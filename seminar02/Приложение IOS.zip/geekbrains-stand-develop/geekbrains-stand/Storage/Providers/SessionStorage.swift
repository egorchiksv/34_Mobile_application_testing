//
//  SessionStorage.swift
//  Storage
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation
import Domain

public final class SessionStorage: Domain.SessionStorageUseCase {
    public static let shared: Domain.SessionStorageUseCase = SessionStorage()

    private let userDefaults = UserDefaults.standard

    private let encoder = JSONEncoder()
    private let decoder = JSONDecoder()

    private static let key: String = "com.gb.test-stand.SessionStorage.SessionInfo"

    private init() {
    }

    public func session() -> SessionInfo? {
        guard
            let data = userDefaults.object(forKey: Self.key) as? Data,
            let session = try? decoder.decode(SessionInfo.self, from: data)
        else {
            return nil
        }

        return session
    }

    public func save(with session: SessionInfo) {
        guard let encoded = try? encoder.encode(session) else {
            return
        }

        userDefaults.set(encoded, forKey: Self.key)
    }

    public func clear() {
        userDefaults.set(nil, forKey: Self.key)
    }
}
