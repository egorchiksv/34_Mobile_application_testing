//
//  Storage.h
//  Storage
//
//  Created by k.kulakov on 19.10.2022.
//

#import <Foundation/Foundation.h>

//! Project version number for Storage.
FOUNDATION_EXPORT double StorageVersionNumber;

//! Project version string for Storage.
FOUNDATION_EXPORT const unsigned char StorageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Storage/PublicHeader.h>


