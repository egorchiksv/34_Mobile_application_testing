//
//  EmptyStatePlaceholderView.swift
//  Utils
//
//  Created by o.gibadulin on 07.11.2022.
//

import UIKit
import PinLayout

public final class EmptyStatePlaceholderView: UIView {

    // MARK: - Properties

    public var image: UIImage? {
        didSet {
            configureImageView()
        }
    }
    public var title: String? {
        didSet {
            configureTitle()
        }
    }
    public var subtitle: String? {
        didSet {
            configureSubtitle()
        }
    }

    private let wrapperView: UIView = UIView()
    private let containerView: UIView = UIView()
    private let imageView: UIImageView = UIImageView()
    private let titleLabel: UILabel = UILabel()
    private let subtitleLabel: UILabel = UILabel()

    // MARK: - Init

    public init(image: UIImage? = nil, title: String? = nil, subtitle: String? = nil) {
        self.image = image
        self.title = title
        self.subtitle = subtitle

        super.init(frame: .zero)
        setup()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        backgroundColor = .background

        containerView.addSubviews(imageView, titleLabel, subtitleLabel)
        wrapperView.addSubviews(containerView)
        addSubview(wrapperView)

        configure()
    }

    private func configure() {
        configureImageView()
        configureTitle()
        configureSubtitle()
    }

    private func configureImageView() {
        imageView.image = image
        imageView.tintColor = Constants.Image.tintColor
        imageView.isHidden = image == nil

        setNeedsLayout()
    }

    private func configureTitle() {
        titleLabel.numberOfLines = 0
        titleLabel.textAlignment = .center
        titleLabel.attributedText = title.map { NSAttributedString(string: $0, attributes: Constants.Title.attributes) }
        titleLabel.isHidden = title.isNilOrEmpty

        setNeedsLayout()
    }

    private func configureSubtitle() {
        subtitleLabel.numberOfLines = 0
        subtitleLabel.textAlignment = .center
        subtitleLabel.attributedText = subtitle.map { NSAttributedString(string: $0, attributes: Constants.Subtitle.attributes) }
        subtitleLabel.isHidden = subtitle.isNilOrEmpty

        setNeedsLayout()
    }

    // MARK: - Layout

    public override func layoutSubviews() {
        super.layoutSubviews()

        let wrapperWidth = calcWrapperWidth(for: bounds.width)
        wrapperView.pin
            .width(wrapperWidth)

        let containerWidth = calcContainerWidth(for: wrapperWidth)
        containerView.pin
            .top()
            .width(containerWidth)

        let imageSize = calcImageSize(of: image, for: containerWidth)
        imageView.pin
            .top()
            .size(imageSize)
            .hCenter()

        if !titleLabel.isHidden {
            titleLabel.pin
                .below(of: imageView)
                .marginTop(Constants.Title.marginTop)
                .horizontally()
                .sizeToFit(.width)
        } else {
            titleLabel.pin
                .below(of: imageView)
                .size(.zero)
        }

        if !subtitleLabel.isHidden {
            subtitleLabel.pin
                .below(of: titleLabel)
                .marginTop(Constants.Subtitle.marginTop)
                .horizontally()
                .sizeToFit(.width)
        } else {
            subtitleLabel.pin
                .below(of: titleLabel)
                .size(.zero)
        }

        containerView.pin
            .hCenter()
            .wrapContent(.vertically)

        wrapperView.pin
            .hCenter()
            .wrapContent(.vertically, padding: Constants.Container.padding)
            .vCenter()
    }
}

// MARK: - Size calculations

private extension EmptyStatePlaceholderView {
    func calcWrapperWidth(for width: CGFloat) -> CGFloat {
        return min(width, Constants.Wrapper.maxWidth)
    }

    func calcContainerWidth(for wrapperWidth: CGFloat) -> CGFloat {
        return wrapperWidth - Constants.Container.padding * 2
    }

    func clasImageSize(with size: CGSize, for width: CGFloat) -> CGSize {
        let ratio = size.width / size.height
        let height = width / ratio
        return .init(width: width, height: height)
    }

    func calcImageSize(of image: UIImage?, for containerWidth: CGFloat) -> CGSize {
        guard let imageSize = image?.size else {
            return .zero
        }

        let minSize = Constants.Image.minSize
        guard imageSize.width > minSize.width || imageSize.height > minSize.height else {
            return clasImageSize(with: imageSize, for: minSize.width)
        }

        guard imageSize.width < containerWidth else {
            return clasImageSize(with: imageSize, for: containerWidth)
        }

        return imageSize
    }
}

// MARK: - Constants

private extension EmptyStatePlaceholderView {
    struct Constants {
        struct Wrapper {
            static let maxWidth: CGFloat = 512
        }
        struct Container {
            static let padding: CGFloat = 24
        }
        struct Image {
            static let minSize: CGSize = CGSize(width: 96, height: 96)

            static let tintColor: UIColor = .UI.primary.value
        }
        struct Title {
            static let marginTop: CGFloat = 20

            static let attributes: [NSAttributedString.Key: Any] = [
                NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value,
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 19, weight: .semibold)
            ]
        }
        struct Subtitle {
            static let marginTop: CGFloat = 16

            static let attributes: [NSAttributedString.Key: Any] = [
                NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value,
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15, weight: .regular)
            ]
        }
    }
}
