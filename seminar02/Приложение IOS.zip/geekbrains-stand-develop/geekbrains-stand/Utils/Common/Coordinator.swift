//
//  Coordinator.swift
//  Utils
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

// swiftlint:disable:next final_class
open class Coordinator: NSObject {
    private var childCoordinators: [Coordinator] = []
    private weak var parent: Coordinator?

    open func start(in parent: Coordinator?) {
        guard let parentCoordinator = parent else {
            return
        }
        self.parent = parentCoordinator
        parentCoordinator.addDependency(self)
    }

    open func finish() {
        parent?.removeDependency(self)
    }
}

private extension Coordinator {
    func addDependency(_ coordinator: Coordinator) {
        guard !childCoordinators.contains(where: { $0 === coordinator }) else {
            return
        }
        childCoordinators.append(coordinator)
    }

    func removeDependency(_ coordinator: Coordinator?) {
        guard !childCoordinators.isEmpty,
            let coordinator = coordinator else {
                return
        }

        if !coordinator.childCoordinators.isEmpty {
            coordinator.childCoordinators.filter { $0 !== coordinator }.forEach { coordinator.removeDependency($0) }
        }
        for (index, element) in childCoordinators.enumerated() where element === coordinator {
            childCoordinators.remove(at: index)
            break
        }
    }
}
