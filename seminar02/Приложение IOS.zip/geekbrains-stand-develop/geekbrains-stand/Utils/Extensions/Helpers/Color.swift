//
//  Color.swift
//  Utils
//
//  Created by e.korotkiy on 21.10.2022.
//

import UIKit

public struct Color {
    let lightValue: UIColor
    let darkValue: UIColor

    init(lightValue: UIColor, darkValue: UIColor? = nil) {
        self.lightValue = lightValue
        self.darkValue = darkValue ?? lightValue
    }

    public var value: UIColor {
        return UIColor { (traitCollection: UITraitCollection) -> UIColor in
            if traitCollection.userInterfaceStyle == .dark {
                return self.darkValue
            } else {
                return self.lightValue
            }
        }
    }
}
