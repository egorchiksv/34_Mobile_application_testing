//
//  UIBarButtonItem.swift
//  Utils
//
//  Created by e.korotkiy on 21.10.2022.
//

import UIKit

public extension UIBarButtonItem {
    static func closeButton(with target: Any?,
                            action: Selector?,
                            accessibilityIdentifier: String? = nil) -> UIBarButtonItem {
        return plainButton(with: target,
                           action: action,
                           image: UIImage(systemName: "xmark"))

    }

    static func plainButton(with target: Any?,
                            action: Selector?,
                            image: UIImage?) -> UIBarButtonItem {
        let button = UIBarButtonItem(image: image, style: .plain, target: target, action: action)

        return button
    }

    static func plainButton(with target: Any?,
                            action: Selector?,
                            title: String?) -> UIBarButtonItem {
        let button = UIBarButtonItem(title: title, style: .plain, target: target, action: action)

        return button
    }
}
