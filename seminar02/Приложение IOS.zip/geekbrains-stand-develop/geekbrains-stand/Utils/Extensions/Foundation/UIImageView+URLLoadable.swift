//
//  UIImageView+URLLoadable.swift
//  Utils
//
//  Created by o.gibadulin on 02.11.2022.
//

import SDWebImage

public extension UIImageView {
    func setImage(from imageURL: String, placeholderImage: UIImage? = nil) {
        sd_setImage(with: URL(string: imageURL),
                    placeholderImage: placeholderImage)
    }
}
