//
//  Array.swift
//  Utils
//
//  Created by e.korotkiy on 26.10.2022.
//

import Foundation

public extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
