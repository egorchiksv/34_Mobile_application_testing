//
//  UICollectionView+CellRegistration.swift
//  Utils
//
//  Created by o.gibadulin on 01.11.2022.
//

import UIKit

public extension UICollectionViewCell {
    static var classNameReuseIdentifier: String {
        return String(describing: self)
    }
}

public extension UICollectionView {
    func registerCellClass(_ cellClass: UICollectionViewCell.Type) {
        let reuseIdentifier = cellClass.classNameReuseIdentifier
        register(cellClass, forCellWithReuseIdentifier: reuseIdentifier)
    }

    func registerNibCell(_ cellClass: UICollectionViewCell.Type) {
        let reuseIdentifier = cellClass.classNameReuseIdentifier
        let nib = UINib(nibName: reuseIdentifier, bundle: Bundle.main)
        register(nib, forCellWithReuseIdentifier: reuseIdentifier)
    }
}
