//
//  Otional+String.swift
//  Utils
//
//  Created by o.gibadulin on 07.11.2022.
//

public extension Optional where Wrapped == String {
    var isNilOrEmpty: Bool {
        switch self {
        case .some(let string):
            return string.isEmpty
        case .none:
            return true
        }
    }
}
