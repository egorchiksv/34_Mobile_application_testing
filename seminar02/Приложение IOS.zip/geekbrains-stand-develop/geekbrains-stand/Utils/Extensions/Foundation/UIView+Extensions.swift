//
//  UIView+Extensions.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 20.10.2022.
//

import UIKit

public extension UIView {
    func addSubviews(_ subviews: UIView...) {
        subviews.forEach(addSubview)
    }
}
