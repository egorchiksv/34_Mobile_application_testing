//
//  String.swift
//  Utils
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public extension String {

    var localized: String {
        return NSLocalizedString(self, tableName: "Localizable", comment: "")
    }
}
