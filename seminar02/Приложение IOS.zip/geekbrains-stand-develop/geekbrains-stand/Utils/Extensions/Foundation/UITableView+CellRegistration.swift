//
//  UITableView+CellRegistration.swift
//  Utils
//
//  Created by o.gibadulin on 24.10.2022.
//

import UIKit

public extension UITableViewCell {
    static var classNameReuseIdentifier: String {
        return String(describing: self)
    }
}

public extension UITableViewHeaderFooterView {
    static var classNameReuseIdentifier: String {
        return String(describing: self)
    }
}

public extension UITableView {
    func registerCellClasses(_ cellClasses: UITableViewCell.Type...) {
        registerCellClasses(cellClasses)
    }

    func registerCellClasses(_ cellClasses: [UITableViewCell.Type]) {
        cellClasses.forEach { cellClass in
            let reuseIdentifier = cellClass.classNameReuseIdentifier
            register(cellClass, forCellReuseIdentifier: reuseIdentifier)
        }
    }

    func registerCellClass(_ cellClass: UITableViewCell.Type) {
        let reuseIdentifier = cellClass.classNameReuseIdentifier
        register(cellClass, forCellReuseIdentifier: reuseIdentifier)
    }

    func registerNibCell(_ cellClass: UITableViewCell.Type) {
        let reuseIdentifier = cellClass.classNameReuseIdentifier
        let nib = UINib(nibName: reuseIdentifier, bundle: Bundle.main)
        register(nib, forCellReuseIdentifier: reuseIdentifier)
    }

    func registerHeaderFooterClass(_ headerFooterClass: UITableViewHeaderFooterView.Type) {
        let reuseIdentifier = headerFooterClass.classNameReuseIdentifier
        register(headerFooterClass, forHeaderFooterViewReuseIdentifier: reuseIdentifier)
    }

    func registerNibHeaderFooter(_ headerFooterClass: UITableViewHeaderFooterView.Type) {
        let reuseIdentifier = headerFooterClass.classNameReuseIdentifier
        let nib = UINib(nibName: reuseIdentifier, bundle: Bundle.main)
        register(nib, forHeaderFooterViewReuseIdentifier: reuseIdentifier)
    }
}

public extension UITableView {
    func dequeueReusableCell<CellType>(for indexPath: IndexPath) -> CellType where CellType: UITableViewCell {
        guard let cell = dequeueReusableCell(withIdentifier: CellType.classNameReuseIdentifier, for: indexPath) as? CellType else {
            fatalError("Couldn't dequeue cell with type \(CellType.description())")
        }
        return cell
    }

    func dequeueReusableHeaderFooterView<ViewType>() -> ViewType where ViewType: UITableViewHeaderFooterView {
        guard let headerView = dequeueReusableHeaderFooterView(withIdentifier: ViewType.classNameReuseIdentifier) as? ViewType else {
            fatalError("Couldn't dequeue headerFooterView with type \(ViewType.description())")
        }
        return headerView
    }
}
