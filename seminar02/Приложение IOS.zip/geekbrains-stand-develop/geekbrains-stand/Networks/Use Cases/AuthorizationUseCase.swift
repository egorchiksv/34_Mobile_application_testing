//
//  AuthorizationUseCase.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Domain
import Moya

final class AuthorizationUseCase: BaseUseCase, Domain.AuthorizationUseCase {

    private let provider = AuthorizationProvider.moyaProvider()

    func login(username: String, password: String, completion: @escaping ((Result<AuthResult, Error>) -> Void)) {
        provider.request(.login(username: username, password: password), completion: { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let authResult = try filteredResponse.map(AuthResult.self)

                    completion(.success(authResult))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        })
    }
}
