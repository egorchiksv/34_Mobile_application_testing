//
//  CreatePostUseCase.swift
//  Networks
//
//  Created by e.korotkiy on 28.10.2022.
//

import Domain
import Moya

final class CreatePostUseCase: SessionUseCase<CreatePostProvider>, Domain.CreatePostUseCase {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String,
                    completion: @escaping ((Result<Void, Error>) -> Void)) {
        provider.request(.createPost(image: image,
                                     title: title,
                                     description: description,
                                     content: content,
                                     isDraft: isDraft,
                                     delayPublishTo: delayPublishTo)) { result in
            switch result {
            case .success(let response):
                do {
                    _ = try response.filterSuccessfulStatusCodes()

                    completion(.success(Void()))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String,
                  completion: @escaping ((Result<FeedPost, Error>) -> Void)) {
        provider.request(.editPost(postId: postId,
                                   image: image,
                                   imageId: imageId,
                                   title: title,
                                   description: description,
                                   content: content,
                                   isDraft: isDraft,
                                   delayPublishTo: delayPublishTo)) { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let updatedPost = try filteredResponse.map(UpdatedFeedPost.self)
                    let post = updatedPost.item

                    completion(.success(post))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
