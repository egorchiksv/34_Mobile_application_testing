//
//  UserUseCase.swift
//  Networks
//
//  Created by o.gibadulin on 24.10.2022.
//

import Domain
import Moya

final class UserUseCase: SessionUseCase<UserProvider>, Domain.UserUseCase {

    func getProfile(userId: Int, completion: @escaping ((Result<UserProfile, Error>) -> Void)) {
        provider.request(.getProfile(userId: userId), completion: { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let userProfile = try filteredResponse.map(UserProfile.self)

                    completion(.success(userProfile))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        })
    }

    func updateProfile(userId: Int,
                       profile: UserProfile,
                       completion: @escaping ((Result<UserProfile, Error>) -> Void)) {
        provider.request(.updateProfile(userId: userId, profile: profile), completion: { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let userProfile = try filteredResponse.map(UserProfile.self)

                    completion(.success(userProfile))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        })
    }
}
