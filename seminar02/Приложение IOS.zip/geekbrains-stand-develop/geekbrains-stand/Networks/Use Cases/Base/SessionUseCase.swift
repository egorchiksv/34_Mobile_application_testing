//
//  SessionUseCase.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Moya

// EXAMPLE

//
// public func makeGoalUseCase(token: String?) -> Domain.GoalUseCase {
//    return GoalUseCase(token: token ?? "")
// }
//
// final class GoalUseCase: SessionUseCase<GoalProvider>, Domain.GoalUseCase {
//    func goals(from date: Date, count: Int) -> Single<[Goal]> {
//        return provider.request ....
//    }
// }

// swiftlint:disable final_class
class SessionUseCase<T: BaseProvider & TargetType>: BaseUseCase {

    let provider: MoyaProvider<T>

    private override init() {
        provider = T.moyaProvider()

        super.init()
    }

    init(token: String) {
        provider = MoyaProvider<T>(requestClosure: { (endpoint, result) in
            // swiftlint:disable:next force_try
            var request = try! endpoint.urlRequest()
            request.addValue(token, forHTTPHeaderField: "X-Auth-Token")

            result(.success(request))
        }, plugins: T.defaultPlugins)
    }
}
