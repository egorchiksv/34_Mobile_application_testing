//
//  BaseUseCase.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

// swiftlint:disable final_class
public class BaseUseCase {

}
