//
//  PostUseCase.swift
//  Networks
//
//  Created by k.kulakov on 31.10.2022.
//

import Domain
import Moya

final class PostUseCase: SessionUseCase<PostProvider>, Domain.PostUseCase {
    private lazy var decoder: JSONDecoder = {
        let decoder = JSONDecoder()

        decoder.dateDecodingStrategy = .iso8601

        return decoder
    }()

    func feed(page: Int,
              limit: Int,
              sort: Domain.FeedSort?,
              order: Domain.FeedOrder?,
              owner: Domain.FeedOwner,
              completion: @escaping ((Result<Domain.Feed, Error>) -> Void)) {
        provider.request(.posts(page: page,
                                limit: limit,
                                sort: sort?.rawValue,
                                order: order?.rawValue,
                                owner: owner.rawValue), completion: { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let feed = try filteredResponse.map(Domain.Feed.self)

                    completion(.success(feed))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        })
    }

    func getPost(postId: Int,
                 completion: @escaping ((Result<FeedPost, Error>) -> Void)) {
        provider.request(.post(postId: postId)) { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let post = try filteredResponse.map(FeedPost.self)

                    completion(.success(post))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func deletePost(postId: Int,
                    completion: @escaping ((Result<FeedPost, Error>) -> Void)) {
        provider.request(.delete(postId: postId), completion: { result in
            switch result {
            case .success(let response):
                do {
                    let filteredResponse = try response.filterSuccessfulStatusCodes()
                    let post = try filteredResponse.map(FeedPost.self)

                    completion(.success(post))
                } catch let error {
                    completion(.failure(error))
                }
            case .failure(let error):
                completion(.failure(error))
            }
        })
    }

}
