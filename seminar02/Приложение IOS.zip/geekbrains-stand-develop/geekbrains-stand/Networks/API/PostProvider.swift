//
//  PostProvider.swift
//  Networks
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation
import Moya
import Domain

enum PostProvider: BaseProvider {
    case posts(page: Int,
               limit: Int,
               sort: String?,
               order: String?,
               owner: String)
    case post(postId: Int)
    case delete(postId: Int)
}

extension PostProvider: TargetType {

    var path: String {
        switch self {
        case .posts:
            return "api/\(Constants.API.Post.posts)"
        case .post(let postId):
            return "api/\(Constants.API.Post.posts)/\(postId)"
        case .delete(let postId):
            return "api/\(Constants.API.Post.posts)/\(postId)"
        }
    }

    var method: Moya.Method {
        switch self {
        case .posts:
            return .get
        case .post:
            return .get
        case .delete:
            return .delete
        }
    }

    var parameterEncoding: ParameterEncoding {
        switch self {
        case .posts:
            return URLEncoding.default
        case .post:
            return URLEncoding.default
        case .delete:
            return URLEncoding.default
        }
    }

    var task: Task {
        switch self {
        case .posts, .post, .delete:
            return .requestParameters(parameters: parameters, encoding: parameterEncoding)
        }
    }

    var parameters: [String: Any] {
        switch self {
        case .posts(
            let page,
            let limit,
            let sort,
            let order,
            let owner
        ):
            var params: [String: Any] = [:]

            params["page"] = page
            params["limit"] = limit
            params["sort"] = sort
            params["order"] = order
            params["owner"] = owner

            return params
        case .post:
            return [:]
        case .delete:
            return [:]
        }
    }
}
