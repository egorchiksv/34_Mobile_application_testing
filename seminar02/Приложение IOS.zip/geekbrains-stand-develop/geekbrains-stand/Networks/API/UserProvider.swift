//
//  UserProvider.swift
//  Networks
//
//  Created by o.gibadulin on 24.10.2022.
//

import Foundation
import Moya
import Domain

enum UserProvider: BaseProvider {
    case getProfile(userId: Int)
    case updateProfile(userId: Int, profile: UserProfile)
}

extension UserProvider: TargetType {

    var path: String {
        switch self {
        case .getProfile(let userId), .updateProfile(let userId, _):
            return "api/\(Constants.API.User.profile)/\(userId)"
        }
    }

    var method: Moya.Method {
        switch self {
        case .getProfile:
            return .get
        case .updateProfile:
            return .put
        }
    }

    var parameterEncoding: ParameterEncoding {
        switch self {
        case .getProfile:
            return URLEncoding.default
        case .updateProfile:
            return JSONEncoding.default
        }
    }

    var task: Task {
        switch self {
        case .getProfile:
            return .requestPlain
        case .updateProfile:
            return .requestParameters(parameters: parameters, encoding: parameterEncoding)
        }
    }

    var parameters: [String: Any] {
        switch self {
        case .getProfile:
            return [:]
        case .updateProfile(_, let profile):
            return [
                "firstName": profile.firstName,
                "lastName": profile.lastName,
                "username": profile.username,
                "phone": profile.phone as Any,
                "sex": profile.sex as Any,
                "birthDate": profile.birthDate as Any
            ]
        }
    }
}
