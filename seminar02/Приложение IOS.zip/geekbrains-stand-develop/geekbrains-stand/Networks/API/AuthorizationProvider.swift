//
//  AuthorizationProvider.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation
import Moya

enum AuthorizationProvider: BaseProvider {
    case login(username: String, password: String)
}

extension AuthorizationProvider: TargetType {

    var path: String {
        switch self {
        case .login: return "api/\(Constants.API.User.login)"
        }
    }

    var method: Moya.Method {
        return .post
    }

    var task: Task {

        switch self {
        case .login:
            return .requestParameters(parameters: parameters, encoding: parameterEncoding)
        }
    }

    var parameters: [String: Any] {
        switch self {
        case .login(let username, let password):
            return [
                "username": username,
                "password": password
            ]
        }
    }
}
