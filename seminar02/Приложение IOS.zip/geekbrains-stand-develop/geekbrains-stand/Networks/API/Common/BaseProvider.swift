//
//  BaseProvider.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Moya

protocol BaseProvider {

}

extension BaseProvider {

    var baseURL: URL {
        // swiftlint:disable force_unwrapping
        let url = URL(string: Constants.API.URL.baseHost)!

        return url
    }

    var path: String {
        return ""
    }

    var method: Moya.Method {
        return .post
    }

    var parameterEncoding: ParameterEncoding {
        return JSONEncoding.default
    }

    var task: Task {
        return .requestPlain
    }

    func multipartFormData(for source: String, name: String) -> MultipartFormData {
        MultipartFormData(provider: .data(source.data(using: .utf8) ?? Data()),
                          name: name)
    }
}

extension BaseProvider where Self: TargetType {

    static var defaultPlugins: [PluginType] {
        return [
            NetworkLoggerPlugin(configuration: .init(logOptions: [.verbose]))
        ]
    }

    static func moyaProvider() -> MoyaProvider<Self> {
        let provider = MoyaProvider<Self>(plugins: defaultPlugins)

        return provider
    }

    var headers: [String: String]? {
        return [:]
    }

    var sampleData: Data {
        return "Not used?".data(using: .utf8)!
    }
}
