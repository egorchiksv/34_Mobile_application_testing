//
//  CreatePostProvider.swift
//  Networks
//
//  Created by e.korotkiy on 28.10.2022.
//

import Foundation
import Moya

enum CreatePostProvider: BaseProvider {
    case createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String)
    case editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String)
}

extension CreatePostProvider: TargetType {

    var path: String {
        switch self {
        case .createPost:
            return "api/\(Constants.API.Post.posts)"
        case .editPost(let postId, _, _, _, _, _, _, _):
            return "gateway/\(Constants.API.Post.posts)/\(postId)"
        }
    }

    var method: Moya.Method {
        switch self {
        case .createPost:
            return .post
        case .editPost:
            return .put
        }
    }

    var task: Task {
        switch self {
        case .createPost(image: let image,
                         title: let title,
                         description: let description,
                         content: let content,
                         isDraft: let isDraft,
                         delayPublishTo: let delayPublishTo):
            let multipartData: [MultipartFormData] = data(image: image,
                                                          title: title,
                                                          description: description,
                                                          content: content,
                                                          isDraft: isDraft,
                                                          delayPublishTo: delayPublishTo)

            return .uploadMultipart(multipartData)
        case .editPost(_,
                       image: let image,
                       imageId: let imageId,
                       title: let title,
                       description: let description,
                       content: let content,
                       isDraft: let isDraft,
                       delayPublishTo: let delayPublishTo):
            var multipartData: [MultipartFormData] = data(image: image,
                                                          title: title,
                                                          description: description,
                                                          content: content,
                                                          isDraft: isDraft,
                                                          delayPublishTo: delayPublishTo)
            if let imageId = imageId {
                multipartData.append(multipartFormData(for: String(imageId), name: "imageId"))
            }

            return .uploadMultipart(multipartData)
        }
    }
}

private extension CreatePostProvider {

    func data(image: Data?,
              title: String,
              description: String,
              content: String,
              isDraft: Bool,
              delayPublishTo: String) -> [MultipartFormData] {
        var multipartData: [MultipartFormData] = []

        if let image = image {
            let data = MultipartFormData(provider: .data(image),
                                         name: "image",
                                         fileName: "image.jpeg",
                                         mimeType: "image/jpeg")
            multipartData.append(data)
        }
        multipartData.append(multipartFormData(for: title, name: "title"))
        multipartData.append(multipartFormData(for: description, name: "description"))
        multipartData.append(multipartFormData(for: content, name: "content"))
        let isDraft = isDraft ? "1" : "0"
        multipartData.append(multipartFormData(for: isDraft, name: "isDraft"))
        multipartData.append(multipartFormData(for: delayPublishTo, name: "delayPublishTo"))

        return multipartData
    }
}
