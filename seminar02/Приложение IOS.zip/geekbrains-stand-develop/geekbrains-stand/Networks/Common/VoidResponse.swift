//
//  VoidResponse.swift
//  Networks
//
//  Created by e.korotkiy on 28.10.2022.
//

import Foundation

public struct VoidResponse: Decodable { }
