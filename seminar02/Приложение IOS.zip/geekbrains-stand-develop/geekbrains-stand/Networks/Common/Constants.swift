//
//  Constants.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

enum Constants {

    enum API {
        enum URL {
            static let baseHost = "https://test-stand.gb.ru/"
        }

        enum User {
            static let login = "login"
            static let profile = "users/profile"
        }

        enum Post {
            static let posts = "posts"
        }
    }
}
