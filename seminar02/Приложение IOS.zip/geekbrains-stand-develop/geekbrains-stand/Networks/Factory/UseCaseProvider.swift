//
//  UseCaseProvider.swift
//  Networks
//
//  Created by k.kulakov on 19.10.2022.
//

import Domain
import Moya

public final class UseCaseProvider: Domain.NetworkingUseCaseProvider {
    public init() {
    }

    public func makeAuthorizationUseCase() -> Domain.AuthorizationUseCase {
        return AuthorizationUseCase()
    }

    public func makeUserUseCase(token: String?) -> Domain.UserUseCase {
        return UserUseCase(token: token ?? "")
    }

    public func makePostUseCase(token: String?) -> Domain.PostUseCase {
        return PostUseCase(token: token ?? "")
    }

    public func makeCreatePostUseCase(token: String?) -> Domain.CreatePostUseCase {
        return CreatePostUseCase(token: token ?? "")
    }
}
