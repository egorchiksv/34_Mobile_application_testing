//
//  AuthResult.swift
//  Domain
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public struct AuthResult: Codable {
    public let userId: Int
    public let username: String
    public let token: String
    public let roles: [String]
}
