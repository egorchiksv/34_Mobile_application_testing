//
//  UserProfile.swift
//  Domain
//
//  Created by o.gibadulin on 24.10.2022.
//

import Foundation

public struct UserProfile: Codable, Equatable {
    public let id: Int
    public var firstName: String
    public var lastName: String
    public var username: String
    public var phone: String?
    public var status: String
    public var sex: String?
    public var birthDate: String?
    public var avatar: FileLink
    public let updatedAt: String
    public let createdAt: String
}
