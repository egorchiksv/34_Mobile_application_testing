//
//  SessionInfo.swift
//  Domain
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public struct SessionInfo: Codable {
    public let userId: String
    public let token: String

    public init(userId: String, token: String) {
        self.userId = userId
        self.token = token
    }
}

extension SessionInfo {
    public var userIdInt: Int {
        // swiftlint:disable force_unwrapping
        return Int(userId)!
    }
}
