//
//  FileLink.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public struct FileLink: Codable, Equatable {
    public let id: Int?
    public let url: String

    public init(id: Int?, url: String) {
        self.id = id
        self.url = url
    }

    enum CodingKeys: String, CodingKey {
        case id
        case url = "cdnUrl"
    }
}
