//
//  Feed.swift
//  Domain
//
//  Created by o.gibadulin on 07.11.2022.
//

import Foundation

public struct Feed: Decodable {

    public let meta: FeedMeta
    public let posts: [FeedPost]

    public enum CodingKeys: String, CodingKey {
        case meta
        case posts = "data"
    }
}
