//
//  FeedOrder.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public enum FeedOrder: String {
    case desc = "DESC"
    case asc = "ASC"
}
