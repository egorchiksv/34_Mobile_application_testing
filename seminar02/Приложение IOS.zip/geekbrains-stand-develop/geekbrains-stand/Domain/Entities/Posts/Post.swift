//
//  Post.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public struct FeedPost: Decodable {

    public let id: Int
    public let title: String
    public let description: String
    public let content: String
    public let authorId: Int
    public let mainImage: FileLink
    public let labels: [String]
    public let delayPublishTo: String?
    public let isDraft: Bool?
    public let updatedDate: String?
    public let createdDate: String

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(Int.self, forKey: .id)
        self.title = try container.decode(String.self, forKey: .title)
        self.description = try container.decode(String.self, forKey: .description)
        self.content = try container.decode(String.self, forKey: .content)
        self.authorId = try container.decode(Int.self, forKey: .authorId)
        self.mainImage = try container.decode(FileLink.self, forKey: .mainImage)
        self.labels = try container.decode([String].self, forKey: .labels)
        self.delayPublishTo = try container.decodeIfPresent(String.self, forKey: .delayPublishTo)
        self.updatedDate = try container.decodeIfPresent(String.self, forKey: .updatedDate)
        self.createdDate = try container.decode(String.self, forKey: .createdDate)

        if let isDraft = try container.decodeIfPresent(Bool.self, forKey: .draft) {
            self.isDraft = isDraft
        } else {
            self.isDraft = try container.decodeIfPresent(Bool.self, forKey: .isDraft)
        }
    }

    public init(id: Int,
                title: String,
                description: String,
                content: String,
                authorId: Int,
                mainImage: FileLink,
                labels: [String],
                delayPublishTo: String?,
                isDraft: Bool?,
                updatedDate: String?,
                createdDate: String) {
        self.id = id
        self.title = title
        self.description = description
        self.content = content
        self.authorId = authorId
        self.mainImage = mainImage
        self.labels = labels
        self.delayPublishTo = delayPublishTo
        self.isDraft = isDraft
        self.updatedDate = updatedDate
        self.createdDate = createdDate
    }

    public enum CodingKeys: String, CodingKey {
        case id
        case title
        case description
        case content
        case authorId
        case mainImage
        case labels
        case delayPublishTo
        case isDraft
        case draft
        case updatedDate = "updatedAt"
        case createdDate = "createdAt"
    }

}

public struct UpdatedFeedPost: Decodable {

    public let item: FeedPost
}
