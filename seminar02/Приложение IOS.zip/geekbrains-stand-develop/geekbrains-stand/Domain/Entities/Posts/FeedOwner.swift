//
//  FeedOwner.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public enum FeedOwner: String {
    case otherUser = "notMe"
    case myUser = "me"
}
