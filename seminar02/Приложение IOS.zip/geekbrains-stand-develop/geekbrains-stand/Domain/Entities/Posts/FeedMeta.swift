//
//  FeedMeta.swift
//  Domain
//
//  Created by o.gibadulin on 07.11.2022.
//

import Foundation

public struct FeedMeta: Codable {

    public let prevPage: Int?
    public let nextPage: Int?
    public let count: Int
}
