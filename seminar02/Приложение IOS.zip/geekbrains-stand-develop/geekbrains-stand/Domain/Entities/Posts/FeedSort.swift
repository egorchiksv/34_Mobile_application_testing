//
//  FeedSort.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public enum FeedSort: String {
    case createdDate = "createdAt"
}
