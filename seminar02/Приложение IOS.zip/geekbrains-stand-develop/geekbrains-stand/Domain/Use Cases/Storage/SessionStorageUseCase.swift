//
//  SessionStorageUseCase.swift
//  Domain
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public protocol SessionStorageUseCase {
    func session() -> SessionInfo?
    func save(with session: SessionInfo)
    func clear()
}
