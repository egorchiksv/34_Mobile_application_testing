//
//  PostUseCase.swift
//  Domain
//
//  Created by k.kulakov on 31.10.2022.
//

import Foundation

public protocol PostUseCase {
    func feed(page: Int,
              limit: Int,
              sort: FeedSort?,
              order: FeedOrder?,
              owner: FeedOwner,
              completion: @escaping ((Result<Feed, Error>) -> Void))
    func getPost(postId: Int,
                 completion: @escaping ((Result<FeedPost, Error>) -> Void))
    func deletePost(postId: Int,
                    completion: @escaping ((Result<FeedPost, Error>) -> Void))
}
