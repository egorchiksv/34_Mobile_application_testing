//
//  CreatePostUseCase.swift
//  Domain
//
//  Created by e.korotkiy on 28.10.2022.
//

import Foundation

public protocol CreatePostUseCase {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String,
                    completion: @escaping ((Result<Void, Error>) -> Void))
    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String,
                  completion: @escaping ((Result<FeedPost, Error>) -> Void))
}
