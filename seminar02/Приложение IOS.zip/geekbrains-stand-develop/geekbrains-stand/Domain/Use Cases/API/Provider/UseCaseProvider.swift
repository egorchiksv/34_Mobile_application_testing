//
//  UseCaseProvider.swift
//  Domain
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public protocol NetworkingUseCaseProvider {

    func makeAuthorizationUseCase() -> AuthorizationUseCase
    func makeUserUseCase(token: String?) -> Domain.UserUseCase
    func makePostUseCase(token: String?) -> Domain.PostUseCase
    func makeCreatePostUseCase(token: String?) -> CreatePostUseCase
}
