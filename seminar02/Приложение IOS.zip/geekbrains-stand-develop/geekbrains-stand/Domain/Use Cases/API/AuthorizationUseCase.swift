//
//  AuthorizationUseCase.swift
//  Domain
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public protocol AuthorizationUseCase {
    func login(username: String, password: String, completion: @escaping ((Result<AuthResult, Error>) -> Void))
}
