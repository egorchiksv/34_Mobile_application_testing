//
//  UserProfileUseCase.swift
//  Domain
//
//  Created by o.gibadulin on 24.10.2022.
//

import Foundation

public protocol UserUseCase {
    func getProfile(userId: Int, completion: @escaping ((Result<UserProfile, Error>) -> Void))
    func updateProfile(userId: Int,
                       profile: UserProfile,
                       completion: @escaping ((Result<UserProfile, Error>) -> Void))
}
