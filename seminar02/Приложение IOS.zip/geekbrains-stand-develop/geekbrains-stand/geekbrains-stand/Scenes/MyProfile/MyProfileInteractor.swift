//
//  MyProfileInteractor.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Foundation
import Domain

final class MyProfileInteractor {
    weak var output: MyProfileInteractorOutput?

    private let userManager: UserManagerDescription
    private let authorizationManager: AuthorizationManagerDescription

    init(userManager: UserManagerDescription = UserManager.shared,
         authorizationManager: AuthorizationManagerDescription = AuthorizationManager.shared) {
        self.userManager = userManager
        self.authorizationManager = authorizationManager
    }
}

extension MyProfileInteractor: MyProfileInteractorInput {
    func loadProfile() {
        guard let userId = authorizationManager.sessionInfo?.userIdInt else {
            return
        }

        userManager.getProfile(userId: userId) { [weak self] result in
            switch result {
            case .success(let profile):
                self?.output?.didRecieve(profile: profile)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }

    func updateProfile(with profile: UserProfile) {
        guard let userId = authorizationManager.sessionInfo?.userIdInt else {
            return
        }

        userManager.updateProfile(userId: userId, profile: profile) { [weak self] result in
            switch result {
            case .success(let profile):
                self?.output?.didRecieve(profile: profile)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }
}
