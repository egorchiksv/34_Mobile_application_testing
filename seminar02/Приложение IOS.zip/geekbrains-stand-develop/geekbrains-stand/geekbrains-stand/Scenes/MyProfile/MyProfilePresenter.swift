//
//  MyProfilePresenter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Domain

final class MyProfilePresenter {
    weak var view: MyProfileViewInput?
    weak var moduleOutput: MyProfileModuleOutput?

    private let router: MyProfileRouterInput
    private let interactor: MyProfileInteractorInput

    private var isAvatarChanged: Bool = false
    private var oldProfile: UserProfile?
    private var profile: UserProfile? {
        didSet {
            enableSavingIfNeeded()
        }
    }
    var dataSource: [MyProfileTableViewSection] = []

    init(router: MyProfileRouterInput, interactor: MyProfileInteractorInput) {
        self.router = router
        self.interactor = interactor
    }
}

private extension MyProfilePresenter {
    func configureDataSource() {
        dataSource = [
            .init(items: [
                .init(type: .avatar,
                      model: MyProfileAvatarCellViewModel(imageUrl: profile?.avatar.url,
                                                          delegate: self)),
                .init(type: .textField,
                      model: MyProfileTextFieldCellViewModel(type: .firstname,
                                                             value: profile?.firstName,
                                                             delegate: self)),
                .init(type: .textField,
                      model: MyProfileTextFieldCellViewModel(type: .lastname,
                                                             value: profile?.lastName,
                                                             delegate: self))
            ]),
            .init(items: [
                .init(type: .phone,
                      model: MyProfilePhoneCellViewModel(value: profile?.phone,
                                                             delegate: self)),
                .init(type: .textField,
                      model: MyProfileTextFieldCellViewModel(type: .username,
                                                             value: profile?.username,
                                                             delegate: self)),
                .init(type: .datePicker,
                      model: MyProfileDatePickerCellViewModel(type: .birthdate,
                                                              value: profile?.birthDate,
                                                              delegate: nil))
            ]),
            .init(items: [
                .init(type: .navigation,
                      model: MyProfileNavigationCellViewModel(type: .subsribers)),
                .init(type: .navigation,
                      model: MyProfileNavigationCellViewModel(type: .subscriptions)),
                .init(type: .logout,
                      model: MyProfileNavigationCellViewModel(type: .logout))
            ])
        ]
    }

    func enableSavingIfNeeded() {
        let isProfileChanged = profile != oldProfile || isAvatarChanged
        view?.updateSaveButtonState(needSave: isProfileChanged)
    }

    func configure(with profile: UserProfile) {
        isAvatarChanged = false
        oldProfile = profile
        self.profile = profile
        configureDataSource()
    }

    func showValidationError(message: String) {
        let title = "MyProfile_Save_Error_Title".localized
        view?.showHUD(title: title, message: message)
    }

    var validPhoneNumber: Bool {
        guard
            let phoneNumber = profile?.phone,
            !phoneNumber.isEmpty
        else {
            return true
        }

        let isWholePhoneNumber = phoneNumber.count == 11
        guard isWholePhoneNumber else {
            showValidationError(message: "MyProfile_Save_Phone_Number_Error_Message".localized)

            return false
        }

        return true
    }

    var validTextFields: Bool {
        guard let profile = profile else {
            return false
        }

        let textFields: [String: String] = [
            "MyProfile_Text_Field_Cell_Title_Username".localized: profile.username,
            "MyProfile_Text_Field_Cell_Title_Lastname".localized: profile.lastName,
            "MyProfile_Text_Field_Cell_Title_Firstname".localized: profile.firstName
        ]
        let isNotEmpty = textFields.allSatisfy { field in
            guard !field.value.isEmpty else {
                let message = String(format: "MyProfile_Save_Empty_Field_Error_Message".localized, field.key)
                showValidationError(message: message)

                return false
            }

            return true
        }

        return isNotEmpty
    }

    var isProfileValid: Bool {
        guard
            profile != nil,
            validTextFields,
            validPhoneNumber
        else {
            return false
        }

        return true
    }
}

extension MyProfilePresenter: MyProfileModuleInput {
}

extension MyProfilePresenter: MyProfileViewOutput {
    func sectionsCount() -> Int {
        dataSource.count
    }

    func itemsCount(for section: Int) -> Int {
        dataSource[section].items.count
    }

    func item(at indexPath: IndexPath) -> MyProfileTableViewItem {
        dataSource[indexPath.section].items[indexPath.row]
    }

    func didLoadView() {
        view?.showActivity()
        interactor.loadProfile()
    }

    func didTapSaveButton() {
        guard
            isProfileValid,
            let profile = profile
        else {
            return
        }

        view?.showActivity()
        interactor.updateProfile(with: profile)
    }

    func didSelectItem(at indexPath: IndexPath) {
        let item: MyProfileTableViewItem = item(at: indexPath)

        switch item.type {
        case .navigation:
            moduleOutput?.myProfileModuleDidRequestToOpenAuthorization()
        case .logout:
            moduleOutput?.myProfileModuleDidRequestToLogout()
        default:
            break
        }
    }
}

extension MyProfilePresenter: MyProfileInteractorOutput {
    func didRecieve(profile: UserProfile) {
        view?.hideActivity()
        configure(with: profile)
        view?.reloadData()
    }

    func didRecieve(error: Error) {
        view?.hideActivity()
        view?.showHUD(with: error, completion: nil)
    }
}

// MARK: - MyProfileTextFieldCellDelegate

extension MyProfilePresenter: MyProfileTextFieldCellDelegate {
    func didChangeText(for type: MyProfileTextFieldCellType, with value: String?) {
        guard let value = value else {
            return
        }

        switch type {
        case .firstname:
            profile?.firstName = value
        case .lastname:
            profile?.lastName = value
        case .username:
            profile?.username = value
        }
    }
}

// MARK: - MyProfileAvatarCellDelegate

extension MyProfilePresenter: MyProfileAvatarCellDelegate {
    func didChangeAvatar() {
        isAvatarChanged = true
        enableSavingIfNeeded()
    }
}

// MARK: - MyProfilePhoneCellDelegate

extension MyProfilePresenter: MyProfilePhoneCellDelegate {
    func didChangePhoneNumber(with value: String?) {
        profile?.phone = value
    }
}
