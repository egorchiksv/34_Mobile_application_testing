//
//  MyProfileTableViewItem.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit

enum MyProfileTableViewItemType: String {
    case textField
    case datePicker
    case navigation
    case logout
    case avatar
    case phone
}

protocol MyProfileTableViewCellViewModel {}

final class MyProfileTableViewItem {
    let type: MyProfileTableViewItemType
    let model: MyProfileTableViewCellViewModel

    var height: CGFloat {
        switch type {
        case .textField, .datePicker, .navigation, .phone, .logout:
            return 40
        case .avatar:
            return 100
        }
    }

    init(type: MyProfileTableViewItemType, model: MyProfileTableViewCellViewModel) {
        self.type = type
        self.model = model
    }
}
