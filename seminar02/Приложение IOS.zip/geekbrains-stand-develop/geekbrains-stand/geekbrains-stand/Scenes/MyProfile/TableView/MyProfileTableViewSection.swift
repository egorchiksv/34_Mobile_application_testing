//
//  MyProfileTableViewSection.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 24.10.2022.
//

import UIKit

final class MyProfileTableViewSection {
    let items: [MyProfileTableViewItem]

    init(items: [MyProfileTableViewItem]) {
        self.items = items
    }
}
