//
//  MyProfileCoordinator.swift
//  geekbrains-stand
//
//  Created e.korotkiy on 19.10.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils

struct MyProfileFlowContext {

}

final class MyProfileCoordinator: Coordinator {

    // MARK: - Private properties

    private let flowContext: MyProfileFlowContext

    private weak var navigationController: UINavigationController?
    private(set) var mainViewController: UIViewController?

    private var myPostsCoordinator: MyPostsCoordinator?

    // MARK: - Init

    init(navigationController: UINavigationController?, flowContext: MyProfileFlowContext) {
        self.flowContext = flowContext

        super.init()

        let context = MyProfileContext(moduleOutput: self)
        let container = MyProfileContainer.assemble(with: context)

        if navigationController == nil {
            mainViewController = UINavigationController(rootViewController: container.viewController)
        } else {
            self.navigationController = navigationController
            mainViewController = container.viewController
        }
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)

    }

    override func finish() {
        super.finish()

    }
}

private extension MyProfileCoordinator {
    var currentNavigationController: UINavigationController? {
        guard navigationController == nil else {
            return navigationController
        }

        return mainViewController as? UINavigationController
    }
}

extension MyProfileCoordinator: MyProfileModuleOutput {
    func myProfileModuleDidRequestToOpenAuthorization() {
        guard let currentNavigationController = currentNavigationController else {
            return
        }

        let context = AuthorizationContext(moduleOutput: nil)
        let container = AuthorizationContainer.assemble(with: context)
        let viewController: UIViewController = container.viewController

        currentNavigationController.pushViewController(viewController, animated: true)
    }

    func myProfileModuleDidRequestToLogout() {
        AuthorizationManager.shared.logout()
    }
}
