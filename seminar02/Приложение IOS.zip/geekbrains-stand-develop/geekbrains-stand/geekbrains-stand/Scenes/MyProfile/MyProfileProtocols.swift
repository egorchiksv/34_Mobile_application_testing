//
//  MyProfileProtocols.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Domain

protocol MyProfileModuleInput {
    var moduleOutput: MyProfileModuleOutput? { get }
}

protocol MyProfileModuleOutput: AnyObject {
    func myProfileModuleDidRequestToOpenAuthorization()
    func myProfileModuleDidRequestToLogout()
}

protocol MyProfileViewInput: HUDPresentable {
    func reloadData()
    func updateSaveButtonState(needSave: Bool)
}

protocol MyProfileViewOutput: AnyObject {
    func sectionsCount() -> Int
    func itemsCount(for section: Int) -> Int
    func item(at indexPath: IndexPath) -> MyProfileTableViewItem
    func didLoadView()
    func didTapSaveButton()
    func didSelectItem(at indexPath: IndexPath)
}

protocol MyProfileInteractorInput: AnyObject {
    func loadProfile()
    func updateProfile(with profile: UserProfile)
}

protocol MyProfileInteractorOutput: AnyObject {
    func didRecieve(profile: UserProfile)
    func didRecieve(error: Error)
}

protocol MyProfileRouterInput: AnyObject {
}
