//
//  MyProfileViewController.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit

final class MyProfileViewController: UIViewController {

    // MARK: - Properties

    private let output: MyProfileViewOutput

    private let tableView: UITableView = UITableView(frame: .zero, style: .insetGrouped)

    // MARK: - Init

    init(output: MyProfileViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        tableView.registerCellClasses(MyProfileTextFieldCell.self,
                                      MyProfileDatePickerCell.self,
                                      MyProfileNavigationCell.self,
                                      MyProfileAvatarCell.self,
                                      MyProfilePhoneCell.self)
        tableView.delegate = self
        tableView.dataSource = self

        tableView.backgroundColor = .background
        view.backgroundColor = .background

        view.addSubviews(tableView)
    }

    private func setupNavigationBar() {
        let saveButton = UIBarButtonItem(title: "MyProfile_Save_Button".localized,
                                         style: .plain,
                                         target: self, action: #selector(didTapSaveButton))
        navigationItem.rightBarButtonItem = saveButton
        updateSaveButtonState(needSave: false)

        navigationItem.title = "MyProfile_Title".localized
    }

    private func setupToHideKeyboardOnTapOnView() {
        let tap: UITapGestureRecognizer = .init(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        setupNavigationBar()
        setupToHideKeyboardOnTapOnView()

        output.didLoadView()
    }

    // MARK: - Layout

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        tableView.pin
            .top(view.safeAreaInsets.top)
            .bottom()
            .horizontally()
    }
}

// MARK: - Actions

private extension MyProfileViewController {
    @objc
    func didTapSaveButton() {
        view.endEditing(true)
        output.didTapSaveButton()
    }

    @objc
    func dismissKeyboard() {
        view.endEditing(true)
    }
}

// MARK: - View input

extension MyProfileViewController: MyProfileViewInput {
    func reloadData() {
        tableView.reloadData()
    }

    func updateSaveButtonState(needSave: Bool) {
        if #available(iOS 16.0, *) {
            navigationItem.rightBarButtonItem?.isHidden = !needSave
        } else {
            navigationItem.rightBarButtonItem?.isEnabled = needSave
        }
    }
}

// MARK: - UITableViewDataSource

extension MyProfileViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return output.sectionsCount()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return output.itemsCount(for: section)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item: MyProfileTableViewItem = output.item(at: indexPath)
        let cellType: UITableViewCell.Type

        switch item.type {
        case .textField:
            cellType = MyProfileTextFieldCell.self
        case .datePicker:
            cellType = MyProfileDatePickerCell.self
        case .navigation:
            cellType = MyProfileNavigationCell.self
        case .logout:
            cellType = MyProfileNavigationCell.self
        case .avatar:
            cellType = MyProfileAvatarCell.self
        case .phone:
            cellType = MyProfilePhoneCell.self
        }

        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellType.classNameReuseIdentifier,
                                                       for: indexPath) as? MyProfileTableViewCell
        else {
            return UITableViewCell()
        }

        cell.configure(with: item.model)

        return cell
    }
}

// MARK: - UITableViewDelegate

extension MyProfileViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let item: MyProfileTableViewItem = output.item(at: indexPath)

        return item.height
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        output.didSelectItem(at: indexPath)
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
