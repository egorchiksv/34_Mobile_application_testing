//
//  MyProfileRouter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit

final class MyProfileRouter {
}

extension MyProfileRouter: MyProfileRouterInput {
}
