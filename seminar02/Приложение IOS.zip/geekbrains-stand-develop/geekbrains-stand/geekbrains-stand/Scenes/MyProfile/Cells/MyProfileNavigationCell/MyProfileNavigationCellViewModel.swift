//
//  MyProfileNavigationCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit

final class MyProfileNavigationCellViewModel: MyProfileTableViewCellViewModel {
    let type: MyProfileNavigationCellType
    let title: NSAttributedString
    let image: String

    init(type: MyProfileNavigationCellType) {
        self.type = type
        self.image = "chevron.right"

        let title: String
        switch type {
        case .subsribers:
            title = "MyProfile_Navigation_Cell_Title_Subsribers".localized
        case .subscriptions:
            title = "MyProfile_Navigation_Cell_Title_Subsriptions".localized
        case .logout:
            title = "MyProfile_Navigation_Cell_Title_Logout".localized
        }
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)
    }
}

private extension MyProfileNavigationCellViewModel {
    struct Constants {
        static let titleAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value]
    }
}
