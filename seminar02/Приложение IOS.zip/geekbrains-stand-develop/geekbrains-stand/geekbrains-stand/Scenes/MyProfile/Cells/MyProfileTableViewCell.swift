//
//  MyProfileTableViewCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 24.10.2022.
//

import UIKit

protocol MyProfileTableViewCell: UITableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel)
}
