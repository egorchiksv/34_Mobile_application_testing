//
//  MyProfileAvatarCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit
import PinLayout
import Utils

protocol MyProfileAvatarCellDelegate: AnyObject {
    func didChangeAvatar()
}

final class MyProfileAvatarCell: UITableViewCell {

    // MARK: - Properties

    private lazy var imagePicker: ImagePicker? = {
        guard let vc = window?.rootViewController else {
            return nil
        }

        return ImagePicker(vc: vc, delegate: self)
    }()
    private var viewModel: MyProfileAvatarCellViewModel?

    private let containerView: UIView = UIView()
    private let avatarButton: UIButton = UIButton()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        selectionStyle = .none
        contentView.isUserInteractionEnabled = false
        contentView.backgroundColor = Constants.backgroundColor

        avatarButton.clipsToBounds = true
        avatarButton.backgroundColor = Constants.AvatarButton.backgroundColor
        avatarButton.tintColor = Constants.AvatarButton.tintColor

        let image = UIImage(systemName: "camera.fill")?.withRenderingMode(.alwaysTemplate)
        avatarButton.setImage(image, for: .normal)
        avatarButton.imageView?.layer.transform = CATransform3DMakeScale(1.5, 1.5, 1.5)

        avatarButton.addTarget(self, action: #selector(didTapAvatarButton), for: .touchUpInside)

        containerView.addSubviews(avatarButton)
        addSubviews(containerView)
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        avatarButton.pin
            .top()
            .height(100%)
            .aspectRatio(1)
            .hCenter()

        avatarButton.layer.cornerRadius = avatarButton.frame.height / 2
    }
}

// MARK: - Actions

private extension MyProfileAvatarCell {
    @objc
    func didTapAvatarButton() {
        imagePicker?.present(from: contentView)

        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.impactOccurred()
    }
}

// MARK: - Constants

private extension MyProfileAvatarCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 12, left: 20, bottom: 12, right: 20)
        }
        struct AvatarButton {
            static let size: CGSize = CGSize(width: 128, height: 128)

            static let backgroundColor: UIColor = .background
            static let tintColor: UIColor = .UI.primary.value
        }
        static let backgroundColor: UIColor = .UI.card.value
    }
}

// MARK: - MyProfileTableViewCell

extension MyProfileAvatarCell: MyProfileTableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel) {
        guard let viewModel = viewModel as? MyProfileAvatarCellViewModel else {
            return
        }

        self.viewModel = viewModel

        setNeedsLayout()
    }
}

// MARK: - ImagePickerDelegate

extension MyProfileAvatarCell: ImagePickerDelegate {
    func didSelect(image: UIImage?) {
        avatarButton.setImage(image, for: .normal)
        viewModel?.delegate?.didChangeAvatar()
    }
}
