//
//  MyProfileTextFieldCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 24.10.2022.
//

import UIKit
import PinLayout

enum MyProfileTextFieldCellType {
    case firstname, lastname, username
}

protocol MyProfileTextFieldCellDelegate: AnyObject {
    func didChangeText(for type: MyProfileTextFieldCellType, with value: String?)
}

final class MyProfileTextFieldCell: UITableViewCell {

    // MARK: - Properties

    private var viewModel: MyProfileTextFieldCellViewModel?

    private let containerView: UIView = UIView()
    private var titleLabel: UILabel = UILabel()
    private let valueTextField: UITextField = UITextField()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        selectionStyle = .none
        contentView.isUserInteractionEnabled = false
        contentView.backgroundColor = Constants.backgroundColor

        valueTextField.delegate = self
        valueTextField.addTarget(self, action: #selector(didChangeValueTextField), for: .editingChanged)

        containerView.addSubviews(titleLabel, valueTextField)
        addSubviews(containerView)
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        titleLabel.pin
            .left()
            .width(Constants.TitleLabel.width)
            .height(Constants.TitleLabel.height)

        valueTextField.pin
            .after(of: titleLabel)
            .right()
            .marginLeft(Constants.ValueTextField.marginLeft)
            .height(Constants.ValueTextField.height)
    }

    override func prepareForReuse() {
        super.prepareForReuse()

        valueTextField.isEnabled = true
    }
}

// MARK: - Actions

private extension MyProfileTextFieldCell {
    @objc
    func didChangeValueTextField(_ textField: UITextField) {
        guard let type = viewModel?.type else {
            return
        }

        viewModel?.delegate?.didChangeText(for: type, with: textField.text)
    }
}

// MARK: - Constants

private extension MyProfileTextFieldCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 4, left: 20, bottom: 4, right: 8)
        }
        struct TitleLabel {
            static let width: Percent = 40%
            static let height: Percent = 100%
        }
        struct ValueTextField {
            static let marginLeft: CGFloat = 8
            static let height: Percent = 100%
        }
        static let backgroundColor: UIColor = .UI.card.value
    }
}

// MARK: - MyProfileTableViewCell

extension MyProfileTextFieldCell: MyProfileTableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel) {
        guard let viewModel = viewModel as? MyProfileTextFieldCellViewModel else {
            return
        }

        switch viewModel.type {
        case .username:
            valueTextField.isEnabled = false
        default:
            break
        }

        self.viewModel = viewModel
        titleLabel.attributedText = viewModel.title
        valueTextField.text = viewModel.value
        valueTextField.attributedPlaceholder = viewModel.placeholder

        setNeedsLayout()
    }
}

// MARK: - UITextFieldDelegate

extension MyProfileTextFieldCell: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()

        return false
    }
}
