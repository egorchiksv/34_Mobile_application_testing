//
//  MyProfilePhoneCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 28.10.2022.
//

import UIKit

final class MyProfilePhoneCellViewModel: MyProfileTableViewCellViewModel {
    let title: NSAttributedString
    let value: String?
    weak var delegate: MyProfilePhoneCellDelegate?

    init(value: String?,
         delegate: MyProfilePhoneCellDelegate?) {
        self.value = value
        self.delegate = delegate

        let title = "MyProfile_Phone_Cell_Title".localized
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)
    }
}

private extension MyProfilePhoneCellViewModel {
    struct Constants {
        static let titleAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value]
    }
}
