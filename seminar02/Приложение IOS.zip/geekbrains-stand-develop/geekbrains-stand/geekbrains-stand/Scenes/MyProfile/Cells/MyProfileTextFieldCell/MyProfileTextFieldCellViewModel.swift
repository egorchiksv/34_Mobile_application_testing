//
//  MyProfileTextFieldCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 24.10.2022.
//

import UIKit

final class MyProfileTextFieldCellViewModel: MyProfileTableViewCellViewModel {
    let type: MyProfileTextFieldCellType
    let title: NSAttributedString
    let placeholder: NSAttributedString
    let value: String?
    weak var delegate: MyProfileTextFieldCellDelegate?

    init(type: MyProfileTextFieldCellType,
         value: String? = nil,
         delegate: MyProfileTextFieldCellDelegate?) {
        self.type = type
        self.value = value
        self.delegate = delegate

        let title: String
        switch type {
        case .firstname:
            title = "MyProfile_Text_Field_Cell_Title_Firstname".localized
        case .lastname:
            title = "MyProfile_Text_Field_Cell_Title_Lastname".localized
        case .username:
            title = "MyProfile_Text_Field_Cell_Title_Username".localized
        }
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)

        let placeholder: String
        switch type {
        case .firstname, .lastname, .username:
            placeholder = "MyProfile_Text_Field_Cell_Value_Placeholder".localized
        }
        self.placeholder = NSAttributedString(string: placeholder,
                                              attributes: Constants.placeholderAttributes)
    }
}

private extension MyProfileTextFieldCellViewModel {
    struct Constants {
        static let titleAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value]
        static let placeholderAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value]
    }
}
