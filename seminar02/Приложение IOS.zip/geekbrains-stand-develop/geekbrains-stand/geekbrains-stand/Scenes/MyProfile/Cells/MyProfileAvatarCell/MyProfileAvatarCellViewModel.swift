//
//  MyProfileAvatarCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

final class MyProfileAvatarCellViewModel: MyProfileTableViewCellViewModel {
    let value: String?
    weak var delegate: MyProfileAvatarCellDelegate?

    init(imageUrl: String? = nil,
         delegate: MyProfileAvatarCellDelegate?) {
        self.value = imageUrl
        self.delegate = delegate
    }
}
