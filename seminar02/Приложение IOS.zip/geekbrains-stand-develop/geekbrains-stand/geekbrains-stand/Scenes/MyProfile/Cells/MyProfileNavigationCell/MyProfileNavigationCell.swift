//
//  MyProfileNavigationCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit
import PinLayout

enum MyProfileNavigationCellType {
    case subsribers, subscriptions, logout
}

final class MyProfileNavigationCell: UITableViewCell {

    // MARK: - Properties

    private let dateFormatter: DateFormatter = DateFormatter()
    private var viewModel: MyProfileNavigationCellViewModel?

    private let containerView: UIView = UIView()
    private var titleLabel: UILabel = UILabel()
    private let iconImageView: UIImageView = UIImageView()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        contentView.backgroundColor = Constants.backgroundColor

        iconImageView.tintColor = .UI.secondary.value

        containerView.addSubviews(titleLabel, iconImageView)
        addSubviews(containerView)
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        iconImageView.pin
            .centerRight()
            .size(Constants.IconImageView.size)

        titleLabel.pin
            .before(of: iconImageView)
            .left()
            .marginRight(Constants.TitleLabel.marginRight)
            .height(Constants.TitleLabel.height)
    }
}

// MARK: - Constants

private extension MyProfileNavigationCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 4, left: 20, bottom: 4, right: 12)
        }
        struct TitleLabel {
            static let marginRight: CGFloat = 8
            static let height: Percent = 100%
        }
        struct IconImageView {
            static let size: CGSize = CGSize(width: 10, height: 12)
        }
        static let backgroundColor: UIColor = .UI.card.value
    }
}

// MARK: - MyProfileTableViewCell

extension MyProfileNavigationCell: MyProfileTableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel) {
        guard let viewModel = viewModel as? MyProfileNavigationCellViewModel else {
            return
        }

        self.viewModel = viewModel
        titleLabel.attributedText = viewModel.title

        let image = UIImage(systemName: viewModel.image)?.withRenderingMode(.alwaysTemplate)
        iconImageView.image = image

        setNeedsLayout()
    }
}
