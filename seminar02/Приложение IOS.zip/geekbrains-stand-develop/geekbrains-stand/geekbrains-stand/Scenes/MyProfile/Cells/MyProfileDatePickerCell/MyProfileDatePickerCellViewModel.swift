//
//  MyProfileDatePickerCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit

final class MyProfileDatePickerCellViewModel: MyProfileTableViewCellViewModel {
    let type: MyProfileDatePickerCellType
    let title: NSAttributedString
    let placeholder: NSAttributedString
    let value: String?
    weak var delegate: MyProfileDatePickerCellDelegate?

    init(type: MyProfileDatePickerCellType,
         value: String? = nil,
         delegate: MyProfileDatePickerCellDelegate?) {
        self.type = type
        self.value = value
        self.delegate = delegate

        let title: String
        switch type {
        case .birthdate:
            title = "MyProfile_Date_Picker_Cell_Title_Birthdate".localized
        }
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)

        let placeholder: String
        switch type {
        case .birthdate:
            placeholder = "MyProfile_Date_Picker_Cell_Value_Placeholder".localized
        }
        self.placeholder = NSAttributedString(string: placeholder,
                                              attributes: Constants.placeholderAttributes)
    }
}

private extension MyProfileDatePickerCellViewModel {
    struct Constants {
        static let titleAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value]
        static let placeholderAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value]
    }
}
