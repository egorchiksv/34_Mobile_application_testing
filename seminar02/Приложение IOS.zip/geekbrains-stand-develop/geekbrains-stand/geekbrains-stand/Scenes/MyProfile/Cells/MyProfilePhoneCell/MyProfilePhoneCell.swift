//
//  MyProfilePhoneCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 28.10.2022.
//

import UIKit
import PinLayout
import SwiftPhoneNumberFormatter

protocol MyProfilePhoneCellDelegate: AnyObject {
    func didChangePhoneNumber(with value: String?)
}

final class MyProfilePhoneCell: UITableViewCell {

    // MARK: - Properties

    private var viewModel: MyProfilePhoneCellViewModel?

    private let containerView: UIView = UIView()
    private var titleLabel: UILabel = UILabel()
    private let phoneNumberTextField: PhoneFormattedTextField = PhoneFormattedTextField()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        selectionStyle = .none
        contentView.isUserInteractionEnabled = false
        contentView.backgroundColor = Constants.backgroundColor

        let phoneFormat = PhoneFormat(phoneFormat: Constants.PhoneNumberTextField.phoneFormat,
                                      regexp: Constants.PhoneNumberTextField.regexp)
        phoneNumberTextField.config.add(format: phoneFormat)
        phoneNumberTextField.prefix = Constants.PhoneNumberTextField.prefix

        phoneNumberTextField.delegate = self
        phoneNumberTextField.textDidChangeBlock = { [weak self] in
            self?.didChangePhoneNumberTextField($0)
        }

        containerView.addSubviews(titleLabel, phoneNumberTextField)
        addSubviews(containerView)
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        titleLabel.pin
            .left()
            .width(Constants.TitleLabel.width)
            .height(Constants.TitleLabel.height)

        phoneNumberTextField.pin
            .after(of: titleLabel)
            .right()
            .marginLeft(Constants.PhoneNumberTextField.marginLeft)
            .height(Constants.PhoneNumberTextField.height)
    }
}

// MARK: - Actions

private extension MyProfilePhoneCell {
    @objc
    func didChangePhoneNumberTextField(_ textField: UITextField?) {
        guard let phoneNumber = phoneNumberTextField.phoneNumber() else {
            return
        }

        let hasOnlyPrefix = phoneNumber.count == Constants.PhoneNumberTextField.prefixValue.count
        let phoneNumberValue = hasOnlyPrefix ? "" : phoneNumber

        viewModel?.delegate?.didChangePhoneNumber(with: phoneNumberValue)
    }
}

// MARK: - Constants

private extension MyProfilePhoneCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 4, left: 20, bottom: 4, right: 8)
        }
        struct TitleLabel {
            static let width: Percent = 40%
            static let height: Percent = 100%
        }
        struct PhoneNumberTextField {
            static let marginLeft: CGFloat = 8
            static let height: Percent = 100%

            static let prefixValue: String = "7"
            static let prefix: String = "+\(prefixValue) "
            static let phoneFormat: String = "(###) ###-##-##"
            static let regexp: String = "^[0-689]\\d*$"
        }
        static let backgroundColor: UIColor = .UI.card.value
    }
}

// MARK: - MyProfileTableViewCell

extension MyProfilePhoneCell: MyProfileTableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel) {
        guard let viewModel = viewModel as? MyProfilePhoneCellViewModel else {
            return
        }

        self.viewModel = viewModel
        titleLabel.attributedText = viewModel.title
        phoneNumberTextField.formattedText = formatPhoneNumber(with: viewModel.value)

        setNeedsLayout()
    }

    func formatPhoneNumber(with phoneNumber: String?) -> String? {
        guard let phoneNumber = phoneNumber else {
            return nil
        }

        let formatted = String(phoneNumber.dropFirst())

        return formatted
    }
}

// MARK: - UITextFieldDelegate

extension MyProfilePhoneCell: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()

        return false
    }
}
