//
//  MyProfileDatePickerCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 26.10.2022.
//

import UIKit
import PinLayout

enum MyProfileDatePickerCellType {
    case birthdate
}

protocol MyProfileDatePickerCellDelegate: AnyObject {
    func didChangeDate(for type: MyProfileDatePickerCellType, with value: Date?)
}

final class MyProfileDatePickerCell: UITableViewCell {

    // MARK: - Properties

    private let dateFormatter: DateFormatter = DateFormatter()
    private var viewModel: MyProfileDatePickerCellViewModel?

    private let containerView: UIView = UIView()
    private var titleLabel: UILabel = UILabel()
    private let dateTextField: UITextField = UITextField()

    // MARK: - Init

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        setup()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        selectionStyle = .none
        contentView.isUserInteractionEnabled = false
        contentView.backgroundColor = Constants.backgroundColor

        let datePicker: UIDatePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.maximumDate = Date()
        datePicker.addTarget(self, action: #selector(didChangeDatePicker), for: .valueChanged)

        dateTextField.delegate = self
        dateTextField.inputView = datePicker

        containerView.addSubviews(titleLabel, dateTextField)
        addSubviews(containerView)
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        titleLabel.pin
            .left()
            .width(Constants.TitleLabel.width)
            .height(Constants.TitleLabel.height)

        dateTextField.pin
            .after(of: titleLabel)
            .right()
            .marginLeft(Constants.DateTextField.marginLeft)
            .height(Constants.DateTextField.height)
    }
}

private extension MyProfileDatePickerCell {
    func formatDate(with value: Date) -> String {
        dateFormatter.dateFormat = "dd MMMM yyyy"

        return dateFormatter.string(from: value)
    }
}

// MARK: - Actions

private extension MyProfileDatePickerCell {
    @objc
    func didChangeDatePicker(_ datePicker: UIDatePicker) {
        guard let type = viewModel?.type else {
            return
        }

        let value: Date = datePicker.date
        dateTextField.text = formatDate(with: value)

        viewModel?.delegate?.didChangeDate(for: type, with: value)
    }
}

// MARK: - Constants

private extension MyProfileDatePickerCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 4, left: 20, bottom: 4, right: 8)
        }
        struct TitleLabel {
            static let width: Percent = 40%
            static let height: Percent = 100%
        }
        struct DateTextField {
            static let marginLeft: CGFloat = 8
            static let height: Percent = 100%
        }
        static let backgroundColor: UIColor = .UI.card.value
    }
}

// MARK: - MyProfileTableViewCell

extension MyProfileDatePickerCell: MyProfileTableViewCell {
    func configure(with viewModel: MyProfileTableViewCellViewModel) {
        guard let viewModel = viewModel as? MyProfileDatePickerCellViewModel else {
            return
        }

        self.viewModel = viewModel
        titleLabel.attributedText = viewModel.title
        dateTextField.text = viewModel.value
        dateTextField.attributedPlaceholder = viewModel.placeholder

        setNeedsLayout()
    }
}

// MARK: - UITextFieldDelegate

extension MyProfileDatePickerCell: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        fatalError("FATAL ERROR: error on editing birthday")
    }
}
