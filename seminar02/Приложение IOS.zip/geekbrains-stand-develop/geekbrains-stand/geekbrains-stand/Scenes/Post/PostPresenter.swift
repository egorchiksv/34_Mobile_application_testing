//
//  PostPresenter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import Foundation
import Domain

final class PostPresenter {
    weak var view: PostViewInput?
    weak var moduleOutput: PostModuleOutput?

    private let router: PostRouterInput
    private let interactor: PostInteractorInput
    private let identifier: Int

    private var post: FeedPost?
    private var author: String?
    private var isMyPost: Bool?

    init(router: PostRouterInput,
         interactor: PostInteractorInput,
         identifier: Int) {
        self.router = router
        self.interactor = interactor
        self.identifier = identifier
    }
}

private extension PostPresenter {
    func updateView() {
        guard
            let post = post,
            let author = author,
            let isMyPost = isMyPost
        else {
            return
        }

        view?.configure(with: PostViewModel(imageURL: post.mainImage.url,
                                            title: post.title,
                                            content: post.content,
                                            date: convertDate(with: post.createdDate),
                                            author: author,
                                            isMyPost: isMyPost))
    }
}

extension PostPresenter: PostModuleInput {
    func update(with post: FeedPost) {
        self.post = post
        updateView()
    }
}

extension PostPresenter: PostViewOutput {
    func didLoadView() {
        interactor.loadPost(for: identifier)
    }

    func didRequestToClose() {
        moduleOutput?.postModuleDidRequestToClose()
    }

    func didTapEditButton() {
        guard let post = post else {
            return
        }
        moduleOutput?.postModuleDidRequestToOpenEditPost(with: post)
    }

    func didTapRemoveButton() {
        view?.showActivity()
        interactor.removePost(for: identifier)
    }

}

extension PostPresenter: PostInteractorOutput {
    func didRecieve(post: FeedPost, author: String, isMyPost: Bool) {
        self.post = post
        self.author = author
        self.isMyPost = isMyPost
        updateView()
    }

    func didRecieve(error: Error) {
        view?.showHUD(with: error, completion: nil)
    }

    func didRemove(post: FeedPost) {
        moduleOutput?.postModuleDidRequestToClose()
    }
}

private extension PostPresenter {
    func convertDate(with value: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        let date = formatter.date(from: value)

        guard let date = date else {
            return String()
        }

        return "\(date.formatted(date: .abbreviated, time: .omitted))"
    }
}
