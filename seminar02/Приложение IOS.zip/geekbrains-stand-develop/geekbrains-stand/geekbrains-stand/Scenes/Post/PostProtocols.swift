//
//  PostProtocols.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import Foundation
import Domain

protocol PostModuleInput: AnyObject {
    var moduleOutput: PostModuleOutput? { get }

    func update(with post: FeedPost)
}

protocol PostModuleOutput: AnyObject {
    func postModuleDidRequestToClose()
    func postModuleDidRequestToOpenEditPost(with post: FeedPost)
}

protocol PostViewInput: HUDPresentable {
    func configure(with model: PostViewModel)
}

protocol PostViewOutput: AnyObject {
    func didLoadView()
    func didRequestToClose()
    func didTapEditButton()
    func didTapRemoveButton()
}

protocol PostInteractorInput: AnyObject {
    func loadPost(for postId: Int)
    func removePost(for postId: Int)
}

protocol PostInteractorOutput: AnyObject {
    func didRecieve(post: FeedPost, author: String, isMyPost: Bool)
    func didRecieve(error: Error)
    func didRemove(post: FeedPost)
}

protocol PostRouterInput: AnyObject {
}
