//
//  PostInteractor.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import Foundation
import Domain

final class PostInteractor {
    weak var output: PostInteractorOutput?

    private let postManager: PostManagerDescription
    private let userManager: UserManagerDescription
    private let authorizationManager: AuthorizationManagerDescription

    init(postManager: PostManagerDescription = PostManager.shared,
         userManager: UserManagerDescription = UserManager.shared,
         authorizationManager: AuthorizationManagerDescription = AuthorizationManager.shared) {
        self.postManager = postManager
        self.userManager = userManager
        self.authorizationManager = authorizationManager
    }
}

extension PostInteractor: PostInteractorInput {
    func loadPost(for postId: Int) {
        postManager.getPost(postId: postId) { [weak self] result in
            switch result {
            case .success(let post):
                self?.getUserName(with: post.authorId) { author in
                    let isMyPost = self?.authorizationManager.sessionInfo?.userId == String(post.authorId)
                    self?.output?.didRecieve(post: post, author: author, isMyPost: isMyPost)
                }
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }

    private func getUserName(with userId: Int, completion: @escaping ((String) -> Void)) {
        userManager.getProfile(userId: userId) { result in
            switch result {
            case .success(let user):
                completion(user.firstName + user.lastName)
            case .failure:
                completion(String())
            }
        }
    }

    func removePost(for postId: Int) {
        postManager.removePost(postId: postId) { [weak self] result in
            switch result {
            case .success(let post):
                self?.output?.didRemove(post: post)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }
}
