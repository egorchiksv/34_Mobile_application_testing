//
//  PostCoordinator.swift
//  geekbrains-stand
//
//  Created e.korotkiy on 13.11.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils
import Domain

struct PostFlowContext {
    let identifier: Int
}

final class PostCoordinator: Coordinator {

    // MARK: - Private properties

    private let flowContext: PostFlowContext
    private weak var navigationController: UINavigationController?

    private(set) weak var moduleInput: PostModuleInput?

    private var createPostCoordinator: CreatePostCoordinator?

    // MARK: - Public properties

    var onClose: (() -> Void)?

    // MARK: - Init

    init(navigationController: UINavigationController?, flowContext: PostFlowContext) {
        self.navigationController = navigationController
        self.flowContext = flowContext
        super.init()
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)

        let context = PostContext(identifier: flowContext.identifier, moduleOutput: self)
        let container = PostContainer.assemble(with: context)
        moduleInput = container.input
        let viewController = container.viewController
        viewController.modalPresentationStyle = .fullScreen
        viewController.hidesBottomBarWhenPushed = true

        navigationController?.pushViewController(viewController, animated: true)
    }

    override func finish() {
        super.finish()

        navigationController?.popViewController(animated: true)
    }
}

extension PostCoordinator: PostModuleOutput {
    func postModuleDidRequestToOpenEditPost(with post: FeedPost) {
        guard let navigationController = navigationController else {
            return
        }

        let flowContext = CreatePostFlowContext(type: .editByPost(post: post))
        createPostCoordinator = CreatePostCoordinator(sourceViewController: navigationController,
                                                      interactor: CreatePostCoordinatorInteractor(),
                                                      flowContext: flowContext)
        createPostCoordinator?.onClose = { [weak self] in
            self?.createPostCoordinator?.finish()
            self?.createPostCoordinator = nil
        }
        createPostCoordinator?.onEditSuccessfully = { [weak self] post in
            self?.moduleInput?.update(with: post)
        }
        createPostCoordinator?.start(in: self)
    }

    func postModuleDidRequestToClose() {
        onClose?()
    }
}
