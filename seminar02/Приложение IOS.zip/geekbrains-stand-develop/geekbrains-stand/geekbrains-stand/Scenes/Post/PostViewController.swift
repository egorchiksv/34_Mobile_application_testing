//
//  PostViewController.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import UIKit

final class PostViewController: UIViewController {

    // MARK: - Private properties

    private let containerScrollView: UIScrollView = UIScrollView()
    private let imageView: UIImageView = UIImageView()
    private let titleLabel: UILabel = UILabel()
    private let contentLabel: UILabel = UILabel()
    private let dateLabel: UILabel = UILabel()
    private let authorLabel: UILabel = UILabel()
    private let favouriteView: UIView = UIView()
    private let favouriteImageView: UIImageView = UIImageView()

    private var isFavourite: Bool = false

    private let output: PostViewOutput

    // MARK: - Init

    init(output: PostViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        output.didLoadView()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        guard isMovingToParent else {
            return
        }

        didTapNavigationBarBackButton()
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        output.didRequestToClose()
    }

    // MARK: - Setup

    private func setup() {
        view.backgroundColor = Constants.backgroundColor

        imageView.contentMode = .scaleAspectFill
        imageView.tintColor = Constants.ImageView.tintColor
        imageView.backgroundColor = Constants.ImageView.backgroundColor
        imageView.layer.masksToBounds = true

        titleLabel.numberOfLines = 2
        contentLabel.numberOfLines = 0

        favouriteView.backgroundColor = .UI.backgroundGray.value.withAlphaComponent(0.8)
        favouriteView.layer.cornerRadius = Constants.FavouriteView.size.height / 2

        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(didTapFavourite))
        favouriteImageView.isUserInteractionEnabled = true
        favouriteImageView.addGestureRecognizer(tapRecognizer)
        favouriteImageView.tintColor = .systemPink
        favouriteImageView.contentMode = .scaleAspectFit
        favouriteImageView.layer.cornerRadius = Constants.FavouriteImageView.size.height / 2

        favouriteView.addSubview(favouriteImageView)
        containerScrollView.addSubviews(imageView,
                                        titleLabel,
                                        contentLabel,
                                        dateLabel,
                                        authorLabel,
                                        favouriteView)
        view.addSubviews(containerScrollView)
    }

    // MARK: - Configure

    private func configureNavBar(with shouldShowEditButton: Bool) {
        title = "Post_Title".localized

        if shouldShowEditButton {
            navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "ellipsis"),
                                                                style: .plain,
                                                                target: self,
                                                                action: #selector(didTapEditButton))
        }
    }

    // MARK: - Layout

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        containerScrollView.pin
            .top()
            .horizontally()
            .bottom(view.safeAreaInsets.bottom)

        imageView.pin
            .top()
            .hCenter()
            .size(CGSize(width: view.frame.width, height: view.frame.height / 3))

        favouriteView.pin
            .below(of: imageView)
            .marginTop(-(Constants.FavouriteView.size.height / 2))
            .right(Constants.FavouriteView.marginRight)
            .size(Constants.FavouriteView.size)

        favouriteImageView.pin
            .center()
            .size(Constants.FavouriteImageView.size)

        if !titleLabel.isHidden {
            titleLabel.pin
                .below(of: imageView)
                .marginTop(Constants.TitleLabel.marginTop)
                .horizontally(Constants.TitleLabel.marginHorizontally)
                .sizeToFit(.width)
        }

        let contextLabelTopEdge = titleLabel.isHidden ? imageView.edge.bottom : titleLabel.edge.bottom

        contentLabel.pin
            .top(to: contextLabelTopEdge)
            .marginTop(Constants.ContentLabel.marginTop)
            .horizontally(Constants.ContentLabel.marginHorizontally)
            .sizeToFit(.width)

        dateLabel.pin
            .below(of: contentLabel)
            .marginTop(Constants.DateLabel.marginTop)
            .horizontally(Constants.DateLabel.marginHorizontally)
            .sizeToFit(.width)

        authorLabel.pin
            .below(of: dateLabel)
            .marginTop(Constants.AuthorLabel.marginTop)
            .horizontally(Constants.AuthorLabel.marginHorizontally)
            .sizeToFit(.width)

        containerScrollView.contentSize = CGSize(width: view.frame.width,
                                                 height: authorLabel.frame.maxY)
    }

    // MARK: - Actions

    private func didTapNavigationBarBackButton() {
        output.didRequestToClose()
    }

    @objc
    private func didTapEditButton() {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let editAction = UIAlertAction(title: "Post_Action_Edit_Title".localized,
                                       style: .default,
                                       handler: { [weak self] _ in
            self?.output.didTapEditButton()
        })
        let removeAction = UIAlertAction(title: "Post_Action_Remove_Title".localized,
                                         style: .destructive,
                                         handler: { [weak self] _ in
            self?.didTapRemoveButton()
        })
        let cancelAction = UIAlertAction(title: "Post_Action_Cancel_Title".localized,
                                         style: .cancel)

        [editAction, removeAction, cancelAction].forEach {
            alert.addAction($0)
        }

        alert.popoverPresentationController?.sourceView = view
        alert.popoverPresentationController?.sourceRect = view.bounds
        alert.popoverPresentationController?.permittedArrowDirections = []

        present(alert, animated: true, completion: nil)
    }

    func didTapRemoveButton() {
        let alert = UIAlertController(title: "Post_Alert_Remove_Title".localized,
                                      message: nil,
                                      preferredStyle: .alert)

        let removeAction = UIAlertAction(title: "Post_Action_Remove_Title_Short".localized,
                                         style: .destructive,
                                         handler: { [weak self] _ in
            self?.output.didTapRemoveButton()
        })
        let cancelAction = UIAlertAction(title: "Post_Action_Cancel_Title".localized,
                                         style: .cancel)

        [removeAction, cancelAction].forEach {
            alert.addAction($0)
        }

        present(alert, animated: true, completion: nil)
    }

    @objc
    func didTapFavourite() {
        isFavourite = !isFavourite
        changeFavouriteState(with: isFavourite)
    }

    // MARK: - Flow

    private func changeFavouriteState(with isFavourite: Bool) {
        favouriteImageView.image = isFavourite ? UIImage(systemName: "heart.fill") : UIImage(systemName: "heart")
    }
}

// MARK: - View input

extension PostViewController: PostViewInput {
    func configure(with model: PostViewModel) {
        if let imageURL = model.imageURL {
            let image = UIImage(systemName: "photo.on.rectangle.angled")?.withRenderingMode(.alwaysTemplate)

            imageView.setImage(from: imageURL, placeholderImage: image)
        }

        titleLabel.attributedText = model.title
        contentLabel.attributedText = model.content
        dateLabel.attributedText = model.date
        authorLabel.attributedText = model.author

        titleLabel.isHidden = !model.shouldShowTitle
        contentLabel.isHidden = !model.shouldShowContent

        isFavourite = model.isFavourite

        changeFavouriteState(with: model.isFavourite)

        configureNavBar(with: model.shouldShowEditButton)

        view.setNeedsLayout()
    }
}

// MARK: - Constants

private extension PostViewController {
    struct Constants {
        static let backgroundColor: UIColor = .background

        struct ImageView {
            static let backgroundColor: UIColor = .UI.secondary.value
            static let tintColor: UIColor = .UI.card.value
        }

        struct FavouriteView {
            static let size: CGSize = CGSize(width: 60, height: 60)
            static let marginRight: CGFloat = 20
        }

        struct FavouriteImageView {
            static let size: CGSize = CGSize(width: 36, height: 36)
        }

        struct TitleLabel {
            static let marginTop: CGFloat = 24
            static let marginHorizontally: CGFloat = 16
        }

        struct ContentLabel {
            static let marginTop: CGFloat = 22
            static let marginHorizontally: CGFloat = 16
        }

        struct DateLabel {
            static let marginTop: CGFloat = 16
            static let marginHorizontally: CGFloat = 16
        }

        struct AuthorLabel {
            static let marginTop: CGFloat = 4
            static let marginHorizontally: CGFloat = 16
        }
    }
}
