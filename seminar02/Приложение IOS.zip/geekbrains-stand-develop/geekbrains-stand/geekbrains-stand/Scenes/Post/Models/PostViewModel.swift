//
//  PostViewModel.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//

import UIKit

struct PostViewModel {
    let imageURL: String?
    let title: NSAttributedString
    let content: NSAttributedString
    var date: NSAttributedString
    let author: NSAttributedString
    let isFavourite: Bool
    let shouldShowEditButton: Bool
    let shouldShowTitle: Bool
    let shouldShowContent: Bool

    init(imageURL: String, title: String, content: String, date: String, author: String, isMyPost: Bool, isFavourite: Bool = false) {
        self.imageURL = imageURL.replacingOccurrences(of: "http://", with: "https://")
        self.title = NSAttributedString(string: title, attributes: Constants.titleStyleAttributes)
        self.content = NSAttributedString(string: content, attributes: Constants.contentAttributes)
        let dateText = "Post_Date_Title".localized + " " + (date.isEmpty ? "-" : date)
        self.date = NSAttributedString(string: dateText, attributes: Constants.dateAttributes)
        let authorText = "Post_Author_Title".localized + " " + (author.isEmpty ? "-" : author)
        self.author = NSAttributedString(string: authorText, attributes: Constants.authorAttributes)
        self.isFavourite = isFavourite
        self.shouldShowEditButton = isMyPost
        self.shouldShowTitle = !title.isEmpty
        self.shouldShowContent = !content.isEmpty
    }
}

private extension PostViewModel {
    struct Constants {
        static let titleStyleAttributes: [NSAttributedString.Key: Any] = {
            let font = UIFont.systemFont(ofSize: 24, weight: .bold)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.firstLineHeadIndent = 8

            let style: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: UIColor.Text.primary.value,
                .paragraphStyle: paragraphStyle
            ]

            return style
        }()

        static let contentAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.Text.primary.value,
            .font: UIFont.systemFont(ofSize: 18, weight: .regular)
        ]
        static let dateAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.Text.secondary.value,
            .font: UIFont.systemFont(ofSize: 16, weight: .regular)
        ]
        static let authorAttributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: UIColor.Text.secondary.value,
            .font: UIFont.systemFont(ofSize: 16, weight: .regular)
        ]
    }
}
