//
//  PostRouter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import UIKit

final class PostRouter {
}

extension PostRouter: PostRouterInput {
}
