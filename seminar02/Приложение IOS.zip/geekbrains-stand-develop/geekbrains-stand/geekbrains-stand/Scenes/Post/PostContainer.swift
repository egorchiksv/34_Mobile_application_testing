//
//  PostContainer.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 13.11.2022.
//  
//

import UIKit

final class PostContainer {
    let input: PostModuleInput
    let viewController: UIViewController
    private(set) weak var router: PostRouterInput!

    class func assemble(with context: PostContext) -> PostContainer {
        let router = PostRouter()
        let interactor = PostInteractor()
        let presenter = PostPresenter(router: router,
                                      interactor: interactor,
                                      identifier: context.identifier)
        let viewController = PostViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return PostContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UIViewController, input: PostModuleInput, router: PostRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct PostContext {
    let identifier: Int
    weak var moduleOutput: PostModuleOutput?
}
