//
//  FeedPresenter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation
import Domain

final class FeedPresenter {
    weak var view: FeedViewInput?
    weak var moduleOutput: FeedModuleOutput?

    private let dataSource: FeedDataSource
    private let router: FeedRouterInput
    private let interactor: FeedInteractorInput
    private let cursor: FeedCursor

    init(dataSource: FeedDataSource,
         router: FeedRouterInput,
         interactor: FeedInteractorInput,
         cursor: FeedCursor) {
        self.dataSource = dataSource
        self.router = router
        self.interactor = interactor
        self.cursor = cursor
    }
}

extension FeedPresenter: FeedModuleInput {
    func scrollToTop() {
        view?.scrollToTop()
    }

    func didChange(configuration: FeedConfiguration) {
        let shouldReloadContent = configuration.shouldUpdateAll(oldConfiguration: interactor.configuration)

        interactor.configuration = configuration

        dataSource.input.style = configuration.style

        if shouldReloadContent {
            view?.showActivity()
            initialLoad()
        } else {
            view?.reloadData()
        }
    }
}

extension FeedPresenter: FeedViewOutput {

    func didLoadView() {
        dataSource.output = self
        view?.setup(with: dataSource)

        view?.showActivity()
        initialLoad()
    }

    func viewWillDisplayViewModel(at index: Int) {
        guard
            interactor.canLoadNext(with: cursor),
            index == (dataSource.input.items.count - 1)
        else {
            return
        }

        interactor.loadFeed(with: cursor)
    }

    func didPullToRefresh() {
        initialLoad()
    }

    func didTapFilterButton() {
        guard let copyConfiguration = interactor.configuration.copy() as? FeedConfiguration else {
            return
        }

        moduleOutput?.feedModuleDidRequestToOpenFilters(with: copyConfiguration)
    }
}

private extension FeedPresenter {
    func initialLoad() {
        cursor.reset()

        interactor.loadFeed(with: cursor)
    }
}

private extension FeedPresenter {
    func mergeItems(with items: [FeedListItemType], shouldClear: Bool) {
        if shouldClear {
            dataSource.input.items = []
        }

        dataSource.input.items.append(contentsOf: items)

        view?.reloadData()
    }
}

extension FeedPresenter: FeedInteractorOutput {
    func didRecieve(listItems: [FeedListItemType], meta: FeedMeta) {
        view?.hideActivity()
        view?.endRefreshing()

        mergeItems(with: listItems, shouldClear: cursor.isFirstPage)

        cursor.update(with: meta)
    }

    func didRecieve(error: Error) {
        view?.hideActivity()
        view?.endRefreshing()

        view?.showHUD(with: error, completion: nil)
    }
}

extension FeedPresenter: FeedPostSectionControllerOutput {

    func didTapPost(with identifier: Int) {
        moduleOutput?.feedModuleDidRequestToOpenPost(with: identifier)
    }
}
