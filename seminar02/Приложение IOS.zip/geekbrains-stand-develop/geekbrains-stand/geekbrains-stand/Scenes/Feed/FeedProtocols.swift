//
//  FeedProtocols.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation
import Domain

protocol FeedModuleInput: AnyObject {
    var moduleOutput: FeedModuleOutput? { get }

    func scrollToTop()
    func didChange(configuration: FeedConfiguration)
}

protocol FeedModuleOutput: AnyObject {
    func feedModuleDidRequestToOpenPost(with identifier: Int)
    func feedModuleDidRequestToOpenFilters(with configuration: FeedConfiguration)
}

protocol FeedViewInput: HUDPresentable {
    func setup(with dataSource: FeedDataSource)
    func scrollToTop()
    func reloadData()
    func endRefreshing()
}

protocol FeedViewOutput: AnyObject {
    func didLoadView()
    func viewWillDisplayViewModel(at index: Int)
    func didPullToRefresh()
    func didTapFilterButton()
}

protocol FeedInteractorInput: AnyObject {
    func loadFeed(with cursor: FeedCursor)
    func canLoadNext(with cursor: FeedCursor) -> Bool

    var configuration: FeedConfiguration { get set }
}

protocol FeedInteractorOutput: AnyObject {
    func didRecieve(listItems: [FeedListItemType], meta: FeedMeta)
    func didRecieve(error: Error)
}

protocol FeedRouterInput: AnyObject {
}
