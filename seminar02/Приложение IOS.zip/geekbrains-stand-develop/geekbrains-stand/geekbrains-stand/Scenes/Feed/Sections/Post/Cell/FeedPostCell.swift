//
//  FeedPostCell.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import UIKit

final class FeedPostCell: UICollectionViewCell {
    private let imageView: UIImageView = UIImageView()
    private let containerView: UIView = UIView()
    private let titleLabel: UILabel = UILabel()
    private let descriptionLabel: UILabel = UILabel()
    private let bottomSpacerView: UIView = UIView()

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override init(frame: CGRect) {
        super.init(frame: frame)

        setup()
    }

    private func setup() {
        containerView.layer.cornerRadius = Constants.ContainerView.cornerRadius
        containerView.backgroundColor = Constants.ContainerView.backgroundColor
        containerView.layer.masksToBounds = true

        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true

        titleLabel.numberOfLines = 0
        descriptionLabel.numberOfLines = 4

        containerView.addSubviews(imageView, titleLabel, descriptionLabel, bottomSpacerView)
        contentView.addSubview(containerView)
    }

    func configure(with viewModel: FeedPostCellViewModel, shouldLoadImage: Bool = true) {
        titleLabel.attributedText = viewModel.title
        descriptionLabel.attributedText = viewModel.description

        guard shouldLoadImage else {
            return
        }

        if let imageURL = viewModel.imageURL {
            let image = UIImage(named: "placeholder")
            imageView.setImage(from: imageURL, placeholderImage: image)
        } else {
            imageView.image = UIImage(named: "placeholder")
        }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        performLayout()
    }

    func performLayout() {
        containerView.pin
            .top()
            .horizontally(Constants.ContainerView.marginHorizontally)

        imageView.pin
            .top()
            .horizontally()
            .height(Constants.ImageView.height)

        titleLabel.pin
            .below(of: imageView)
            .marginTop(Constants.TitleLabel.marginTop)
            .horizontally(Constants.TitleLabel.marginHorizontally)
            .sizeToFit(.width)

        descriptionLabel.pin
            .below(of: titleLabel)
            .marginTop(Constants.DescriptionLabel.marginTop)
            .horizontally(Constants.DescriptionLabel.marginHorizontally)
            .sizeToFit(.width)

        bottomSpacerView.pin
            .below(of: descriptionLabel)
            .horizontally()
            .height(Constants.BottomSpacerView.height)

        containerView.pin
            .wrapContent(.vertically)
    }

    override func sizeThatFits(_ size: CGSize) -> CGSize {
        return containerView.autoSizeThatFits(size, layoutClosure: performLayout)
    }

    class func cellSize(for width: CGFloat, model: FeedPostCellViewModel) -> CGSize {
        let view = FeedPostCell()
        view.configure(with: model, shouldLoadImage: false)

        return view.sizeThatFits(CGSize(width: width, height: CGFloat.greatestFiniteMagnitude))
    }
}

// MARK: - Constants

private extension FeedPostCell {
    struct Constants {

        struct ContainerView {
            static let marginHorizontally: CGFloat = 8
            static let cornerRadius: CGFloat = 8
            static let backgroundColor: UIColor = .UI.backgroundCard.value
        }

        struct ImageView {
            static let height: CGFloat = 174
        }

        struct TitleLabel {
            static let marginHorizontally: CGFloat = 8
            static let marginTop: CGFloat = 8
        }

        struct DescriptionLabel {
            static let marginHorizontally: CGFloat = 8
            static let marginTop: CGFloat = 4
        }

        struct BottomSpacerView {
            static let height: CGFloat = 8
        }
    }
}
