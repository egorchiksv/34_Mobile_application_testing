//
//  FeedPostSectionModel.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import IGListKit
import Domain

final class FeedPostSectionModel {
    let post: FeedPostCellViewModel
    let style: FeedStyle

    init(post: FeedPostCellViewModel, style: FeedStyle) {
        self.post = post
        self.style = style
    }
}

extension FeedPostSectionModel: Hashable {
    static func == (lhs: FeedPostSectionModel, rhs: FeedPostSectionModel) -> Bool {
        return lhs.hashValue == rhs.hashValue
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(post.hashValue)
        hasher.combine(style)
    }
}

extension FeedPostSectionModel: ListDiffable {

    func diffIdentifier() -> NSObjectProtocol {
        return String(describing: Self.Type.self) + "." + "\(post.id)" as NSString
    }

    func isEqual(toDiffableObject object: ListDiffable?) -> Bool {
        guard let object = object as? FeedPostSectionModel else {
            return false
        }

        return object == self
    }
}
