//
//  FeedPostSectionController.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import IGListKit

protocol FeedPostSectionControllerOutput: AnyObject {
    func didTapPost(with identifier: Int)
}

final class FeedPostSectionController: ListSectionController {

    private var object: FeedPostSectionModel?

    private weak var output: FeedPostSectionControllerOutput?

    init(output: FeedPostSectionControllerOutput?) {
        self.output = output
        super.init()

        inset.top = Constants.insetTop
        minimumLineSpacing = Constants.minimumLineSpacing
    }

    override func sizeForItem(at index: Int) -> CGSize {
        guard let context = collectionContext, let object = object else {
            return .zero
        }

        let numberOfItemsInRow: CGFloat

        switch object.style {
        case .grid:
            numberOfItemsInRow = 2.0
        case .list:
            numberOfItemsInRow = 1.0
        case .long:
            numberOfItemsInRow = 1.0
        }

        let width = context.containerSize.width / numberOfItemsInRow

        switch object.style {
        case .grid, .list:
            return FeedPostCell.cellSize(for: width, model: object.post)
        case .long:
            return FeedPostLongCell.cellSize(for: width, model: object.post)
        }
    }

    override func cellForItem(at index: Int) -> UICollectionViewCell {
        guard
            let context = collectionContext,
            let object = object
        else {
            return UICollectionViewCell()
        }

        switch object.style {
        case .list, .grid:
            return dequeueStandardCell(at: index, context: context, object: object)
        case .long:
            return dequeueLongCell(at: index, context: context, object: object)
        }
    }

    private func dequeueStandardCell(at index: Int,
                                     context: ListCollectionContext,
                                     object: FeedPostSectionModel) -> UICollectionViewCell {

        let cell = context.dequeueReusableCell(of: FeedPostCell.self,
                                               for: self,
                                               at: index) as? FeedPostCell

        cell?.configure(with: object.post)

        return cell ?? UICollectionViewCell()
    }

    private func dequeueLongCell(at index: Int,
                                 context: ListCollectionContext,
                                 object: FeedPostSectionModel) -> UICollectionViewCell {

        let cell = context.dequeueReusableCell(of: FeedPostLongCell.self,
                                               for: self,
                                               at: index) as? FeedPostLongCell

        cell?.configure(with: object.post)

        return cell ?? UICollectionViewCell()
    }

    override func didUpdate(to object: Any) {
        self.object = object as? FeedPostSectionModel
    }

    override func didSelectItem(at index: Int) {
        guard let post = object?.post else {
            return
        }

        output?.didTapPost(with: post.id)
    }

    private struct Constants {
        static let insetTop: CGFloat = 16
        static let minimumLineSpacing: CGFloat = 12
    }
}
