//
//  FeedPostCellViewModel.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import Domain
import UIKit

struct FeedPostCellViewModel {

    let id: Int
    let title: NSAttributedString
    let description: NSAttributedString
    let imageURL: String?

    init(id: Int,
         title: String,
         description: String,
         imageURL: String?) {
        self.id = id
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)
        self.description = NSAttributedString(string: description, attributes: Constants.descriptionAttributes)
        self.imageURL = imageURL?.replacingOccurrences(of: "http://", with: "https://")
    }
}

private extension FeedPostCellViewModel {

    struct Constants {
        static let titleAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17, weight: .bold)
        ]

        static let descriptionAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15, weight: .regular)
        ]
    }
}

extension FeedPostCellViewModel: Hashable {
     func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(title)
        hasher.combine(description)
        hasher.combine(imageURL)
    }
}
