//
//  FeedInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation
import Domain

final class FeedInteractor {
    weak var output: FeedInteractorOutput?

    private let postManager: PostManagerDescription
    private let converter: FeedItemsConverterDescription

    private var isLoading: Bool = false

    var configuration: FeedConfiguration

    init(postManager: PostManagerDescription,
         converter: FeedItemsConverterDescription,
         configuration: FeedConfiguration) {
        self.postManager = postManager
        self.converter = converter
        self.configuration = configuration
    }
}

extension FeedInteractor: FeedInteractorInput {

    func loadFeed(with cursor: FeedCursor) {
        isLoading = true

        postManager.getFeed(page: cursor.page,
                            limit: cursor.limit,
                            sort: .createdDate,
                            order: configuration.order,
                            owner: .otherUser) { [weak self] result in
            guard let self = self else {
                return
            }

            switch result {
            case .success(let feed):
                let listItems = self.converter.convert(feed: feed)
                self.output?.didRecieve(listItems: listItems, meta: feed.meta)
            case .failure(let error):
                self.output?.didRecieve(error: error)
            }

            self.isLoading = false
        }
    }

    func canLoadNext(with cursor: FeedCursor) -> Bool {
        return cursor.canRequestNext && !isLoading
    }
}
