//
//  FeedContainer.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit

final class FeedContainer {
    let input: FeedModuleInput
    let viewController: UIViewController
    private(set) weak var router: FeedRouterInput!

    class func assemble(with context: FeedContext) -> FeedContainer {
        let router = FeedRouter()
        let interactor = FeedInteractor(postManager: PostManager.shared,
                                        converter: FeedItemsConverter(),
                                        configuration: context.configuration)
        let dataSource = FeedDataSource(input: FeedDataSourceInput(items: [], style: context.configuration.style))
        let cursor = FeedCursor()
        let presenter = FeedPresenter(dataSource: dataSource,
                                      router: router,
                                      interactor: interactor,
                                      cursor: cursor)
        let viewController = FeedViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return FeedContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UIViewController, input: FeedModuleInput, router: FeedRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct FeedContext {
    weak var moduleOutput: FeedModuleOutput?
    let configuration: FeedConfiguration
}
