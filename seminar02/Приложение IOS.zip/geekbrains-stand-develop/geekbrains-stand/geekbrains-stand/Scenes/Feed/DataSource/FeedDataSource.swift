//
//  FeedDataSource.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import IGListKit

final class FeedDataSource: NSObject {
    var input: FeedDataSourceInput

    weak var output: (FeedPostSectionControllerOutput)?

    init(input: FeedDataSourceInput) {
        self.input = input
    }
}

extension FeedDataSource: ListAdapterDataSource {
    func objects(for listAdapter: ListAdapter) -> [ListDiffable] {
        let builder: FeedViewModelsBuilder = FeedDefaultViewModelsBuilder()

        return builder.build(with: input)
    }

    func listAdapter(_ listAdapter: ListAdapter, sectionControllerFor object: Any) -> ListSectionController {
        if object is FeedPostSectionModel {
            return FeedPostSectionController(output: output)
        } else {
            return ListSectionController()
        }
    }

    func emptyView(for listAdapter: ListAdapter) -> UIView? {
        return nil
    }
}
