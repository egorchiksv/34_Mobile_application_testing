//
//  FeedViewModelsBuilder.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import IGListKit

protocol FeedViewModelsBuilder {
    func build(with input: FeedDataSourceInput) -> [ListDiffable]
}

final class FeedDefaultViewModelsBuilder: FeedViewModelsBuilder {
    private let factory = FeedSectionModelFactory()

    func build(with input: FeedDataSourceInput) -> [ListDiffable] {
        return input.items.map { listItem in
            switch listItem {
            case .post(let post):
                return factory.make(section: .post(post: post), input: input)
            }
        }
    }
}
