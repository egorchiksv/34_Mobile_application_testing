//
//  FeedDataSourceInput.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import Domain

enum FeedListItemType {
    case post(FeedPost)
}

final class FeedDataSourceInput {
    var items: [FeedListItemType] = []
    var style: FeedStyle

    init(items: [FeedListItemType], style: FeedStyle) {
        self.items = items
        self.style = style
    }
}

enum FeedStyle {
    case list
    case grid
    case long
}
