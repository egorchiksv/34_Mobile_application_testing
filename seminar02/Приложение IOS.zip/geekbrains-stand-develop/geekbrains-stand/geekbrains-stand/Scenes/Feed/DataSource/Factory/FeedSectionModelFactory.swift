//
//  FeedSectionModelFactory.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import Domain
import IGListKit

final class FeedSectionModelFactory {
    enum FeedSectionType {
        case post(post: FeedPost)
    }

    func make(section: FeedSectionType, input: FeedDataSourceInput) -> ListDiffable {
        switch section {
        case .post(let post):
            return postSection(with: input, post: post)
        }
    }
}

private extension FeedSectionModelFactory {

    func postSection(with input: FeedDataSourceInput, post: FeedPost) -> ListDiffable {
        let post = FeedPostCellViewModel(id: post.id,
                                         title: post.title,
                                         description: post.description,
                                         imageURL: post.mainImage.url)

        return FeedPostSectionModel(post: post, style: input.style)
    }
}
