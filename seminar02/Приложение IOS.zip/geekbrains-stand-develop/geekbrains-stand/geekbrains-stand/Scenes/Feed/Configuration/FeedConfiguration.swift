//
//  FeedConfiguration.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//

import Foundation
import Domain

final class FeedConfiguration: NSObject, NSCopying {
    var style: FeedStyle
    var order: FeedOrder

    init(style: FeedStyle, order: FeedOrder) {
        self.style = style
        self.order = order

        super.init()
    }

    func shouldUpdateAll(oldConfiguration: FeedConfiguration) -> Bool {
        return self.order != oldConfiguration.order
    }

    func copy(with zone: NSZone? = nil) -> Any {
        let copy = FeedConfiguration(style: style, order: order)
        return copy
    }

    static let `default`: FeedConfiguration = FeedConfiguration(style: .list, order: .desc)
}
