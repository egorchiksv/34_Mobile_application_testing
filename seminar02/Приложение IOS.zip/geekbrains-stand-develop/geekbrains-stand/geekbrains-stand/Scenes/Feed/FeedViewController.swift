//
//  FeedViewController.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit
import IGListKit

final class FeedViewController: UIViewController {
    private let output: FeedViewOutput

    private lazy var collectionView: UICollectionView = {
        let layout = ListCollectionViewLayout(stickyHeaders: false, topContentInset: 0, stretchToEdge: false)

        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }()

    private lazy var adapter: ListAdapter = {
        return ListAdapter(updater: ListAdapterUpdater(),
                           viewController: self)
    }()

    private let refreshControl: UIRefreshControl = UIRefreshControl()

    init(output: FeedViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavbar()
        setup()
        output.didLoadView()
    }

    private func setupNavbar() {
        navigationItem.title = "Feed_Title".localized
        navigationItem.backButtonDisplayMode = .minimal

        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Feed_Filters_Title".localized,
                                                            style: .plain,
                                                            target: self,
                                                            action: #selector(didTapFilterButton))
    }

    private func setup() {
        view.backgroundColor = Constants.ContainerView.backgroundColor

        refreshControl.addTarget(self, action: #selector(didPullToRefresh), for: .valueChanged)

        collectionView.backgroundColor = Constants.CollectionView.backgroundColor
        collectionView.contentInset = Constants.CollectionView.contentInset
        collectionView.refreshControl = refreshControl

        adapter.delegate = self

        view.addSubview(collectionView)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        collectionView.pin
            .top(view.safeAreaInsets.top)
            .horizontally()
            .bottom()
    }
}

private extension FeedViewController {

    @objc
    func didPullToRefresh() {
        output.didPullToRefresh()
    }

    @objc
    func didTapFilterButton() {
        output.didTapFilterButton()
    }
}

extension FeedViewController: FeedViewInput {

    func setup(with dataSource: FeedDataSource) {
        adapter.collectionView = collectionView
        adapter.dataSource = dataSource
    }

    func scrollToTop() {
        collectionView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
    }

    func reloadData() {
        adapter.performUpdates(animated: true, completion: nil)
    }

    func endRefreshing() {
        refreshControl.endRefreshing()
    }
}

extension FeedViewController: ListAdapterDelegate {

    func listAdapter(_ listAdapter: ListAdapter, didEndDisplaying object: Any, at index: Int) {

    }

    func listAdapter(_ listAdapter: ListAdapter, willDisplay object: Any, at index: Int) {
        output.viewWillDisplayViewModel(at: index)
    }
}

// MARK: - Constants

private extension FeedViewController {

    struct Constants {
        struct ContainerView {
            static let backgroundColor: UIColor = .background
        }

        struct CollectionView {
            static let backgroundColor: UIColor = .UI.backgroundGray.value
            static let contentInset: UIEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 12, right: 0)
        }
    }
}
