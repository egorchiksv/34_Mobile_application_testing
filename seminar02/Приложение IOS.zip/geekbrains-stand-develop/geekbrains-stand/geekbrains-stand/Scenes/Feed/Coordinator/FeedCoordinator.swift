//
//  FeedCoordinator.swift
//  geekbrains-stand
//
//  Created k.kulakov on 19.10.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils

struct FeedFlowContext {

}

final class FeedCoordinator: Coordinator {

    // MARK: - Coordinators

    private var postCoordinator: PostCoordinator?

    // MARK: - Private properties

    private let flowContext: FeedFlowContext

    private weak var navigationController: UINavigationController?
    private(set) var mainViewController: UIViewController?
    private var filterViewController: UIViewController?

    private(set) weak var moduleInput: FeedModuleInput?

    // MARK: - Init

    init(navigationController: UINavigationController?, flowContext: FeedFlowContext) {
        self.flowContext = flowContext

        super.init()

        let context = FeedContext(moduleOutput: self, configuration: .default)
        let container = FeedContainer.assemble(with: context)

        // в будущем разделю на 2 координатора
        if navigationController == nil {
            mainViewController = UINavigationController(rootViewController: container.viewController)
            self.navigationController = mainViewController as? UINavigationController
        } else {
            self.navigationController = navigationController
            mainViewController = container.viewController
        }

        moduleInput = container.input
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)

    }

    override func finish() {
        super.finish()

        postCoordinator = nil
    }

    // MARK: - Router

    private func showPost(with identifier: Int) {
        let flowContext = PostFlowContext(identifier: identifier)
        postCoordinator = PostCoordinator(navigationController: navigationController, flowContext: flowContext)
        postCoordinator?.onClose = {
            [weak self] in
            self?.postCoordinator?.finish()
            self?.postCoordinator = nil
        }

        postCoordinator?.start(in: self)
    }

    private func showFilters(with configuration: FeedConfiguration) {
        let flowContext = FeedFilterContext(configuration: configuration, moduleOutput: self)
        let container = FeedFilterContainer.assemble(with: flowContext)

        let viewController = container.viewController
        filterViewController = viewController

        let navigationController = UINavigationController(rootViewController: viewController)

        self.navigationController?.present(navigationController, animated: true)
    }
}

extension FeedCoordinator: FeedModuleOutput {

    func feedModuleDidRequestToOpenFilters(with configuration: FeedConfiguration) {
        showFilters(with: configuration)
    }

    func feedModuleDidRequestToOpenPost(with identifier: Int) {
        showPost(with: identifier)
    }
}

extension FeedCoordinator: FeedFilterModuleOutput {

    func feedFilterModuleDidRequestUpdate(configuration: FeedConfiguration) {
        filterViewController?.dismiss(animated: true, completion: { [weak moduleInput] in
            moduleInput?.didChange(configuration: configuration)
        })
    }

    func feedFilterModuleDidRequestToClose() {
        filterViewController?.dismiss(animated: true)
    }
}
