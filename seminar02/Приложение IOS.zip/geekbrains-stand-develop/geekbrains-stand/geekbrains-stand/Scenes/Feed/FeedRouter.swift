//
//  FeedRouter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit

final class FeedRouter {
}

extension FeedRouter: FeedRouterInput {
}
