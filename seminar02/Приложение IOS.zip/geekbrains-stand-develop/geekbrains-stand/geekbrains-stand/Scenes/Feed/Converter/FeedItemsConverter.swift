//
//  FeedItemsConverter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import Domain

protocol FeedItemsConverterDescription {
    func convert(feed: Feed) -> [FeedListItemType]
}

final class FeedItemsConverter: FeedItemsConverterDescription {

    func convert(feed: Feed) -> [FeedListItemType] {
        return feed.posts.map({ FeedListItemType.post($0) })
    }
}
