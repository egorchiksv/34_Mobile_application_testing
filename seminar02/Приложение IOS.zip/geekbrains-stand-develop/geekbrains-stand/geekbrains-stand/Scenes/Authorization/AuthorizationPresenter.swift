//
//  AuthorizationPresenter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation

final class AuthorizationPresenter {
    weak var view: AuthorizationViewInput?
    weak var moduleOutput: AuthorizationModuleOutput?

    private let router: AuthorizationRouterInput
    private let interactor: AuthorizationInteractorInput

    init(router: AuthorizationRouterInput, interactor: AuthorizationInteractorInput) {
        self.router = router
        self.interactor = interactor
    }
}

extension AuthorizationPresenter: AuthorizationModuleInput {
}

extension AuthorizationPresenter: AuthorizationViewOutput {
    func didTapSignInButton(login: String, password: String) {
        view?.showActivity()
        AuthorizationManager.shared.login(userName: login, password: password) { [weak self] result in
            self?.view?.hideActivity()

            switch result {
            case .success:
                self?.moduleOutput?.authorizationModuleDidSignIn()
            case .failure:
                self?.view?.showHUD(title: "Auth_Sign_In_Error_Title".localized,
                                    message: "Auth_Sign_In_Error_Message".localized)
            }
        }
    }

    func didTapResetPasswordButton() {
        fatalError("FATAL ERROR: error on tap reset password button")
    }
}

extension AuthorizationPresenter: AuthorizationInteractorOutput {
}
