//
//  AuthorizationContainer.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit

final class AuthorizationContainer {
    let input: AuthorizationModuleInput
    let viewController: UIViewController
    private(set) weak var router: AuthorizationRouterInput!

    class func assemble(with context: AuthorizationContext) -> AuthorizationContainer {
        let router = AuthorizationRouter()
        let interactor = AuthorizationInteractor()
        let presenter = AuthorizationPresenter(router: router, interactor: interactor)
        let viewController = AuthorizationViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return AuthorizationContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UIViewController, input: AuthorizationModuleInput, router: AuthorizationRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct AuthorizationContext {
    weak var moduleOutput: AuthorizationModuleOutput?
}
