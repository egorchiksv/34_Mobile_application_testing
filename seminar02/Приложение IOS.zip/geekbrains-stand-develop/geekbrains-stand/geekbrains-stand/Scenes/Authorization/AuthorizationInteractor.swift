//
//  AuthorizationInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation

final class AuthorizationInteractor {
    weak var output: AuthorizationInteractorOutput?
}

extension AuthorizationInteractor: AuthorizationInteractorInput {
}
