//
//  AuthorizationProtocols.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation

protocol AuthorizationModuleInput {
    var moduleOutput: AuthorizationModuleOutput? { get }
}

protocol AuthorizationModuleOutput: AnyObject {
    func authorizationModuleDidSignIn()
}

protocol AuthorizationViewInput: HUDPresentable {
}

protocol AuthorizationViewOutput: AnyObject {
    func didTapSignInButton(login: String, password: String)
    func didTapResetPasswordButton()
}

protocol AuthorizationInteractorInput: AnyObject {
}

protocol AuthorizationInteractorOutput: AnyObject {
}

protocol AuthorizationRouterInput: AnyObject {
}
