//
//  AuthorizationViewController.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit
import PinLayout

final class AuthorizationViewController: UIViewController {

    // MARK: - Properties

    private let output: AuthorizationViewOutput

    private let logoImageView: UIImageView = UIImageView()
    private let containerView: UIView = UIView()
    private let loginTextField: AuthorizationTextField = AuthorizationTextField(for: .login)
    private let passwordTextField: AuthorizationTextField = AuthorizationTextField(for: .password)
    private let signInButton: UIButton = UIButton()
    private let resetPasswordButton: UIButton = UIButton()

    private var containerViewBottomPadding: CGFloat {
        let width: CGFloat = view.bounds.width - Constants.ContainerView.marginHorizontally * 2
        let availableSize: CGSize = CGSize(width: width, height: CGFloat.greatestFiniteMagnitude)
        let height: CGFloat = containerView.sizeThatFits(availableSize).height
        let padding: CGFloat = (view.bounds.height - height) / 2

        return padding
    }

    // MARK: - Init

    init(output: AuthorizationViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        view.backgroundColor = .background

        logoImageView.image = UIImage(named: "ImageTitleLogo")
        logoImageView.contentMode = .scaleAspectFit

        loginTextField.delegate = self
        loginTextField.addTarget(self, action: #selector(didChangeTextField), for: .editingChanged)

        passwordTextField.delegate = self
        passwordTextField.addTarget(self, action: #selector(didChangeTextField), for: .editingChanged)

        signInButton.clipsToBounds = true
        signInButton.backgroundColor = Constants.SignInButton.backgroundColor
        signInButton.layer.cornerRadius = Constants.SignInButton.cornerRadius
        signInButton.addTarget(self, action: #selector(didTapSignInButton), for: .touchUpInside)

        resetPasswordButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        resetPasswordButton.setTitleColor(Constants.ResetPasswordButton.titleColor, for: .normal)
        resetPasswordButton.addTarget(self, action: #selector(didTapResetPasswordButton), for: .touchUpInside)

        containerView.addSubviews(logoImageView, loginTextField, passwordTextField, signInButton, resetPasswordButton)
        view.addSubviews(containerView)
    }

    private func setupToHideKeyboardOnTapOnView() {
        let tap: UITapGestureRecognizer = .init(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tap)
    }

    private func setupToMoveViewOnKeyboardActions() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    private func configure() {
        loginTextField.setPlaceholder(with: "Auth_Login_Input_Placeholder".localized)

        passwordTextField.setPlaceholder(with: "Auth_Password_Input_Placeholder".localized)

        signInButton.setTitle("Auth_Sign_In_Button_Title".localized, for: .normal)

        resetPasswordButton.setTitle("Auth_Reset_Password_Button_Title".localized, for: .normal)
    }

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        setupToHideKeyboardOnTapOnView()
        setupToMoveViewOnKeyboardActions()
        configure()
    }

    // MARK: - Layout

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        containerView.pin
            .horizontally(Constants.ContainerView.marginHorizontally)
            .maxWidth(Constants.ContainerView.maxWidth)

        logoImageView.pin
            .top()
            .horizontally(Constants.LogoImageView.marginHorizontally)
            .sizeToFit(.width)

        loginTextField.pin
            .below(of: logoImageView)
            .marginTop(Constants.loginTextField.marginTop)
            .horizontally()
            .height(Constants.loginTextField.height)

        passwordTextField.pin
            .below(of: loginTextField)
            .marginTop(Constants.passwordTextField.marginTop)
            .horizontally()
            .height(Constants.passwordTextField.height)

        signInButton.pin
            .below(of: passwordTextField)
            .marginTop(Constants.SignInButton.marginTop)
            .horizontally()
            .height(Constants.SignInButton.height)

        resetPasswordButton.pin
            .below(of: signInButton)
            .marginTop(Constants.ResetPasswordButton.marginTop)
            .bottomRight()
            .height(Constants.ResetPasswordButton.height)
            .sizeToFit(.height)

        containerView.pin
            .wrapContent(.vertically)
            .center()
    }
}

// MARK: - Actions

private extension AuthorizationViewController {
    @objc
    func didTapSignInButton() {
        var hasError = false

        [loginTextField, passwordTextField].forEach {
            if let text = $0.text, text.isEmpty {
                $0.setState(.error)
                hasError = true
            }
        }

        guard !hasError,
              let login = loginTextField.text,
              let password = passwordTextField.text
        else {
            return
        }

        output.didTapSignInButton(login: login, password: password)
    }

    @objc
    func didTapResetPasswordButton() {
        output.didTapResetPasswordButton()
    }

    @objc
    func didChangeTextField(_ textField: AuthorizationTextField) {
        textField.setState(.normal)
    }

    @objc
    func dismissKeyboard() {
        view.endEditing(true)
    }

    @objc
    func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height - containerViewBottomPadding + Constants.keyboardMarginTop
            }
        }
    }

    @objc
    func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
    }
}

// MARK: - Constants

private extension AuthorizationViewController {
    struct Constants {
        struct ContainerView {
            static let marginHorizontally: CGFloat = 32
            static let maxWidth: CGFloat = 512
        }
        struct LogoImageView {
            static let marginHorizontally: CGFloat = 32
        }
        struct loginTextField {
            static let height: CGFloat = 40
            static let marginTop: CGFloat = 48
        }
        struct passwordTextField {
            static let marginTop: CGFloat = 16
            static let height: CGFloat = 40
        }
        struct SignInButton {
            static let marginTop: CGFloat = 32
            static let height: CGFloat = 40

            static let backgroundColor: UIColor = .UI.success.value
            static let cornerRadius: CGFloat = 8
        }
        struct ResetPasswordButton {
            static let marginTop: CGFloat = 16
            static let height: CGFloat = 20

            static let titleColor: UIColor = .Text.link.value
        }
        static let keyboardMarginTop: CGFloat = 48
    }
}

// MARK: - View input

extension AuthorizationViewController: AuthorizationViewInput {
}

// MARK: - UITextFieldDelegate

extension AuthorizationViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case loginTextField:
            passwordTextField.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }

        return false
    }
}
