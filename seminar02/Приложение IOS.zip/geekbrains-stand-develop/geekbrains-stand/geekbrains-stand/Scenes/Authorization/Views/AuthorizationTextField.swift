//
//  AuthorizationTextField.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 20.10.2022.
//

import UIKit

enum AuthorizationTextFieldType {
    case login, password
}

enum AuthorizationTextFieldState {
    case normal, error
}

final class AuthorizationTextField: TextField {
    init(for type: AuthorizationTextFieldType) {
        super.init()

        switch type {
        case .login:
            break
        case .password:
            isSecureTextEntry = true
        }

        setState(.normal)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setState(_ state: AuthorizationTextFieldState) {
        switch state {
        case .normal:
            layer.borderColor = UIColor.clear.cgColor
        case .error:
            layer.borderColor = UIColor.UI.error.value.cgColor
        }
    }
}
