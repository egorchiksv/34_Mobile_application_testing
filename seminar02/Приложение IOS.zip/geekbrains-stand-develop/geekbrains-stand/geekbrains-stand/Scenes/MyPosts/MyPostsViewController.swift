//
//  MyPostsViewController.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit
import PinLayout
import Domain
import Utils

final class MyPostsViewController: UIViewController {

    // MARK: - Properties

    private let output: MyPostsViewOutput

    private let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0

        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }()
    private let refreshControl: UIRefreshControl = UIRefreshControl()
    private let emptyStateView: EmptyStatePlaceholderView = {
        let image = UIImage(systemName: "list.bullet.rectangle.fill")?.withRenderingMode(.alwaysTemplate)

        return EmptyStatePlaceholderView(image: image,
                                         title: "MyPosts_Empty_State_Title".localized,
                                         subtitle: "MyPosts_Empty_State_Subtitle".localized)
    }()

    // MARK: - Init

    init(output: MyPostsViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Setup

    private func setup() {
        navigationItem.title = "MyPosts_Title".localized

        view.backgroundColor = .background

        collectionView.registerCellClass(MyPostCell.self)
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.backgroundColor = .background
        collectionView.refreshControl = refreshControl
        collectionView.backgroundView = emptyStateView

        refreshControl.addTarget(self, action: #selector(didPullToRefresh), for: .valueChanged)

        emptyStateView.isHidden = true

        view.addSubviews(collectionView)
    }

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        output.didLoadView()
    }

    // MARK: - Layout

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        collectionView.collectionViewLayout.invalidateLayout()
        collectionView.pin
            .all()
    }
}

// MARK: - Actions

private extension MyPostsViewController {
    @objc
    func didPullToRefresh() {
        output.didPullToRefresh()
    }

    func didTapRemoveButton(for itemId: Int) {
        let alert = UIAlertController(title: "Post_Alert_Remove_Title".localized,
                                      message: nil,
                                      preferredStyle: .alert)

        let removeAction = UIAlertAction(title: "Post_Action_Remove_Title_Short".localized,
                                         style: .destructive,
                                         handler: { [weak self] _ in
            self?.output.didTapRemoveButton(for: itemId)
        })
        let cancelAction = UIAlertAction(title: "Post_Action_Cancel_Title".localized,
                                         style: .cancel)

        [removeAction, cancelAction].forEach {
            alert.addAction($0)
        }

        present(alert, animated: true, completion: nil)
    }
}

// MARK: - Constants

private extension MyPostsViewController {
    struct Constants {
        struct Collection {
            static let insets: UIEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        }
    }
}

// MARK: - MyPostsViewInput

extension MyPostsViewController: MyPostsViewInput {
    func scrollToTop() {
        collectionView.setContentOffset(CGPoint(x: 0, y: -view.safeAreaInsets.top), animated: true)
    }

    func reloadData() {
        collectionView.reloadData()
    }

    func removeItem(for itemIndex: Int) {
        let indexPath = IndexPath(row: itemIndex, section: 0)

        collectionView.performBatchUpdates { [weak self] in
            self?.collectionView.deleteItems(at: [indexPath])
        } completion: { [weak self] _ in
            guard let collectionView = self?.collectionView else {
                return
            }

            collectionView.reloadItems(at: collectionView.indexPathsForVisibleItems)
        }
    }

    func setEmptyState(needShow: Bool) {
        emptyStateView.isHidden = !needShow
    }

    func endRefreshing() {
        collectionView.refreshControl?.endRefreshing()
    }
}

// MARK: - UICollectionViewDataSource

extension MyPostsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return output.itemsCount
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MyPostCell.classNameReuseIdentifier,
                                                            for: indexPath) as? MyPostCell
        else {
            return UICollectionViewCell()
        }

        let item: FeedPost = output.item(at: indexPath)
        let cellViewModel = MyPostCellViewModel(imageURL: item.mainImage.url,
                                                title: item.title,
                                                description: item.description)
        cell.configure(itemId: item.id, viewModel: cellViewModel)
        cell.delegate = self

        return cell
    }

    func collectionView(_ collectionView: UICollectionView,
                        willDisplay cell: UICollectionViewCell,
                        forItemAt indexPath: IndexPath) {
        let isLastCell = indexPath.row == output.itemsCount - 1
        guard isLastCell else {
            return
        }

        output.willDisplayLastCell()
    }
}

// MARK: - UICollectionViewDelegate

extension MyPostsViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        output.didTapCell(with: indexPath)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout

extension MyPostsViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let insets = Constants.Collection.insets
        let horizontalPadding = insets.left + insets.right
        let width = collectionView.bounds.size.width - horizontalPadding

        return CGSize(width: width, height: MyPostCell.height())
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return Constants.Collection.insets
    }
}

// MARK: - MyPostCellDelegate

extension MyPostsViewController: MyPostCellDelegate {
    func didRequestToShowActions(for itemId: Int, sourceView: UIView) {
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        let editAction = UIAlertAction(title: "Post_Action_Edit_Title".localized,
                                       style: .default,
                                       handler: { [weak self] _ in
            self?.output.didTapEditButton(for: itemId)
        })
        let removeAction = UIAlertAction(title: "Post_Action_Remove_Title".localized,
                                         style: .destructive,
                                         handler: { [weak self] _ in
            self?.didTapRemoveButton(for: itemId)
        })
        let cancelAction = UIAlertAction(title: "Post_Action_Cancel_Title".localized,
                                         style: .cancel)

        [editAction, removeAction, cancelAction].forEach {
            alert.addAction($0)
        }

        alert.popoverPresentationController?.sourceView = sourceView
        alert.popoverPresentationController?.sourceRect = sourceView.bounds

        present(alert, animated: true, completion: nil)
    }
}
