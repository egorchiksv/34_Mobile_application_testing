//
//  MyPostsInteractor.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Foundation
import Networks

final class MyPostsInteractor {
    weak var output: MyPostsInteractorOutput?

    private let postManager: PostManagerDescription

    private(set) var isLoadingFeed: Bool = false

    init(postManager: PostManagerDescription = PostManager.shared) {
        self.postManager = postManager
    }
}

extension MyPostsInteractor: MyPostsInteractorInput {
    func loadFeed(with cursor: FeedCursor) {
        isLoadingFeed = true
        postManager.getFeed(page: cursor.page,
                            limit: cursor.limit,
                            sort: nil,
                            order: nil,
                            owner: .myUser) { [weak self] result in
            switch result {
            case .success(let feed):
                self?.output?.didRecieve(feed: feed)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
            self?.isLoadingFeed = false
        }
    }

    func removePost(for postId: Int) {
        postManager.removePost(postId: postId) { [weak self] result in
            switch result {
            case .success(let post):
                self?.output?.didRemove(post: post)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }
}
