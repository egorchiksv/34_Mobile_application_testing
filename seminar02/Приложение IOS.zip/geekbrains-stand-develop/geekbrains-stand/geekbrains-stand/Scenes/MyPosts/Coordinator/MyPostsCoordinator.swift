//
//  MyPostsCoordinator.swift
//  geekbrains-stand
//
//  Created e.korotkiy on 19.10.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils

struct MyPostsFlowContext {

}

final class MyPostsCoordinator: Coordinator {

    // MARK: - Private properties

    private let flowContext: MyPostsFlowContext

    private weak var navigationController: UINavigationController?
    private(set) var mainViewController: UIViewController?

    private(set) weak var moduleInput: MyPostsModuleInput?

    private var createPostCoordinator: CreatePostCoordinator?
    private var postCoordinator: PostCoordinator?

    // MARK: - Init

    init(navigationController: UINavigationController?, flowContext: MyPostsFlowContext) {
        self.flowContext = flowContext

        super.init()

        let context = MyPostsContext(moduleOutput: self)
        let container = MyPostsContainer.assemble(with: context)

        if navigationController == nil {
            mainViewController = UINavigationController(rootViewController: container.viewController)
        } else {
            self.navigationController = navigationController
            mainViewController = container.viewController
        }

        moduleInput = container.input
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)

    }

    override func finish() {
        super.finish()

    }
}

extension MyPostsCoordinator: MyPostsModuleOutput {
    func myPostsModuleDidRequestToOpenDetailedPost(for postId: Int) {
        // open detailed post
    }

    func myPostsModuleDidRequestToOpenEditPost(for postId: Int) {
        guard let mainViewController = mainViewController else {
            return
        }

        let flowContext = CreatePostFlowContext(type: .editById(postId: postId))
        createPostCoordinator = CreatePostCoordinator(sourceViewController: mainViewController,
                                                      interactor: CreatePostCoordinatorInteractor(),
                                                      flowContext: flowContext)
        createPostCoordinator?.onClose = { [weak self] in
            self?.createPostCoordinator?.finish()
            self?.createPostCoordinator = nil
        }
        createPostCoordinator?.onEditSuccessfully = { [weak self] post in
            self?.moduleInput?.updatePost(with: post)
        }
        createPostCoordinator?.start(in: self)
    }
}
