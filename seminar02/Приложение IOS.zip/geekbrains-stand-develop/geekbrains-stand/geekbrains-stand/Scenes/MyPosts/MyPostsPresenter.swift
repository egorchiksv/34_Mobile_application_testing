//
//  MyPostsPresenter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Foundation
import Domain

final class MyPostsPresenter {
    weak var view: MyPostsViewInput?
    weak var moduleOutput: MyPostsModuleOutput?

    private var posts: [FeedPost] = []
    private let cursor: FeedCursor = FeedCursor()

    private let router: MyPostsRouterInput
    private let interactor: MyPostsInteractorInput

    init(router: MyPostsRouterInput, interactor: MyPostsInteractorInput) {
        self.router = router
        self.interactor = interactor
    }
}

private extension MyPostsPresenter {
    var needLoadData: Bool {
        cursor.canRequestNext && !interactor.isLoadingFeed
    }

    func loadDataIfNeeded() {
        guard needLoadData else {
            return
        }
        interactor.loadFeed(with: cursor)
    }
}

extension MyPostsPresenter: MyPostsModuleInput {
    func scrollToTop() {
        view?.scrollToTop()
    }

    func updatePost(with post: FeedPost) {
        guard let index = posts.firstIndex(where: { $0.id == post.id }) else {
            return
        }
        posts[index] = post
        view?.reloadData()
    }
}

extension MyPostsPresenter: MyPostsViewOutput {
    var itemsCount: Int {
        posts.count
    }

    func item(at indexPath: IndexPath) -> FeedPost {
        posts[indexPath.row]
    }

    func didLoadView() {
        view?.showActivity()
        loadDataIfNeeded()
    }

    func didPullToRefresh() {
        cursor.reset()
        loadDataIfNeeded()
    }

    func willDisplayLastCell() {
        loadDataIfNeeded()
    }

    func didTapEditButton(for itemId: Int) {
        moduleOutput?.myPostsModuleDidRequestToOpenEditPost(for: itemId)
    }

    func didTapRemoveButton(for itemId: Int) {
        view?.showActivity()
        interactor.removePost(for: itemId)
    }

    func didTapCell(with indexPath: IndexPath) {
        let itemId = posts[indexPath.row].id
        moduleOutput?.myPostsModuleDidRequestToOpenDetailedPost(for: itemId)
    }
}

extension MyPostsPresenter: MyPostsInteractorOutput {
    func didRecieve(feed: Feed) {
        if cursor.isFirstPage {
            posts = feed.posts
        } else {
            posts.append(contentsOf: feed.posts)
        }
        cursor.update(with: feed.meta)

        view?.hideActivity()
        view?.endRefreshing()
        view?.reloadData()
        view?.setEmptyState(needShow: posts.isEmpty)
    }

    func didRecieve(error: Error) {
        view?.hideActivity()
        view?.endRefreshing()
        view?.setEmptyState(needShow: posts.isEmpty)
        view?.showHUD(with: error, completion: nil)
    }

    func didRemove(post: FeedPost) {
        view?.hideActivity()
        view?.showHUD(message: "MyPosts_Remove_Post_Success_Message".localized)

        let itemIndex = posts.firstIndex {
            $0.id == post.id
        }
        guard let itemIndex = itemIndex else {
            return
        }

        posts.remove(at: itemIndex)
        view?.removeItem(for: itemIndex)
        view?.setEmptyState(needShow: posts.isEmpty)
    }
}
