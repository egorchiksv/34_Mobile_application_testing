//
//  MyPostCellViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 01.11.2022.
//

import UIKit

final class MyPostCellViewModel: MyProfileTableViewCellViewModel {
    let imageURL: String?
    let title: NSAttributedString
    let description: NSAttributedString

    init(imageURL: String, title: String, description: String) {
        self.imageURL = imageURL.replacingOccurrences(of: "http://", with: "https://")
        self.title = NSAttributedString(string: title, attributes: Constants.titleAttributes)
        self.description = NSAttributedString(string: description, attributes: Constants.descriptionAttributes)
    }
}

private extension MyPostCellViewModel {
    struct Constants {
        static let titleAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 17, weight: .bold)
        ]
        static let descriptionAttributes = [
            NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value,
            NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15, weight: .regular)
        ]
    }
}
