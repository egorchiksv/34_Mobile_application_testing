//
//  MyPostCell.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 01.11.2022.
//

import UIKit

protocol MyPostCellDelegate: AnyObject {
    func didRequestToShowActions(for itemId: Int, sourceView: UIView)
}

final class MyPostCell: UICollectionViewCell {

    // MARK: - Properties

    weak var delegate: MyPostCellDelegate?
    private var itemId: Int?

    private let containerView: UIView = UIView()
    private let labelsContainerView: UIView = UIView()
    private let imageView: UIImageView = UIImageView()
    private let titleLabel: UILabel = UILabel()
    private let descriptionLabel: UILabel = UILabel()
    private let actionsButton: UIButton = UIButton()

    // MARK: - Init

    override init(frame: CGRect) {
        super.init(frame: frame)

        setup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

        fatalError("Interface Builder is not supported!")
    }

    // MARK: - Setup

    private func setup() {
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = Constants.ImageView.tintColor
        imageView.backgroundColor = Constants.ImageView.backgroundColor
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = Constants.ImageView.cornerRadius

        titleLabel.adjustsFontSizeToFitWidth = false
        titleLabel.lineBreakMode = .byTruncatingTail

        descriptionLabel.numberOfLines = 2
        descriptionLabel.adjustsFontSizeToFitWidth = false
        descriptionLabel.lineBreakMode = .byTruncatingTail

        let actionsImage = UIImage(systemName: "ellipsis")?.withRenderingMode(.alwaysTemplate)
        actionsButton.setImage(actionsImage, for: .normal)
        actionsButton.addTarget(self, action: #selector(didTapActionButton), for: .touchUpInside)

        labelsContainerView.addSubviews(titleLabel, descriptionLabel)
        containerView.addSubviews(imageView, labelsContainerView, actionsButton)
        contentView.addSubviews(containerView)
    }

    func configure(itemId: Int, viewModel: MyPostCellViewModel) {
        self.itemId = itemId

        let placeholderImage = UIImage(systemName: "photo.fill")?.withRenderingMode(.alwaysTemplate)
        if let imageURL = viewModel.imageURL {
            imageView.setImage(from: imageURL, placeholderImage: placeholderImage)
        } else {
            imageView.image = placeholderImage
        }

        titleLabel.attributedText = viewModel.title
        descriptionLabel.attributedText = viewModel.description
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        containerView.pin
            .all(Constants.ContainerView.insets)

        imageView.pin
            .left()
            .centerLeft()
            .size(Constants.ImageView.size)

        actionsButton.pin
            .centerRight()
            .size(Constants.ActionsButton.size)

        labelsContainerView.pin
            .top()
            .horizontallyBetween(imageView, and: actionsButton)
            .marginLeft(Constants.LabelsContainerView.marginLeft)
            .marginRight(Constants.LabelsContainerView.marginRight)
            .marginTop(Constants.LabelsContainerView.marginTop)
            .sizeToFit(.width)

        titleLabel.pin
            .top()
            .horizontally()
            .sizeToFit(.width)

        descriptionLabel.pin
            .below(of: titleLabel)
            .marginTop(Constants.DescriptionLabel.marginTop)
            .horizontally()
            .sizeToFit(.width)
    }

    static func height() -> CGFloat {
        let insets = Constants.ContainerView.insets

        return insets.top + Constants.ImageView.size.height + insets.bottom
    }
}

// MARK: - Actions

private extension MyPostCell {
    @objc
    func didTapActionButton() {
        guard let itemId = itemId else {
            return
        }

        delegate?.didRequestToShowActions(for: itemId, sourceView: actionsButton)
    }
}

// MARK: - Constants

private extension MyPostCell {
    struct Constants {
        struct ContainerView {
            static let insets = UIEdgeInsets(top: 8, left: 12, bottom: 8, right: 12)
        }
        struct ImageView {
            static let size: CGSize = CGSize(width: 64, height: 64)

            static let cornerRadius: CGFloat = 8
            static let backgroundColor: UIColor = .UI.primary.value
            static let tintColor: UIColor = .UI.background.value
        }
        struct ActionsButton {
            static let size: CGSize = CGSize(width: 16, height: 16)
        }
        struct LabelsContainerView {
            static let marginLeft: CGFloat = 12
            static let marginRight: CGFloat = 12
            static let marginTop: CGFloat = 2
        }
        struct DescriptionLabel {
            static let marginTop: CGFloat = 0
        }
    }
}
