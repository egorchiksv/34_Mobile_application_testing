//
//  MyPostsContainer.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit

final class MyPostsContainer {
    let input: MyPostsModuleInput
    let viewController: UIViewController
    private(set) weak var router: MyPostsRouterInput!

    class func assemble(with context: MyPostsContext) -> MyPostsContainer {
        let router = MyPostsRouter()
        let interactor = MyPostsInteractor()
        let presenter = MyPostsPresenter(router: router, interactor: interactor)
        let viewController = MyPostsViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return MyPostsContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UIViewController, input: MyPostsModuleInput, router: MyPostsRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct MyPostsContext {
    weak var moduleOutput: MyPostsModuleOutput?
}
