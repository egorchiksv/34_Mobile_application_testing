//
//  MyPostsProtocols.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Foundation
import Domain

protocol MyPostsModuleInput: AnyObject {
    var moduleOutput: MyPostsModuleOutput? { get }

    func scrollToTop()
    func updatePost(with post: FeedPost)
}

protocol MyPostsModuleOutput: AnyObject {
    func myPostsModuleDidRequestToOpenDetailedPost(for postId: Int)
    func myPostsModuleDidRequestToOpenEditPost(for postId: Int)
}

protocol MyPostsViewInput: HUDPresentable {
    func scrollToTop()
    func reloadData()
    func removeItem(for itemIndex: Int)
    func setEmptyState(needShow: Bool)
    func endRefreshing()
}

protocol MyPostsViewOutput: AnyObject {
    var itemsCount: Int { get }

    func item(at indexPath: IndexPath) -> FeedPost
    func didLoadView()
    func didPullToRefresh()
    func willDisplayLastCell()
    func didTapEditButton(for itemId: Int)
    func didTapRemoveButton(for itemId: Int)
    func didTapCell(with indexPath: IndexPath)
}

protocol MyPostsInteractorInput: AnyObject {
    var isLoadingFeed: Bool { get }

    func loadFeed(with cursor: FeedCursor)
    func removePost(for postId: Int)
}

protocol MyPostsInteractorOutput: AnyObject {
    func didRecieve(feed: Feed)
    func didRecieve(error: Error)
    func didRemove(post: FeedPost)
}

protocol MyPostsRouterInput: AnyObject {
}
