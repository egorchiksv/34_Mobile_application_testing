//
//  MyPostsRouter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit

final class MyPostsRouter {
}

extension MyPostsRouter: MyPostsRouterInput {
}
