//
//  CreatePostViewController.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit
import PinLayout

final class CreatePostViewController: UIViewController {

    // MARK: - Private properties

    private let containerScrollView: UIScrollView = UIScrollView()

    private lazy var addImagesCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = Constants.AddImagesCollectionView.minimumLineSpacing

        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.register(CreatePostAddImageCell.self, forCellWithReuseIdentifier: "CreatePostAddImageCell")
        collectionView.contentInset = UIEdgeInsets(top: .zero,
                                                   left: Constants.AddImagesCollectionView.horizontalInset,
                                                   bottom: .zero,
                                                   right: Constants.AddImagesCollectionView.horizontalInset)

        return collectionView
    }()

    private let titleTextField: TextField = TextField()
    private let descriptionTextView: TextView = TextView()
    private let contentTextView: TextView = TextView()
    private let descriptionPlaceholder: UILabel = UILabel()
    private let delayDateContainer: UIView = UIView()
    private let contentPlaceholder: UILabel = UILabel()
    private let datePicker: UIDatePicker = UIDatePicker()
    private let delayDateTitle: UILabel = UILabel()
    private let actionPostButtonContainer: UIView = UIView()
    private let actionPostButton: UIButton = UIButton()

    private lazy var dateFromPicker: String = {
        guard datePicker.date > Date.now else {
            return ""
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = formatter.string(from: datePicker.date)
        return (dateString)
    }()

    private let output: CreatePostViewOutput

    // MARK: - Init

    init(output: CreatePostViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Life cycle

    override func viewDidLoad() {
        super.viewDidLoad()

        setup()
        setupNavbar()
        setupToHideKeyboardOnTapOnView()

        output.didLoadView()
    }

    // MARK: - Setup

    private func setupNavbar() {
        navigationItem.leftBarButtonItem = .closeButton(with: self, action: #selector(didTapNavigationBarCloseButton))
        navigationItem.rightBarButtonItem = .plainButton(with: self,
                                                         action: #selector(didTapNavigationBarAddToDraftButton),
                                                         image: UIImage(systemName: "list.clipboard"))
        navigationController?.navigationBar.tintColor = Constants.NavBar.tintColor
        navigationController?.presentationController?.delegate = self
    }

    private func setup() {
        view.backgroundColor = Constants.backgroundColor

        containerScrollView.delegate = self
        containerScrollView.contentInsetAdjustmentBehavior = .never
        containerScrollView.keyboardDismissMode = .onDrag

        addImagesCollectionView.backgroundColor = Constants.AddImagesCollectionView.backgroundColor
        addImagesCollectionView.delegate = self
        addImagesCollectionView.dataSource = self
        addImagesCollectionView.dragDelegate = self
        addImagesCollectionView.dropDelegate = self
        addImagesCollectionView.showsHorizontalScrollIndicator = false

        titleTextField.delegate = self

        descriptionTextView.addSubview(descriptionPlaceholder)
        descriptionTextView.textContainerInset = Constants.TextView.inset
        descriptionTextView.delegate = self

        contentTextView.addSubview(contentPlaceholder)
        contentTextView.textContainerInset = Constants.TextView.inset
        contentTextView.delegate = self

        delayDateContainer.backgroundColor = .clear

        datePicker.preferredDatePickerStyle = .compact
        datePicker.datePickerMode = .date
        datePicker.tintColor = Constants.DatePicker.tintColor

        actionPostButtonContainer.backgroundColor = Constants.backgroundColor

        actionPostButton.addTarget(self, action: #selector(didTapActionPostButton), for: .touchUpInside)
        actionPostButton.backgroundColor = Constants.ActionPostButton.backgroundColor
        actionPostButton.layer.cornerRadius = Constants.ActionPostButton.cornerRadius

        delayDateContainer.addSubviews(delayDateTitle, datePicker)

        containerScrollView.addSubviews(addImagesCollectionView, titleTextField, descriptionTextView, contentTextView, delayDateContainer)
        actionPostButtonContainer.addSubview(actionPostButton)

        view.addSubviews(containerScrollView, actionPostButtonContainer)
    }

    private func setupToHideKeyboardOnTapOnView() {
        let tap: UITapGestureRecognizer = .init(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    // MARK: - Layout

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        actionPostButtonContainer.pin
            .bottom()
            .horizontally()
            .height(Constants.ActionPostButtonContainer.height + view.safeAreaInsets.bottom)

        actionPostButton.pin
            .top(Constants.ActionPostButton.marginVertically)
            .horizontally(Constants.ActionPostButton.marginHorizontally)
            .bottom(Constants.ActionPostButton.marginVertically + view.safeAreaInsets.bottom)

        containerScrollView.pin
            .horizontally()
            .top(view.safeAreaInsets.top)
            .above(of: actionPostButtonContainer)

        addImagesCollectionView.pin
            .top()
            .horizontally()
            .height(Constants.AddImagesCollectionView.height)

        titleTextField.pin
            .below(of: addImagesCollectionView)
            .marginTop(Constants.TitleTextField.marginTop)
            .horizontally(Constants.TitleTextField.marginHorizontally)
            .height(Constants.TitleTextField.height)

        descriptionTextView.pin
            .below(of: titleTextField)
            .marginTop(Constants.descriptionTextView.marginTop)
            .horizontally(Constants.descriptionTextView.marginHorizontally)
            .height(Constants.descriptionTextView.height)

        descriptionPlaceholder.pin
            .top(Constants.TextView.inset.top)
            .left(Constants.TextView.inset.left)
            .right(Constants.TextView.inset.right)
            .sizeToFit(.width)

        contentTextView.pin
            .below(of: descriptionTextView)
            .marginTop(Constants.ContentTextView.marginTop)
            .horizontally(Constants.ContentTextView.marginHorizontally)
            .height(Constants.ContentTextView.height)

        contentPlaceholder.pin
            .top(Constants.TextView.inset.top)
            .left(Constants.TextView.inset.left)
            .right(Constants.TextView.inset.right)
            .sizeToFit(.width)

        delayDateContainer.pin
            .below(of: contentTextView)
            .horizontally(Constants.DelayDateContainer.marginHorizontally)

        delayDateTitle.pin
            .left()
            .vCenter()
            .sizeToFit()

        datePicker.pin
            .after(of: delayDateTitle)
            .marginLeft(Constants.DatePicker.marginLeft)
            .right()
            .vCenter()

        delayDateContainer.pin
            .wrapContent(.vertically, padding: Constants.DelayDateContainer.marginVertically)

        containerScrollView.contentSize = CGSize(width: view.bounds.width, height: delayDateContainer.frame.maxY)
    }

    // MARK: - Actions

    @objc
    private func didTapNavigationBarCloseButton() {
        output.didRequestToClose()
    }

    @objc
    private func didTapNavigationBarAddToDraftButton() {
        // Bug: do nothing
    }

    @objc
    private func didTapActionPostButton() {
        output.didTapActionButton(title: titleTextField.text ?? "",
                                  description: descriptionTextView.text,
                                  content: contentTextView.text,
                                  delayPublishTo: dateFromPicker)
    }

    @objc
    func dismissKeyboard() {
        view.endEditing(true)
    }
}

// MARK: - View input

extension CreatePostViewController: CreatePostViewInput {
    func configure(with model: CreatePostViewModel) {
        title = model.screenTitle

        titleTextField.text = model.title
        titleTextField.setPlaceholder(with: model.titlePlaceholder)

        descriptionTextView.text = model.description
        textViewDidChange(descriptionTextView)
        descriptionPlaceholder.attributedText = model.descriptionPlaceholder

        contentTextView.text = model.content
        textViewDidChange(contentTextView)
        contentPlaceholder.attributedText = model.contentPlaceholder

        datePicker.date = model.delayDate
        delayDateTitle.attributedText = model.delayDateTitle

        actionPostButton.setTitle(model.actionButtonTitle, for: .normal)

        view.setNeedsLayout()
    }

    func update(at index: Int, cellModel: CreatePostAddImageCellModel) {
        addImagesCollectionView.performBatchUpdates({
            guard let cell = addImagesCollectionView.cellForItem(at: IndexPath(item: index, section: 0)) as? CreatePostAddImageCell else {
                return
            }
            cell.configure(with: cellModel)
        })
    }
}

// MARK: - Image Picker delegate

 extension CreatePostViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true)
        guard
            let image = info[.editedImage] as? UIImage
        else {
            return
        }

        output.didChangeImage(with: image)
    }
 }

// MARK: - Collection View delegate

extension CreatePostViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return output.viewModelsCount()
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CreatePostAddImageCell",
                                                          for: indexPath) as? CreatePostAddImageCell
        else {
            return UICollectionViewCell()
        }

        cell.configure(with: output.viewModel(at: indexPath.row))
        cell.contentView.isUserInteractionEnabled = false

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        output.didTapCell(at: indexPath)
    }
}

extension CreatePostViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return Constants.AddImagesCollectionView.cellSize
    }
}

extension CreatePostViewController: UICollectionViewDragDelegate {
    func collectionView(_ collectionView: UICollectionView, itemsForBeginning session: UIDragSession, at indexPath: IndexPath) -> [UIDragItem] {
        let itemProvider = NSItemProvider()
        let dragItem = UIDragItem(itemProvider: itemProvider)
        dragItem.localObject = indexPath

        return [dragItem]
    }
}

extension CreatePostViewController: UICollectionViewDropDelegate {
    func collectionView(_ collectionView: UICollectionView, performDropWith coordinator: UICollectionViewDropCoordinator) {
        guard
            let item = coordinator.items.first,
            let sourceIndexPath = item.sourceIndexPath,
            let destinationIndexPath = coordinator.destinationIndexPath
        else {
            return
        }

        switch coordinator.proposal.operation {
        case .move:
            output.didMoveCell(at: sourceIndexPath.row, to: destinationIndexPath.row)

            collectionView.performBatchUpdates({
                collectionView.deleteItems(at: [sourceIndexPath])
                collectionView.insertItems(at: [destinationIndexPath])
            })

            coordinator.drop(item.dragItem, toItemAt: destinationIndexPath)
        default:
            return
        }
    }

    func collectionView(_ collectionView: UICollectionView, dropSessionDidUpdate session: UIDropSession, withDestinationIndexPath destinationIndexPath: IndexPath?) -> UICollectionViewDropProposal {
        return UICollectionViewDropProposal(operation: .move, intent: .insertAtDestinationIndexPath)
    }
}

// MARK: - Text View delegate

extension CreatePostViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        switch textView {
        case descriptionTextView:
            descriptionPlaceholder.isHidden = !descriptionTextView.text.isEmpty
        case contentTextView:
            contentPlaceholder.isHidden = !contentTextView.text.isEmpty
        default:
            break
        }
    }

    func textViewDidBeginEditing(_ textView: UITextView) {
        containerScrollView.scrollRectToVisible(textView.frame, animated: true)
    }
}

// MARK: - Text Field Delegate

extension CreatePostViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case titleTextField:
            descriptionTextView.becomeFirstResponder()
        default:
            textField.resignFirstResponder()
        }

        return false
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        containerScrollView.scrollRectToVisible(textField.frame, animated: true)
    }
}

// MARK: - Adaptive Presentation Delegate

extension CreatePostViewController: UIAdaptivePresentationControllerDelegate {
    func presentationControllerDidDismiss(_ presentationController: UIPresentationController) {
        output.didRequestToClose()
    }
}

// MARK: - Constants

private extension CreatePostViewController {
    struct Constants {
        static let backgroundColor: UIColor = .background

        struct NavBar {
            static let tintColor: UIColor = .systemIndigo
        }

        struct AddImagesCollectionView {
            static let backgroundColor: UIColor = .background
            static let horizontalInset: CGFloat = 18
            static let minimumLineSpacing: CGFloat = 8
            static let height: CGFloat = 140
            static let cellSize: CGSize = CGSize(width: 110, height: 110)
        }

        struct TextView {
            static let borderColor: CGColor = UIColor.UI.separator.value.cgColor
            static let inset = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
        }

        struct TitleTextField {
            static let height: CGFloat = 40
            static let marginTop: CGFloat = 20
            static let marginHorizontally: CGFloat = 18
        }

        struct descriptionTextView {
            static let height: CGFloat = 120
            static let marginTop: CGFloat = 16
            static let marginHorizontally: CGFloat = 18
        }

        struct ContentTextView {
            static let height: CGFloat = 120
            static let marginTop: CGFloat = 16
            static let marginHorizontally: CGFloat = 18
        }

        struct DelayDateContainer {
            static let marginHorizontally: CGFloat = 18
            static let marginVertically: CGFloat = 16
        }

        struct DatePicker {
            static let tintColor: UIColor = .systemIndigo
            static let marginLeft: CGFloat = 8
        }

        struct ActionPostButtonContainer {
            static let height: CGFloat = 74
        }

        struct ActionPostButton {
            static let backgroundColor: UIColor = .systemIndigo
            static let cornerRadius: CGFloat = 8
            static let marginHorizontally: CGFloat = 12
            static let marginVertically: CGFloat = 12
        }
    }
}
