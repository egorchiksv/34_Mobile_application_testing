//
//  CreatePostProtocols.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit
import Domain

protocol CreatePostModuleInput {
    var moduleOutput: CreatePostModuleOutput? { get }
}

protocol CreatePostModuleOutput: AnyObject {
    func createPostModuleDidRequestToClose()
    func createPostModuleDidCreate()
    func createPostModuleDidEdit(with post: FeedPost)
}

protocol CreatePostViewInput: HUDPresentable {
    func configure(with model: CreatePostViewModel)
    func update(at index: Int, cellModel: CreatePostAddImageCellModel)
}

protocol CreatePostViewOutput: AnyObject {
    func didLoadView()
    func viewModelsCount() -> Int
    func viewModel(at index: Int) -> CreatePostAddImageCellModel
    func didTapCell(at indexPath: IndexPath)
    func didMoveCell(at sourceIndex: Int, to destinationIndex: Int)
    func didChangeImage(with image: UIImage)
    func didTapActionButton(title: String,
                            description: String,
                            content: String,
                            delayPublishTo: String)
    func didRequestToClose()
}

protocol CreatePostInteractorInput: AnyObject {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String)
    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String)
}

protocol CreatePostInteractorOutput: AnyObject {
    func didCreatePost()
    func didEditPost(with post: FeedPost)
    func didRecieve(error: Error)
}

protocol CreatePostRouterInput: AnyObject {
    func showAddImageAlert(isImageAlready: Bool, onRemovedImage: (() -> Void)?)
}
