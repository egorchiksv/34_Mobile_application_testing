//
//  CreatePostPresenter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit
import Domain

final class CreatePostPresenter {
    weak var view: CreatePostViewInput?
    weak var moduleOutput: CreatePostModuleOutput?

    private let router: CreatePostRouterInput
    private let interactor: CreatePostInteractorInput
    private let type: CreatePostModuleType

    private let viewModelFactory: CreatePostViewModelFactory = .init()

    private lazy var models: [CreatePostAddImageCellModel] = {
        var models = Array(repeating: CreatePostAddImageCellModel(state: .empty), count: 3)

        switch type {
        case .edit(let post):
            let rawImageURL = post.mainImage.url
            if !rawImageURL.isEmpty {
                let imageURL = rawImageURL.replacingOccurrences(of: "http://", with: "https://")
                models[0] = .init(state: .url(imageURL: imageURL))
            }
        case .create:
            break
        }

        return models
    }()
    private var selectedCellIndexPath: IndexPath?

    init(router: CreatePostRouterInput, interactor: CreatePostInteractorInput, type: CreatePostModuleType) {
        self.router = router
        self.interactor = interactor
        self.type = type
    }
}

extension CreatePostPresenter: CreatePostModuleInput {
}

extension CreatePostPresenter: CreatePostViewOutput {
    func didLoadView() {
        let viewModel = viewModelFactory.createViewModel(for: type)
        view?.configure(with: viewModel)
    }

    func viewModelsCount() -> Int {
        return models.count
    }

    func viewModel(at index: Int) -> CreatePostAddImageCellModel {
        guard models.count > index else {
            return .init(state: .empty)
        }

        return models[index]
    }

    func didTapCell(at indexPath: IndexPath) {
        guard models.count > indexPath.row else {
            return
        }

        selectedCellIndexPath = indexPath
        let isImageAlready: Bool = !models[indexPath.row].shouldShowEmptyStateImage
        router.showAddImageAlert(isImageAlready: isImageAlready) { [weak self] in
            let cellModel = CreatePostAddImageCellModel(state: .empty)

            self?.models.remove(at: indexPath.row)
            self?.models.insert(cellModel, at: indexPath.row)

            self?.view?.update(at: indexPath.row, cellModel: cellModel)
        }
    }

    func didMoveCell(at sourceIndex: Int, to destinationIndex: Int) {
        let element = models.remove(at: sourceIndex)
        models.insert(element, at: destinationIndex)
    }

    func didChangeImage(with image: UIImage) {
        guard
            let index = selectedCellIndexPath?.row,
            models.count > index
        else {
            return
        }

        let cellModel = CreatePostAddImageCellModel(state: .uploaded(image: image))
        models.remove(at: index)
        models.insert(cellModel, at: index)

        view?.update(at: index, cellModel: cellModel)
    }

    func didTapActionButton(title: String,
                            description: String,
                            content: String,
                            delayPublishTo: String) {
        view?.showActivity()

        let image = models.compactMap {
            switch $0.state {
            case .uploaded(let image):
                return image
            case .url, .empty:
                return nil
            }
        }.last
        let imageData = image?.jpegData(compressionQuality: 1)

        switch type {
        case .create:
            interactor.createPost(image: imageData,
                                  title: title,
                                  description: description,
                                  content: content,
                                  isDraft: false,
                                  delayPublishTo: delayPublishTo)
        case .edit(let post):
            interactor.editPost(postId: post.id,
                                image: imageData,
                                imageId: post.mainImage.id,
                                title: title,
                                description: description,
                                content: content,
                                isDraft: false,
                                delayPublishTo: delayPublishTo)
        }
    }

    func didRequestToClose() {
        self.moduleOutput?.createPostModuleDidRequestToClose()
    }
}

extension CreatePostPresenter: CreatePostInteractorOutput {
    func didCreatePost() {
        view?.hideActivity()
        moduleOutput?.createPostModuleDidCreate()
    }

    func didEditPost(with post: FeedPost) {
        view?.hideActivity()
        moduleOutput?.createPostModuleDidEdit(with: post)
    }

    func didRecieve(error: Error) {
        view?.hideActivity()

        switch type {
        case .create:
            view?.showHUD(title: "Create_Post_Error_Title".localized,
                          message: "Create_Post_Error_Message".localized)
        case .edit:
            view?.showHUD(title: "Edit_Post_Error_Title".localized,
                          message: "Edit_Post_Error_Message".localized)
        }
    }
}
