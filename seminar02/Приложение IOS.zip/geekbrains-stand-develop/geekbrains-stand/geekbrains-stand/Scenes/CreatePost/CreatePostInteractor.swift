//
//  CreatePostInteractor.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import Foundation

final class CreatePostInteractor {
    weak var output: CreatePostInteractorOutput?
}

extension CreatePostInteractor: CreatePostInteractorInput {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String) {
        CreatePostManager.shared.createPost(image: image,
                                            title: title,
                                            description: description,
                                            content: content,
                                            isDraft: isDraft,
                                            delayPublishTo: delayPublishTo) { [weak self] result in
            switch result {
            case .success:
                self?.output?.didCreatePost()
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }

    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String) {
        CreatePostManager.shared.editPost(postId: postId,
                                          image: image,
                                          imageId: imageId,
                                          title: title,
                                          description: description,
                                          content: content,
                                          isDraft: isDraft,
                                          delayPublishTo: delayPublishTo) { [weak self] result in
            switch result {
            case .success(let post):
                self?.output?.didEditPost(with: post)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }
}
