//
//  CreatePostRouter.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit

final class CreatePostRouter {
    weak var viewController: UIViewController?
}

extension CreatePostRouter: CreatePostRouterInput {
    func showAddImageAlert(isImageAlready: Bool, onRemovedImage: (() -> Void)?) {

        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        alert.addAction(UIAlertAction(title: "Create_Post_Create_Add_Image_Alert_Take_Photo_Title".localized,
                                      style: .default, handler: { [weak self] _ in
            self?.showImagePicker(with: .camera)
        }))

        alert.addAction(UIAlertAction(title: "Create_Post_Create_Add_Image_Alert_Choose_Title".localized,
                                      style: .default, handler: { [weak self] _ in
            self?.showImagePicker(with: .photoLibrary)
        }))

        if isImageAlready {
            alert.addAction(UIAlertAction(title: "Create_Post_Create_Add_Image_Alert_Remove_Title".localized,
                                          style: .destructive, handler: { _ in
                onRemovedImage?()
            }))
        }

        alert.addAction(UIAlertAction(title: "Create_Post_Create_Add_Image_Alert_Cancel_Title".localized,
                                      style: .cancel))

        if let sourceView = viewController?.view {
            alert.popoverPresentationController?.sourceView = sourceView
            alert.popoverPresentationController?.sourceRect = sourceView.bounds
            alert.popoverPresentationController?.permittedArrowDirections = []
        }

        viewController?.present(alert, animated: true)
    }

    private func showImagePicker(with sourceType: UIImagePickerController.SourceType) {
        guard let viewController = viewController as? CreatePostViewController else {
            return
        }

        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = sourceType
        imagePicker.allowsEditing = true
        imagePicker.delegate = viewController
        viewController.present(imagePicker, animated: true)
    }
}
