//
//  CreatePostAddImageCell.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 22.10.2022.
//

import UIKit

final class CreatePostAddImageCell: UICollectionViewCell {

    // MARK: - Private properties

    private let logoAddImageView: UIImageView = UIImageView()
    private let userImageView: UIImageView = UIImageView()

    // MARK: - Init

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Reuse

    override func prepareForReuse() {
        super.prepareForReuse()
    }

    // MARK: - Setup

    private func setup() {
        backgroundColor = Constants.View.backgroundColor

        layer.cornerRadius = Constants.View.cornerRadius
        layer.borderWidth = Constants.View.borderWidth
        layer.borderColor = Constants.View.borderColor
        clipsToBounds = true

        userImageView.tintColor = Constants.UserImageView.tintColor
        userImageView.backgroundColor = Constants.UserImageView.backgroundColor

        logoAddImageView.image = UIImage(systemName: "photo.circle")
        logoAddImageView.tintColor = Constants.AddImageView.tintColor

        addSubviews(logoAddImageView, userImageView)
    }

    // MARK: - Configure

    func configure(with model: CreatePostAddImageCellModel) {
        logoAddImageView.isHidden = !model.shouldShowEmptyStateImage
        userImageView.isHidden = model.shouldShowEmptyStateImage

        switch model.state {
        case .uploaded(let image):
            userImageView.image = image
        case .url(let imageURL):
            let placeholderImage = UIImage(systemName: "photo.circle")?.withRenderingMode(.alwaysTemplate)
            userImageView.setImage(from: imageURL, placeholderImage: placeholderImage)
        case .empty:
            userImageView.image = nil
        }
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        logoAddImageView.pin
            .center()
            .size(Constants.AddImageView.size)

        userImageView.pin
            .all()
    }
}

// MARK: - Constants

private extension CreatePostAddImageCell {
    struct Constants {
        struct View {
            static let backgroundColor: UIColor = .UI.card.value
            static let borderColor: CGColor = UIColor.UI.separator.value.cgColor
            static let cornerRadius: CGFloat = 8
            static let borderWidth: CGFloat = 1
        }

        struct UserImageView {
            static let backgroundColor: UIColor = .UI.secondary.value
            static let tintColor: UIColor = .UI.card.value
        }

        struct AddImageView {
            static let tintColor: UIColor = .systemIndigo
            static let size: CGSize = CGSize(width: 40, height: 40)
        }
    }
}
