//
//  CreatePostAddImageCellModel.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 25.10.2022.
//

import UIKit

enum CreatePostAddImageCellState: Equatable {
    case url(imageURL: String)
    case uploaded(image: UIImage)
    case empty
}

struct CreatePostAddImageCellModel {
    let state: CreatePostAddImageCellState
    let shouldShowEmptyStateImage: Bool

    init(state: CreatePostAddImageCellState) {
        self.state = state
        self.shouldShowEmptyStateImage = state == .empty
    }
}
