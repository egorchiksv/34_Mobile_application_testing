//
//  CreatePostViewModel.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 12.11.2022.
//

import UIKit

struct CreatePostViewModel {
    let screenTitle: String
    let title: String?
    let titlePlaceholder: String
    let description: String?
    let descriptionPlaceholder: NSAttributedString
    let content: String?
    let contentPlaceholder: NSAttributedString
    let delayDate: Date
    let delayDateTitle: NSAttributedString
    let actionButtonTitle: String

    init(screenTitle: String,
         title: String?,
         titlePlaceholder: String,
         description: String?,
         descriptionPlaceholder: String,
         content: String?,
         contentPlaceholder: String,
         delayDate: String?,
         delayDateTitle: String,
         actionButtonTitle: String) {
        self.screenTitle = screenTitle

        self.title = title
        self.titlePlaceholder = titlePlaceholder

        self.description = description
        self.descriptionPlaceholder = NSAttributedString(string: descriptionPlaceholder,
                                                         attributes: Constants.placeholderAttributes)

        self.content = content
        self.contentPlaceholder = NSAttributedString(string: contentPlaceholder,
                                                     attributes: Constants.placeholderAttributes)

        self.delayDate = Self.delayDate(for: delayDate)
        self.delayDateTitle = NSAttributedString(string: delayDateTitle,
                                                 attributes: Constants.delayDateTitleAttributes)

        self.actionButtonTitle = actionButtonTitle
    }
}

private extension CreatePostViewModel {
    static func delayDate(for date: String?) -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yy-MM-dd'T'HH:mm:ssZ"

        guard
            let date = date,
            let delayDate = dateFormatter.date(from: date)
        else {
            return Date.now
        }

        return delayDate
    }
}

private extension CreatePostViewModel {
    struct Constants {
        static let placeholderAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.secondary.value]
        static let delayDateTitleAttributes = [NSAttributedString.Key.foregroundColor: UIColor.Text.primary.value]
    }
}
