//
//  CreatePostContainer.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 19.10.2022.
//  
//

import UIKit
import Domain

enum CreatePostModuleType {
    case create
    case edit(post: FeedPost)
}

final class CreatePostContainer {
    let input: CreatePostModuleInput
    let viewController: UIViewController
    private(set) weak var router: CreatePostRouterInput!

    class func assemble(with context: CreatePostContext) -> CreatePostContainer {
        let router = CreatePostRouter()
        let interactor = CreatePostInteractor()
        let presenter = CreatePostPresenter(router: router, interactor: interactor, type: context.type)
        let viewController = CreatePostViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter
        router.viewController = viewController

        return CreatePostContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UIViewController, input: CreatePostModuleInput, router: CreatePostRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct CreatePostContext {
    weak var moduleOutput: CreatePostModuleOutput?
    let type: CreatePostModuleType
}
