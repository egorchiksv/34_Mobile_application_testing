//
//  CreatePostViewModelFactory.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 12.11.2022.
//

protocol CreatePostViewModelFactoryDescription {
    func createViewModel(for type: CreatePostModuleType) -> CreatePostViewModel
}

final class CreatePostViewModelFactory: CreatePostViewModelFactoryDescription {
    func createViewModel(for type: CreatePostModuleType) -> CreatePostViewModel {
        let titlePlaceholder = "Create_Post_Title_Placeholder".localized
        let descriptionPlaceholder = "Create_Post_Description_Placeholder".localized
        let contentPlaceholder = "Create_Post_Content_Placeholder".localized
        let delayDateTitle = "Create_Post_Delay_Title".localized

        switch type {
        case .create:
            return CreatePostViewModel(screenTitle: "Create_Post_Title".localized,
                                       title: nil,
                                       titlePlaceholder: titlePlaceholder,
                                       description: nil,
                                       descriptionPlaceholder: descriptionPlaceholder,
                                       content: nil,
                                       contentPlaceholder: contentPlaceholder,
                                       delayDate: nil,
                                       delayDateTitle: delayDateTitle,
                                       actionButtonTitle: "Create_Post_Action_Button_Title".localized)
        case .edit(let post):
            return CreatePostViewModel(screenTitle: "Edit_Post_Title".localized,
                                       title: post.title,
                                       titlePlaceholder: titlePlaceholder,
                                       description: post.description,
                                       descriptionPlaceholder: descriptionPlaceholder,
                                       content: post.content,
                                       contentPlaceholder: contentPlaceholder,
                                       delayDate: post.delayPublishTo,
                                       delayDateTitle: delayDateTitle,
                                       actionButtonTitle: "Edit_Post_Action_Button_Title".localized)
        }
    }
}
