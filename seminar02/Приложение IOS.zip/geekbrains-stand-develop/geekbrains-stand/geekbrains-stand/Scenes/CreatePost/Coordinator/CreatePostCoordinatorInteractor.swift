//
//  CreatePostCoordinatorInteractor.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 20.11.2022.
//

final class CreatePostCoordinatorInteractor {
    weak var output: CreatePostCoordinatorInteractorOutput?

    private let postManager: PostManagerDescription

    init(postManager: PostManagerDescription = PostManager.shared) {
        self.postManager = postManager
    }
}

extension CreatePostCoordinatorInteractor: CreatePostCoordinatorInteractorInput {
    func recievePost(with postId: Int) {
        postManager.getPost(postId: postId) { [weak self] result in
            switch result {
            case .success(let post):
                self?.output?.didRecieve(post: post)
            case .failure(let error):
                self?.output?.didRecieve(error: error)
            }
        }
    }
}
