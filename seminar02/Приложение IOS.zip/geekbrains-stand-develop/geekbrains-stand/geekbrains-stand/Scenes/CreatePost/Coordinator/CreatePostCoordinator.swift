//
//  CreatePostCoordinator.swift
//  geekbrains-stand
//
//  Created e.korotkiy on 19.10.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils
import Domain

enum CreatePostType {
    case create
    case editByPost(post: FeedPost)
    case editById(postId: Int)
}

struct CreatePostFlowContext {
    let type: CreatePostType
}

final class CreatePostCoordinator: Coordinator {

    // MARK: - Private properties

    private weak var sourceViewController: UIViewController?
    private let interactor: CreatePostCoordinatorInteractorInput
    private let flowContext: CreatePostFlowContext

    private(set) var mainViewController: UIViewController?

    // MARK: - Public properties

    var onClose: (() -> Void)?
    var onEditSuccessfully: ((FeedPost) -> Void)?

    // MARK: - Init

    init(sourceViewController: UIViewController,
         interactor: CreatePostCoordinatorInteractorInput,
         flowContext: CreatePostFlowContext) {
        self.sourceViewController = sourceViewController
        self.interactor = interactor
        self.flowContext = flowContext

        super.init()

        self.interactor.output = self
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)

        switch flowContext.type {
        case .create:
            showCreatePost(with: .create)
        case .editByPost(let post):
            showCreatePost(with: .edit(post: post))
        case .editById(let postId):
            sourceViewController?.showActivity()
            interactor.recievePost(with: postId)
        }
    }

    override func finish() {
        super.finish()

        sourceViewController?.presentedViewController?.dismiss(animated: true, completion: nil)
    }
}

private extension CreatePostCoordinator {
    func showCreatePost(with type: CreatePostModuleType) {
        let context = CreatePostContext(moduleOutput: self, type: type)
        let container = CreatePostContainer.assemble(with: context)
        let viewController = container.viewController
        viewController.modalPresentationStyle = .popover
        mainViewController = UINavigationController(rootViewController: container.viewController)

        guard
            let sourceViewController = sourceViewController,
            let mainViewController = mainViewController
        else {
            return
        }

        sourceViewController.present(mainViewController, animated: true)
    }
}

extension CreatePostCoordinator: CreatePostModuleOutput {
    func createPostModuleDidRequestToClose() {
        onClose?()
    }

    func createPostModuleDidCreate() {
        onClose?()
        sourceViewController?.view.showHUD(message: "Create_Post_Success_Message".localized)
    }

    func createPostModuleDidEdit(with post: FeedPost) {
        onClose?()
        sourceViewController?.view.showHUD(message: "Edit_Post_Success_Message".localized)
        onEditSuccessfully?(post)
    }
}

extension CreatePostCoordinator: CreatePostCoordinatorInteractorOutput {
    func didRecieve(post: FeedPost) {
        sourceViewController?.hideActivity()
        showCreatePost(with: .edit(post: post))
    }

    func didRecieve(error: Error) {
        sourceViewController?.hideActivity()
        sourceViewController?.showHUD(with: error, completion: nil)
    }
}
