//
//  CreatePostCoordinatorProtocol.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 20.11.2022.
//

import Domain

protocol CreatePostCoordinatorInteractorInput: AnyObject {
    var output: CreatePostCoordinatorInteractorOutput? { get set }

    func recievePost(with postId: Int)
}

protocol CreatePostCoordinatorInteractorOutput: AnyObject {
    func didRecieve(post: FeedPost)
    func didRecieve(error: Error)
}
