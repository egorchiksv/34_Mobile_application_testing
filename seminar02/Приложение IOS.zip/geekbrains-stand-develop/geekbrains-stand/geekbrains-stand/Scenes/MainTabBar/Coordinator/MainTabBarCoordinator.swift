//
//  MainTabBarCoordinator.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation
import Utils
import UIKit

final class MainTabBarCoordinator: Coordinator {

    private(set) var tabBarController: UITabBarController?

    // MARK: - Coordinators

    private var feedCoordinator: FeedCoordinator?
    private var createPostCoordinator: CreatePostCoordinator?
    private var myPostsCoordinator: MyPostsCoordinator?
    private var myProfileCoordinator: MyProfileCoordinator?

    // MARK: - Private properties

    lazy var interactor: MainTabBarCoordinatorInteractorInput = MainTabBarCoordinatorInteractor(output: self)

    private weak var feedModuleInput: FeedModuleInput?
    private weak var myPostsModuleInput: MyPostsModuleInput?

    // MARK: - Init
    override init() {
        super.init()

        let container = MainTabBarContainer.assemble(with: MainTabBarContext(moduleOutput: self))
        tabBarController = container.viewController

        setup()
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)
    }

    override func finish() {
        super.finish()

        feedCoordinator = nil
        createPostCoordinator = nil
        myPostsCoordinator = nil
        myProfileCoordinator = nil
    }
}

extension MainTabBarCoordinator {

    func setup() {
        setupFeed()
        setupMyPosts()
        setupMyProfile()
        setupTabBar()
    }

    func setupFeed() {
        let flowContext = FeedFlowContext()
        feedCoordinator = FeedCoordinator(navigationController: nil, flowContext: flowContext)
        feedModuleInput = feedCoordinator?.moduleInput
        feedCoordinator?.start(in: self)
    }

    func setupMyPosts() {
        let flowContext = MyPostsFlowContext()
        myPostsCoordinator = MyPostsCoordinator(navigationController: nil, flowContext: flowContext)
        myPostsModuleInput = myPostsCoordinator?.moduleInput
        myPostsCoordinator?.start(in: self)
    }

    func setupMyProfile() {
        let flowContext = MyProfileFlowContext()
        myProfileCoordinator = MyProfileCoordinator(navigationController: nil, flowContext: flowContext)

        myProfileCoordinator?.start(in: self)
    }

    func setupTabBar() {
        let viewControllers = TabBarItem.allCases.map { createViewController(for: $0) }
        tabBarController?.setViewControllers(viewControllers, animated: false)
    }
}

extension MainTabBarCoordinator {

    private func createViewController(for item: TabBarItem) -> UIViewController {
        let viewController: UIViewController
        let tabBarItem = UITabBarItem()

        switch item {
        case .feed:
            viewController = feedCoordinator?.mainViewController ?? UIViewController()
            tabBarItem.image = UIImage(systemName: "house")
            tabBarItem.selectedImage = UIImage(systemName: "house")?.withRenderingMode(.automatic)
            tabBarItem.title = "Feed_Title".localized
        case .createPost:
            viewController = UIViewController()
            tabBarItem.image = UIImage(systemName: "square.and.pencil")
            tabBarItem.selectedImage = UIImage(systemName: "square.and.pencil")?.withRenderingMode(.automatic)
            tabBarItem.title = "Create_Post_Title".localized
        case .myPosts:
            viewController = myPostsCoordinator?.mainViewController ?? UIViewController()
            tabBarItem.image = UIImage(systemName: "rectangle.grid.1x2")
            tabBarItem.selectedImage = UIImage(systemName: "rectangle.grid.1x2")?.withRenderingMode(.automatic)
            tabBarItem.title = "MyPosts_Title".localized
        case .myProfile:
            viewController = myProfileCoordinator?.mainViewController ?? UIViewController()
            tabBarItem.image = UIImage(systemName: "person")
            tabBarItem.selectedImage = UIImage(systemName: "person")?.withRenderingMode(.automatic)
            tabBarItem.title = "MyProfile_Title".localized
        }

        tabBarItem.tag = item.rawValue
        viewController.tabBarItem = tabBarItem

        return viewController
    }
}

extension MainTabBarCoordinator: MainTabBarCoordinatorInteractorOutput {

    // MARK: - Auth

    func didSignIn() {

    }

    func didSignOut() {

    }
}

extension MainTabBarCoordinator: MainTabBarModuleOutput {
    func tabBarModuleDidRequestToCreatePost() {
        guard let tabBarController = tabBarController else {
            return
        }

        let flowContext = CreatePostFlowContext(type: .create)
        createPostCoordinator = CreatePostCoordinator(sourceViewController: tabBarController,
                                                      interactor: CreatePostCoordinatorInteractor(),
                                                      flowContext: flowContext)
        createPostCoordinator?.onClose = { [weak self] in
            self?.createPostCoordinator?.finish()
            self?.createPostCoordinator = nil
        }

        createPostCoordinator?.start(in: self)
    }

    func tabBarModuleDidTapOnAlreadySelected(_ item: TabBarItem) {
        switch item {
        case .feed:
            feedModuleInput?.scrollToTop()
        case .createPost:
            break
        case .myPosts:
            myPostsModuleInput?.scrollToTop()
        case .myProfile:
            break
        }
    }
}
