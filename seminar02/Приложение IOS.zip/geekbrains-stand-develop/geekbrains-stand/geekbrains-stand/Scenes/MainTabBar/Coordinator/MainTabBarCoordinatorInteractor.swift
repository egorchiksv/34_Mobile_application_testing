//
//  MainTabBarCoordinatorInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

protocol MainTabBarCoordinatorInteractorInput: AnyObject {
}

protocol MainTabBarCoordinatorInteractorOutput: AnyObject {
    func didSignIn()
    func didSignOut()
}

final class MainTabBarCoordinatorInteractor {
    private weak var output: MainTabBarCoordinatorInteractorOutput?

    private let authObserving: AuthObserving

    init(output: MainTabBarCoordinatorInteractorOutput? = nil,
         authObserving: AuthObserving = AuthChangingService()) {
        self.output = output
        self.authObserving = authObserving

        authObserving.delegate = self
        authObserving.subscribe()
    }
}

extension MainTabBarCoordinatorInteractor: MainTabBarCoordinatorInteractorInput {

}

extension MainTabBarCoordinatorInteractor: AuthChangingDelegate {
    func authChangingDidSignIn() {
        output?.didSignIn()
    }

    func authChangingDidSignOut() {
        output?.didSignOut()
    }
}
