//
//  MainTabBarViewController.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit

final class MainTabBarViewController: UITabBarController {
    private let output: MainTabBarViewOutput

    init(output: MainTabBarViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        delegate = output.tabBarDelegate
        view.tintColor = .systemIndigo

        tabBar.backgroundColor = .background

        output.didLoadView()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        output.didAppearView()
    }
}

extension MainTabBarViewController: MainTabBarViewInput {
    func set(viewControllers: [UIViewController]) {
        self.viewControllers = viewControllers
    }

    func set(selectedIndex: Int) {
        guard let count = viewControllers?.count, selectedIndex < count else {
            return
        }

        self.selectedIndex = selectedIndex
    }
}
