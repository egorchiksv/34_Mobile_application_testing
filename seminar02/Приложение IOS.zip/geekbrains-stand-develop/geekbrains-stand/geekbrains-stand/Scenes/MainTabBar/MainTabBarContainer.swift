//
//  MainTabBarContainer.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import UIKit

final class MainTabBarContainer {
    let input: MainTabBarModuleInput
    let viewController: UITabBarController
    private(set) weak var router: MainTabBarRouterInput!

    class func assemble(with context: MainTabBarContext) -> MainTabBarContainer {
        let router = MainTabBarRouter()
        let interactor = MainTabBarInteractor()
        let presenter = MainTabBarPresenter(router: router, interactor: interactor)
        let viewController = MainTabBarViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return MainTabBarContainer(view: viewController, input: presenter, router: router)
    }

    private init(view: UITabBarController, input: MainTabBarModuleInput, router: MainTabBarRouterInput) {
        self.viewController = view
        self.input = input
        self.router = router
    }
}

struct MainTabBarContext {
    weak var moduleOutput: MainTabBarModuleOutput?
}
