//
//  MainTabBarPresenter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation
import UIKit

final class MainTabBarPresenter: NSObject {
    weak var view: MainTabBarViewInput?
    weak var moduleOutput: MainTabBarModuleOutput?

    private let router: MainTabBarRouterInput
    private let interactor: MainTabBarInteractorInput

    init(router: MainTabBarRouterInput, interactor: MainTabBarInteractorInput) {
        self.router = router
        self.interactor = interactor
    }
}

extension MainTabBarPresenter: MainTabBarModuleInput {
}

extension MainTabBarPresenter: MainTabBarViewOutput {
    var tabBarDelegate: UITabBarControllerDelegate { self }

    func didLoadView() {

    }

    func didAppearView() {
    }
}

extension MainTabBarPresenter: MainTabBarInteractorOutput {
}

extension MainTabBarPresenter: UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        guard let tag = viewController.tabBarItem?.tag, let item = TabBarItem(rawValue: tag) else {
            return true
        }

        if tabBarController.selectedViewController == viewController {
            moduleOutput?.tabBarModuleDidTapOnAlreadySelected(item)
            return true
        }

        switch item {
        case .feed:
            return true
        case .createPost:
            moduleOutput?.tabBarModuleDidRequestToCreatePost()
            return false
        case .myPosts:
            return true
        case .myProfile:
            return true
        }
    }
}
