//
//  MainTabBarProtocols.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation
import UIKit

protocol MainTabBarModuleInput {
    var moduleOutput: MainTabBarModuleOutput? { get }
}

protocol MainTabBarModuleOutput: AnyObject {
    func tabBarModuleDidRequestToCreatePost()
    func tabBarModuleDidTapOnAlreadySelected(_ item: TabBarItem)
}

protocol MainTabBarViewInput: AnyObject {
    func set(viewControllers: [UIViewController])
    func set(selectedIndex: Int)
}

protocol MainTabBarViewOutput: AnyObject {
    var tabBarDelegate: UITabBarControllerDelegate { get }

    func didLoadView()
    func didAppearView()
}

protocol MainTabBarInteractorInput: AnyObject {
}

protocol MainTabBarInteractorOutput: AnyObject {
}

protocol MainTabBarRouterInput: AnyObject {
}
