//
//  MainTabBarInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//  
//

import Foundation

final class MainTabBarInteractor {
    weak var output: MainTabBarInteractorOutput?
}

extension MainTabBarInteractor: MainTabBarInteractorInput {

}
