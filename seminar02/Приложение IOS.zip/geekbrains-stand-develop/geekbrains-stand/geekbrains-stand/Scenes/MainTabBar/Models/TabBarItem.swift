//
//  TabBarItem.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

enum TabBarItem: Int, CaseIterable {
    case feed
    case createPost
    case myPosts
    case myProfile
}
