//
//  FeedFilterContainer.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//  
//

import UIKit

final class FeedFilterContainer {
    let input: FeedFilterModuleInput
    let viewController: UIViewController

    class func assemble(with context: FeedFilterContext) -> FeedFilterContainer {
        let interactor = FeedFilterInteractor()
        let presenter = FeedFilterPresenter(configuration: context.configuration, interactor: interactor)
        let viewController = FeedFilterViewController(output: presenter)

        presenter.view = viewController
        presenter.moduleOutput = context.moduleOutput

        interactor.output = presenter

        return FeedFilterContainer(view: viewController, input: presenter)
    }

    private init(view: UIViewController, input: FeedFilterModuleInput) {
        self.viewController = view
        self.input = input
    }
}

struct FeedFilterContext {
    let configuration: FeedConfiguration

    weak var moduleOutput: FeedFilterModuleOutput?
}
