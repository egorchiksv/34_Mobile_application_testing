//
//  FeedFilterInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//  
//

import Foundation

final class FeedFilterInteractor {
    weak var output: FeedFilterInteractorOutput?
}

extension FeedFilterInteractor: FeedFilterInteractorInput {
}
