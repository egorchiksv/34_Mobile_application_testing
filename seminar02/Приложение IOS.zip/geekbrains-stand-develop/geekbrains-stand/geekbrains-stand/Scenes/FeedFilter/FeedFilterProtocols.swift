//
//  FeedFilterProtocols.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//  
//

import Foundation

protocol FeedFilterModuleInput {
    var moduleOutput: FeedFilterModuleOutput? { get }
}

protocol FeedFilterModuleOutput: AnyObject {
    func feedFilterModuleDidRequestUpdate(configuration: FeedConfiguration)
    func feedFilterModuleDidRequestToClose()
}

protocol FeedFilterViewInput: AnyObject {
    func setup(viewModel: FeedFilterViewModel)
}

protocol FeedFilterViewOutput: AnyObject {
    func didLoadView()
    func didRequestToClose()
    func didTapResetFilterButton()
    func toggle(option: FeedFilterOptions)
    func didTapActionButton()
}

protocol FeedFilterInteractorInput: AnyObject {
}

protocol FeedFilterInteractorOutput: AnyObject {
}
