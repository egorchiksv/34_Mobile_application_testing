//
//  FeedFilterViewModel.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//

import Foundation

struct FeedFilterOptions: OptionSet {
    let rawValue: Int

    static let grid = FeedFilterOptions(rawValue: 1 << 0)
    static let list = FeedFilterOptions(rawValue: 1 << 1)
    static let longCard = FeedFilterOptions(rawValue: 1 << 2)
    static let ascSort = FeedFilterOptions(rawValue: 1 << 3)
    static let descSort = FeedFilterOptions(rawValue: 1 << 4)
}

enum FeedFilterElements {
    case grid
    case list
    case longCard
    case ascSort
    case descSort

    var title: String {
        switch self {
        case .grid:
            return "Feed_Filters_Grid_Title".localized
        case .list:
            return "Feed_Filters_List_Title".localized
        case .longCard:
            return "Feed_Filters_Long_Card_Title".localized
        case .ascSort:
            return "Feed_Filters_ASC_Sort_Title".localized
        case .descSort:
            return "Feed_Filters_DESC_Sort_Title".localized
        }
    }
}

struct FeedFilterViewModel {
    let actionButtonTitle: String
    let enabledOptions: FeedFilterOptions

    let gridTitle: String = FeedFilterElements.grid.title
    var gridEnabled: Bool {
        return enabledOptions.contains(.grid)
    }

    let listTitle: String = FeedFilterElements.list.title
    var listEnabled: Bool {
        return enabledOptions.contains(.list)
    }

    let longCardTitle: String = FeedFilterElements.longCard.title
    var longCardEnabled: Bool {
        return enabledOptions.contains(.longCard)
    }

    let ascSortTitle: String = FeedFilterElements.ascSort.title
    var ascSortEnabled: Bool {
        return enabledOptions.contains(.ascSort)
    }

    let descSortTitle: String = FeedFilterElements.descSort.title
    var descSortEnabled: Bool {
        return enabledOptions.contains(.descSort)
    }

    init(actionButtonTitle: String, enabledOptions: FeedFilterOptions) {
        self.actionButtonTitle = actionButtonTitle
        self.enabledOptions = enabledOptions
    }
}
