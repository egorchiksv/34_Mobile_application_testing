//
//  FeedFilterPresenter.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//  
//

import Foundation

final class FeedFilterPresenter {
    weak var view: FeedFilterViewInput?
    weak var moduleOutput: FeedFilterModuleOutput?

    private let interactor: FeedFilterInteractorInput

    private var configuration: FeedConfiguration

    init(configuration: FeedConfiguration, interactor: FeedFilterInteractorInput) {
        self.configuration = configuration
        self.interactor = interactor
    }
}

private extension FeedFilterPresenter {
    func enabledOptions() -> FeedFilterOptions {
        var options: FeedFilterOptions = []

        switch configuration.style {
        case .list:
            options.insert(.list)
        case .grid:
            options.insert(.grid)
        case .long:
            options.insert(.longCard)
        }

        switch configuration.order {
        case .desc:
            options.insert(.descSort)
        case .asc:
            options.insert(.ascSort)
        }

        return options
    }

    func reloadData() {
        let viewModel = FeedFilterViewModel(actionButtonTitle: "Feed_Filters_Apply_Button_Title".localized,
                                            enabledOptions: enabledOptions())

        view?.setup(viewModel: viewModel)
    }
}

extension FeedFilterPresenter: FeedFilterModuleInput {
}

extension FeedFilterPresenter: FeedFilterViewOutput {

    func didLoadView() {
        reloadData()
    }

    func didRequestToClose() {
        moduleOutput?.feedFilterModuleDidRequestToClose()
    }

    func didTapResetFilterButton() {
        configuration = .default
        reloadData()
    }

    func toggle(option: FeedFilterOptions) {
        switch option {
        case .list:
            configuration.style = .list
        case .grid:
            configuration.style = .grid
        case .longCard:
            configuration.style = .long
        case .descSort:
            configuration.order = .desc
        case .ascSort:
            configuration.order = .asc
        default:
            break
        }

        reloadData()
    }

    func didTapActionButton() {
        moduleOutput?.feedFilterModuleDidRequestUpdate(configuration: configuration)
    }
}

extension FeedFilterPresenter: FeedFilterInteractorOutput {
}
