//
//  FeedFilterViewController.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 26.11.2022.
//  
//

import UIKit

final class FeedFilterViewController: UIViewController {
    private let output: FeedFilterViewOutput

    private let containerScrollView: UIScrollView = UIScrollView()
    private let actionButton: UIButton = UIButton()

    private let listButton: UIButton = UIButton(configuration: UIButton.Configuration.plain())
    private let gridButton: UIButton = UIButton(configuration: UIButton.Configuration.plain())
    private let longCardButton: UIButton = UIButton(configuration: UIButton.Configuration.plain())
    private let ascSortButton: UIButton = UIButton(configuration: UIButton.Configuration.plain())
    private let descSortButton: UIButton = UIButton(configuration: UIButton.Configuration.plain())

    init(output: FeedFilterViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        output.didLoadView()
        setup()
    }

    private func setup() {
        view.backgroundColor = Constants.Container.backgroundColor
        title = "Feed_Filters_Title".localized
        navigationItem.leftBarButtonItem = .closeButton(with: self, action: #selector(didTapNavigationBarCloseButton))

        actionButton.addTarget(self, action: #selector(didTapActionButton), for: .touchUpInside)
        actionButton.backgroundColor = Constants.ActionButton.backgroundColor
        actionButton.layer.cornerRadius = Constants.ActionButton.cornerRadius

        containerScrollView.contentInsetAdjustmentBehavior = .never
        containerScrollView.keyboardDismissMode = .onDrag

        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Feed_Filters_Reset_Title".localized,
                                                            style: .plain,
                                                            target: self,
                                                            action: #selector(didTapResetFilterButton))

        containerScrollView.addSubviews(listButton, gridButton, longCardButton, ascSortButton, descSortButton)

        [listButton, gridButton, longCardButton, ascSortButton, descSortButton]
            .forEach({
                $0.layer.cornerRadius = Constants.Common.cornerRadius
                $0.titleLabel?.numberOfLines = 0
                $0.titleLabel?.lineBreakMode = .byWordWrapping
            })

        listButton.addTarget(self, action: #selector(didTapListButton), for: .touchUpInside)
        gridButton.addTarget(self, action: #selector(didTapGridButton), for: .touchUpInside)
        longCardButton.addTarget(self, action: #selector(didTapLongCardButton), for: .touchUpInside)

        ascSortButton.addTarget(self, action: #selector(didTapAscButton), for: .touchUpInside)
        descSortButton.addTarget(self, action: #selector(didTapDescButton), for: .touchUpInside)

        view.addSubviews(actionButton, containerScrollView)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        actionButton.pin
            .horizontally(Constants.ActionButton.marginHorizontally)
            .bottom(view.safeAreaInsets.bottom + Constants.ActionButton.marginVertically)
            .height(Constants.ActionButton.height)

        containerScrollView.pin
            .top(view.safeAreaInsets.top)
            .horizontally()
            .above(of: actionButton)

        listButton.pin
            .top(Constants.Common.marginTop)
            .horizontally(Constants.Common.marginHorizontally)
            .sizeToFit(.width)

        gridButton.pin
            .below(of: listButton)
            .marginTop(Constants.Common.marginTop)
            .horizontally(Constants.Common.marginHorizontally)
            .sizeToFit(.width)

        longCardButton.pin
            .below(of: gridButton)
            .marginTop(Constants.Common.marginTop)
            .horizontally(Constants.Common.marginHorizontally)
            .sizeToFit(.width)

        ascSortButton.pin
            .below(of: longCardButton)
            .marginTop(Constants.Common.marginTop)
            .horizontally(Constants.Common.marginHorizontally)
            .sizeToFit(.width)

        descSortButton.pin
            .below(of: ascSortButton)
            .marginTop(Constants.Common.marginTop)
            .horizontally(Constants.Common.marginHorizontally)
            .sizeToFit(.width)

        containerScrollView.contentSize = CGSize(width: view.bounds.width,
                                                 height: descSortButton.frame.maxY)
    }
}

private extension FeedFilterViewController {

    @objc
    func didTapActionButton() {
        output.didTapActionButton()
    }

    @objc
    func didTapNavigationBarCloseButton() {
        output.didRequestToClose()
    }

    @objc
    func didTapResetFilterButton() {
        output.didTapResetFilterButton()
    }

    @objc
    func didTapListButton() {
        output.toggle(option: .list)
    }

    @objc
    func didTapGridButton() {
        output.toggle(option: .grid)
    }

    @objc
    func didTapLongCardButton() {
        output.toggle(option: .longCard)
    }

    @objc
    func didTapAscButton() {
        output.toggle(option: .ascSort)
    }

    @objc
    func didTapDescButton() {
        output.toggle(option: .descSort)
    }
}

extension FeedFilterViewController: FeedFilterViewInput {

    func setup(viewModel: FeedFilterViewModel) {
        actionButton.setTitle(viewModel.actionButtonTitle, for: .normal)

        func updateButton(with button: UIButton, isEnabled: Bool, title: String) {
            let enabledColor = Constants.Common.enabledBackgroundColor
            let disabledColor = Constants.Common.disabledBackgroundColor

            button.configurationUpdateHandler = { button in
                var config = button.configuration
                config?.title = title
                config?.background.backgroundColor = isEnabled ? enabledColor : disabledColor
                config?.baseForegroundColor = .white
                button.configuration = config
            }
        }

        updateButton(with: listButton, isEnabled: viewModel.listEnabled, title: viewModel.listTitle)
        updateButton(with: gridButton, isEnabled: viewModel.gridEnabled, title: viewModel.gridTitle)
        updateButton(with: longCardButton, isEnabled: viewModel.longCardEnabled, title: viewModel.longCardTitle)
        updateButton(with: ascSortButton, isEnabled: viewModel.ascSortEnabled, title: viewModel.ascSortTitle)
        updateButton(with: descSortButton, isEnabled: viewModel.descSortEnabled, title: viewModel.descSortTitle)

        view.setNeedsLayout()
        view.layoutIfNeeded()
    }
}

private extension FeedFilterViewController {

    struct Constants {
        struct Container {
            static let backgroundColor: UIColor = .UI.background.value
        }

        struct ActionButton {
            static let backgroundColor: UIColor = .systemIndigo
            static let cornerRadius: CGFloat = 8
            static let marginHorizontally: CGFloat = 12
            static let marginVertically: CGFloat = 12
            static let height: CGFloat = 44
        }

        struct Common {
            static let enabledBackgroundColor: UIColor = .UI.success.value
            static let disabledBackgroundColor: UIColor = .UI.secondary.value
            static let marginHorizontally: CGFloat = 12
            static let marginTop: CGFloat = 8
            static let cornerRadius: CGFloat = 8
        }
    }
}
