//
//  AppCoordinator.swift
//  geekbrains-stand
//
//  Created k.kulakov on 19.10.2022.
//  Copyright © 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit
import Utils

protocol AppCoordinatorOutput: AnyObject {
    func appCoordinatorRequestUpdateWindow()
}

struct AppFlowContext {
    weak var moduleOutput: AppCoordinatorOutput?
}

final class AppCoordinator: Coordinator {

    // MARK: - Coordinator

    private var tabBarCoordinator: MainTabBarCoordinator?

    // MARK: - Public properties
    var appViewController: UIViewController?

    // MARK: - Private properties

    lazy var interactor: AppCoordinatorInteractorInput = AppCoordinatorInteractor(output: self)

    private let flowContext: AppFlowContext

    // MARK: - Init

    init(flowContext: AppFlowContext) {
        self.flowContext = flowContext
        super.init()

        setup()
    }

    // MARK: - Setup

    private func setup() {
        if interactor.isLoggedIn {
            setupTabBar()
        } else {
            setupAuth()
        }
    }

    private func setupTabBar() {
        let mainTabBarCoordinator = MainTabBarCoordinator()
        mainTabBarCoordinator.start(in: self)
        tabBarCoordinator = mainTabBarCoordinator

        appViewController = tabBarCoordinator?.tabBarController
    }

    private func setupAuth() {
        let context = AuthorizationContext(moduleOutput: self)
        let container = AuthorizationContainer.assemble(with: context)

        appViewController = container.viewController
    }

    // MARK: - Flow

    override func start(in parent: Coordinator?) {
        super.start(in: parent)
    }

    override func finish() {
        super.finish()

        tabBarCoordinator = nil
    }
}

extension AppCoordinator: AppCoordinatorInteractorOutput {

    func didSignIn() {
        setup()
        flowContext.moduleOutput?.appCoordinatorRequestUpdateWindow()
    }

    func didSignOut() {
        setup()
        flowContext.moduleOutput?.appCoordinatorRequestUpdateWindow()
    }
}

extension AppCoordinator: AuthorizationModuleOutput {

    func authorizationModuleDidSignIn() {
        setup()
        flowContext.moduleOutput?.appCoordinatorRequestUpdateWindow()
    }
}
