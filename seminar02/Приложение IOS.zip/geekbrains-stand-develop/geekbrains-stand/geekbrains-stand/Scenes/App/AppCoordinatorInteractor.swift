//
//  AppCoordinatorInteractor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

protocol AppCoordinatorInteractorInput: AnyObject {
    var isLoggedIn: Bool { get }
}

protocol AppCoordinatorInteractorOutput: AnyObject {
    func didSignIn()
    func didSignOut()
}

final class AppCoordinatorInteractor {
    private weak var output: AppCoordinatorInteractorOutput?

    private let authObserving: AuthObserving
    private let authManager: AuthorizationManagerDescription

    init(output: AppCoordinatorInteractorOutput? = nil,
         authObserving: AuthObserving = AuthChangingService(),
         authManager: AuthorizationManagerDescription = AuthorizationManager.shared) {
        self.output = output
        self.authObserving = authObserving
        self.authManager = authManager

        authObserving.delegate = self
        authObserving.subscribe()
    }
}

extension AppCoordinatorInteractor: AppCoordinatorInteractorInput {

    var isLoggedIn: Bool {
        return authManager.sessionInfo != nil
    }
}

extension AppCoordinatorInteractor: AuthChangingDelegate {
    func authChangingDidSignIn() {
        output?.didSignIn()
    }

    func authChangingDidSignOut() {
        output?.didSignOut()
    }
}
