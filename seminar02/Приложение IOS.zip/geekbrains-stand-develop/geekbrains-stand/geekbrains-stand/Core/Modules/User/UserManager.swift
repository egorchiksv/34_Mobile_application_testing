//
//  UserManager.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 24.10.2022.
//

import Domain
import Storage
import Networks

protocol UserManagerDescription {
    func getProfile(userId: Int, completion: @escaping ((Result<UserProfile, Error>) -> Void))
    func updateProfile(userId: Int,
                       profile: UserProfile,
                       completion: @escaping ((Result<UserProfile, Error>) -> Void))
}

final class UserManager {
    private let networkingUseCaseProvider: NetworkingUseCaseProvider
    private let network: UserUseCase
    private let storage: SessionStorageUseCase

    static let shared: UserManagerDescription = UserManager()

    private init(networkingUseCaseProvider: NetworkingUseCaseProvider = UseCaseProvider(),
                 storage: SessionStorageUseCase = SessionStorage.shared) {
        self.networkingUseCaseProvider = networkingUseCaseProvider
        self.storage = storage
        self.network = networkingUseCaseProvider.makeUserUseCase(token: storage.session()?.token)
    }
}

extension UserManager: UserManagerDescription {
    func getProfile(userId: Int, completion: @escaping ((Result<Domain.UserProfile, Error>) -> Void)) {
        network.getProfile(userId: userId) { result in
            switch result {
            case .success(let userProfile):
                completion(.success(userProfile))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func updateProfile(userId: Int,
                       profile: UserProfile,
                       completion: @escaping ((Result<UserProfile, Error>) -> Void)) {
        network.updateProfile(userId: userId, profile: profile) { result in
            switch result {
            case .success(let userProfile):
                completion(.success(userProfile))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
