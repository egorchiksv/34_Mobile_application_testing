//
//  AuthChangingProtocols.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

protocol AuthChangingDelegate: AnyObject {
    func authChangingDidSignIn()
    func authChangingDidSignOut()
}

protocol AuthObserving: AnyObject {
    var delegate: AuthChangingDelegate? { get set }

    func subscribe()
}

protocol AuthChanging: AnyObject {
    func signIn()
    func signOut()
}
