//
//  AuthChangingService.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

final class AuthChangingService {
    weak var delegate: AuthChangingDelegate?
}

extension AuthChangingService: AuthObserving {
    func subscribe() {
        NotificationCenter.default.removeObserver(self,
                                                  name: .didSignIn,
                                                  object: nil)
        NotificationCenter.default.removeObserver(self,
                                                  name: .didSignOut,
                                                  object: nil)

        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didSignIn),
                                               name: .didSignIn,
                                               object: nil)
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(didSignOut),
                                               name: .didSignOut,
                                               object: nil)
    }

    @objc
    private func didSignIn() {
        delegate?.authChangingDidSignIn()
    }

    @objc
    private func didSignOut() {
        delegate?.authChangingDidSignOut()
    }

}

extension AuthChangingService: AuthChanging {
    func signIn() {
        NotificationCenter.default.post(name: .didSignIn, object: nil)
    }

    func signOut() {
        NotificationCenter.default.post(name: .didSignOut, object: nil)
    }
}

private extension Notification.Name {
    static let didSignIn: Notification.Name = .init("AuthChangingService.didSignIn")
    static let didSignOut: Notification.Name = .init("AuthChangingService.didSignOut")
}
