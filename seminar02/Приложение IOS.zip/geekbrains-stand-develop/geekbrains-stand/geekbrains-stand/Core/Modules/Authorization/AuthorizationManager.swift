//
//  AuthorizationManager.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation
import Domain
import Storage
import Networks

protocol AuthorizationManagerDescription {
    var sessionInfo: SessionInfo? { get }
    func login(userName: String, password: String, completion: @escaping ((Result<SessionInfo, Error>) -> Void))
    func logout()
}

final class AuthorizationManager {
    private let networkingUseCaseProvider: NetworkingUseCaseProvider
    private let network: AuthorizationUseCase
    private let storage: SessionStorageUseCase
    private let authChangingService: AuthChangingService

    static let shared: AuthorizationManagerDescription = AuthorizationManager()

    private init(networkingUseCaseProvider: NetworkingUseCaseProvider = UseCaseProvider(),
                 storage: SessionStorageUseCase = SessionStorage.shared,
                 authChangingService: AuthChangingService = AuthChangingService()) {

        self.networkingUseCaseProvider = networkingUseCaseProvider
        self.network = networkingUseCaseProvider.makeAuthorizationUseCase()
        self.storage = storage
        self.authChangingService = authChangingService
    }
}

extension AuthorizationManager: AuthorizationManagerDescription {

    var sessionInfo: SessionInfo? {
        return storage.session()
    }

    func login(userName: String, password: String, completion: @escaping ((Result<SessionInfo, Error>) -> Void)) {
        network.login(username: userName, password: password) { [weak self] result in
            switch result {
            case .success(let authResult):
                let sessionInfo = SessionInfo(userId: "\(authResult.userId)", token: authResult.token)
                self?.storage.save(with: sessionInfo)
                self?.authChangingService.signIn()

                completion(.success(sessionInfo))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func logout() {
        storage.clear()
        authChangingService.signOut()
    }
}
