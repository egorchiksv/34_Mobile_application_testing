//
//  PostsManager.swift
//  geekbrains-stand
//
//  Created by o.gibadulin on 02.11.2022.
//

import Domain
import Storage
import Networks

protocol PostManagerDescription {
    func getFeed(page: Int,
                 limit: Int,
                 sort: FeedSort?,
                 order: FeedOrder?,
                 owner: FeedOwner,
                 completion: @escaping ((Result<Feed, Error>) -> Void))
    func getPost(postId: Int,
                 completion: @escaping ((Result<FeedPost, Error>) -> Void))
    func removePost(postId: Int,
                    completion: @escaping ((Result<FeedPost, Error>) -> Void))
}

final class PostManager {
    private let networkingUseCaseProvider: NetworkingUseCaseProvider
    private let network: PostUseCase
    private let storage: SessionStorageUseCase

    static let shared: PostManagerDescription = PostManager()

    private init(networkingUseCaseProvider: NetworkingUseCaseProvider = UseCaseProvider(),
                 storage: SessionStorageUseCase = SessionStorage.shared) {
        self.networkingUseCaseProvider = networkingUseCaseProvider
        self.storage = storage
        self.network = networkingUseCaseProvider.makePostUseCase(token: storage.session()?.token)
    }
}

extension PostManager: PostManagerDescription {
    func getFeed(page: Int,
                 limit: Int,
                 sort: FeedSort?,
                 order: FeedOrder?,
                 owner: FeedOwner,
                 completion: @escaping ((Result<Feed, Error>) -> Void)) {
        network.feed(page: page,
                     limit: limit,
                     sort: sort,
                     order: order,
                     owner: owner) { result in
            switch result {
            case .success(let feed):
                completion(.success(feed))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func getPost(postId: Int, completion: @escaping ((Result<Domain.FeedPost, Error>) -> Void)) {
        network.getPost(postId: postId) { result in
            switch result {
            case .success(let post):
                completion(.success(post))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func removePost(postId: Int,
                    completion: @escaping ((Result<FeedPost, Error>) -> Void)) {
        network.deletePost(postId: postId) { result in
            switch result {
            case .success(let post):
                completion(.success(post))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
