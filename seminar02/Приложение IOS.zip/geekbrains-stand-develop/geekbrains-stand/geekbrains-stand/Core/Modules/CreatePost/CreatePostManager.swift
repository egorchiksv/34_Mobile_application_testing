//
//  CreatePostManager.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 28.10.2022.
//

import Domain
import Storage
import Networks

protocol CreatePostManagerDescription {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String,
                    completion: @escaping ((Result<Void, Error>) -> Void))
    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String,
                  completion: @escaping ((Result<FeedPost, Error>) -> Void))
}

final class CreatePostManager {
    private let network: CreatePostUseCase
    private let storage: SessionStorageUseCase

    static let shared: CreatePostManagerDescription = CreatePostManager()

    private init(networkingUseCaseProvider: NetworkingUseCaseProvider = UseCaseProvider(),
                 storage: SessionStorageUseCase = SessionStorage.shared) {
        let token = storage.session()?.token
        self.storage = storage
        self.network = networkingUseCaseProvider.makeCreatePostUseCase(token: token)
    }
}

extension CreatePostManager: CreatePostManagerDescription {
    func createPost(image: Data?,
                    title: String,
                    description: String,
                    content: String,
                    isDraft: Bool,
                    delayPublishTo: String,
                    completion: @escaping ((Result<Void, Error>) -> Void)) {
        network.createPost(image: image,
                           title: title,
                           description: description,
                           content: content,
                           isDraft: isDraft,
                           delayPublishTo: delayPublishTo) { result in
            switch result {
            case .success:
                completion(.success(()))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func editPost(postId: Int,
                  image: Data?,
                  imageId: Int?,
                  title: String,
                  description: String,
                  content: String,
                  isDraft: Bool,
                  delayPublishTo: String,
                  completion: @escaping ((Result<FeedPost, Error>) -> Void)) {
        network.editPost(postId: postId,
                         image: image,
                         imageId: imageId,
                         title: title,
                         description: description,
                         content: content,
                         isDraft: isDraft,
                         delayPublishTo: delayPublishTo) { result in
            switch result {
            case .success(let post):
                completion(.success(post))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}
