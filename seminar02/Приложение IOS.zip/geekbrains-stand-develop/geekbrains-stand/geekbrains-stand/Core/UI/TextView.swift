//
//  TextView.swift
//  geekbrains-stand
//
//  Created by e.korotkiy on 24.10.2022.
//

import UIKit

// swiftlint:disable final_class
class TextView: UITextView {
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    init() {
        super.init(frame: .zero, textContainer: nil)

        backgroundColor = Constants.backgroundColor
        clipsToBounds = true
        layer.cornerRadius = Constants.cornerRadius
        layer.borderWidth = Constants.borderWidth
        layer.borderColor = Constants.borderColor
        textContainer.lineFragmentPadding = 0
        font = Constants.font
    }
}

private extension TextView {
    struct Constants {
        static let backgroundColor: UIColor = .UI.card.value
        static let borderColor: CGColor = UIColor.UI.card.value.cgColor
        static let font: UIFont = UIFont.systemFont(ofSize: 17)
        static let cornerRadius: CGFloat = 8
        static let borderWidth: CGFloat = 1
    }
}
