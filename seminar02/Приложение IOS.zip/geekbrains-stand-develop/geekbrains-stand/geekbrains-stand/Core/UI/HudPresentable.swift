//
//  HudPresentable.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation
import MBProgressHUD

public protocol HUDPresentable: AnyObject {
    func showActivity()
    func showActivity(duration: TimeInterval, completion: (() -> Void)?)
    func hideActivity()
    func showHUD(with error: Error?, completion: (() -> Void)?)
    func showHUD(title: String?, message: String?, duration: TimeInterval, completion: (() -> Void)?)
}

extension HUDPresentable {

    public func showActivityWithDefaultDuration(completion: (() -> Void)?) {
        showActivity(duration: UIView.Activity.Constants.hudDefaultDuration, completion: completion)
    }

    public func showHUD(with error: Error?, completion: (() -> Void)? = nil) {
        showHUD(with: error, completion: completion)
    }

    public func showHUD(title: String? = nil,
                        message: String? = nil,
                        duration: TimeInterval = UIView.Activity.Constants.hudDefaultDuration,
                        completion: (() -> Void)? = nil) {
        showHUD(title: title, message: message, duration: duration, completion: completion)

        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.error)
    }

}

extension UIViewController: HUDPresentable {

    public struct Activity {
        public struct Constants {
            public static let hudDefaultDuration: TimeInterval = 2.0
        }
    }

    public func showActivity() {
        showActivity(didShowHud: nil, completion: nil)
    }

    public func showActivity(duration: TimeInterval, completion: (() -> Void)?) {
        showActivity(didShowHud: { (hud) in
            hud.hide(animated: true, afterDelay: duration)
        }, completion: completion)
    }

    public func hideActivity() {
        DispatchQueue.main.safeAsync { [weak self] in
            guard let self = self else {
                return
            }
            self.view.isUserInteractionEnabled = true

            while let hud = MBProgressHUD.forView(self.view) {
                hud.removeFromSuperViewOnHide = true
                hud.hide(animated: true)
            }
        }
    }

    private func showActivity(didShowHud: ((MBProgressHUD) -> Void)?, completion: (() -> Void)?) {
        guard nil == MBProgressHUD.forView(self.view) else {
            return
        }

        DispatchQueue.main.safeAsync {  [weak self] in
            guard let self = self else {
                return
            }
            self.view.isUserInteractionEnabled = false

            let hud = MBProgressHUD(view: self.view)
            hud.removeFromSuperViewOnHide = true
            hud.completionBlock = completion
            self.view.addSubview(hud)
            hud.layoutIfNeeded()
            hud.show(animated: true)
            didShowHud?(hud)
        }
    }

    public func showHUD(with error: Error?, completion: (() -> Void)?) {
        guard let error = error else {
            return
        }
        if !error.localizedDescription.isEmpty {
            showHUD(message: error.localizedDescription, completion: completion)
        }
    }

    public func showHUD(title: String?,
                        message: String?,
                        duration: TimeInterval = Activity.Constants.hudDefaultDuration,
                        completion: (() -> Void)? = nil) {
        DispatchQueue.main.safeAsync { [weak self] in
            guard let self = self else {
                return
            }
            let hud = MBProgressHUD(view: self.view)
            self.view.addSubview(hud)
            hud.label.text = title
            hud.detailsLabel.text = message
            hud.mode = MBProgressHUDMode.text
            hud.completionBlock = completion
            hud.removeFromSuperViewOnHide = true
            hud.show(animated: true)
            hud.hide(animated: true, afterDelay: duration)
        }
    }
}

extension UIView: HUDPresentable {

    public struct Activity {
        public struct Constants {
            public static let hudDefaultDuration: TimeInterval = 2.0
        }
    }

    private func showActivity(didShowHud: ((MBProgressHUD) -> Void)?, completion: (() -> Void)?) {
        guard nil == MBProgressHUD.forView(self) else {
            return
        }

        DispatchQueue.main.safeAsync {  [weak self] in
            guard let self = self else {
                return
            }
            self.isUserInteractionEnabled = false

            let hud = MBProgressHUD(view: self)
            hud.removeFromSuperViewOnHide = true
            hud.completionBlock = completion
            self.addSubview(hud)
            hud.layoutIfNeeded()
            hud.show(animated: true)
            didShowHud?(hud)
        }
    }

    public func showActivity() {
        showActivity(didShowHud: nil, completion: nil)
    }

    public func showActivity(duration: TimeInterval, completion: (() -> Void)?) {
        showActivity(didShowHud: { (hud) in
            hud.hide(animated: true, afterDelay: duration)
        }, completion: completion)
    }

    public func hideActivity() {
        DispatchQueue.main.safeAsync { [weak self] in
            guard let self = self else {
                return
            }
            self.isUserInteractionEnabled = true

            while let hud = MBProgressHUD.forView(self) {
                hud.removeFromSuperViewOnHide = true
                hud.hide(animated: true)
            }
        }
    }

    public func showHUD(with error: Error?, completion: (() -> Void)?) {
        guard let error = error else {
            return
        }
        if !error.localizedDescription.isEmpty {
            showHUD(message: error.localizedDescription, completion: completion)
        }
    }

    public func showHUD(title: String?, message: String?, duration: TimeInterval, completion: (() -> Void)?) {
        DispatchQueue.main.safeAsync { [weak self] in
            guard let self = self else {
                return
            }
            let hud = MBProgressHUD(view: self)
            self.addSubview(hud)
            hud.label.text = title
            hud.detailsLabel.text = message
            hud.mode = MBProgressHUDMode.text
            hud.completionBlock = completion
            hud.removeFromSuperViewOnHide = true
            hud.show(animated: true)
            hud.hide(animated: true, afterDelay: duration)
        }
    }

}
