//
//  FeedCursor.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 08.11.2022.
//

import Foundation
import Domain

final class FeedCursor {
    let limit: Int = 10
    private(set) var page: Int = Constants.initialPage
    private(set) var canRequestNext: Bool = true

    func reset() {
        canRequestNext = true
        page = Constants.initialPage
    }

    var isFirstPage: Bool {
        return page == Constants.initialPage
    }

    func update(with meta: FeedMeta) {
        guard let nextPage = meta.nextPage else {
            canRequestNext = false
            return
        }

        page = nextPage
        canRequestNext = true
    }

    private struct Constants {
        static let initialPage: Int = 1
    }
}
