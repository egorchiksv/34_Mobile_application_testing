//
//  ThreadHelper.swift
//  geekbrains-stand
//
//  Created by k.kulakov on 19.10.2022.
//

import Foundation

public extension DispatchQueue {
    // This method will dispatch the `block` to self.
    // If `self` is the main queue, and current thread is main thread, the block
    // will be invoked immediately instead of being dispatched.
    func safeAsync(_ block: @escaping () -> Void) {
        if self === DispatchQueue.main && Thread.isMainThread {
            block()
        } else {
            async { block() }
        }
    }

    func safeSync<T>(_ block: () throws -> T) rethrows -> T {
        if self === DispatchQueue.main && Thread.isMainThread {
            return try block()
        } else {
            return try sync { try block() }
        }
    }
}
